package com.gamification.core.dao;

import java.util.Date;
import java.util.List;


/**
 * MJ
 */
public interface GamificationEventPointsDao
{

	public List<Object> getCurrentTotalEventPoints(List<Object> fromDate);

}
