package com.gamification.core;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.fest.util.Collections;

import com.gamification.core.model.cron.LoyaltyPointCalculationCronJobModel;
import com.gamification.core.service.GamificationEventPointsService;

import de.hybris.platform.cronjob.enums.CronJobResult;
import de.hybris.platform.cronjob.enums.CronJobStatus;
import de.hybris.platform.cronjob.model.CronJobHistoryModel;
import de.hybris.platform.servicelayer.cronjob.AbstractJobPerformable;
import de.hybris.platform.servicelayer.cronjob.CronJobHistoryService;
import de.hybris.platform.servicelayer.cronjob.PerformResult;
import de.hybris.platform.util.Config;


public class LoyaltyPointCalculationJob extends AbstractJobPerformable<LoyaltyPointCalculationCronJobModel>
{
	@Resource
	private GamificationEventPointsService gamificationEventPointsService;

	@Resource
	private CronJobHistoryService cronJobHistoryService;

	private static final String CONFIGURABLE_PREV_YEAR = "cron.gamification.config.previous.year";
	private static final String CRON_JOB_CODE = "cron.gamification.config.cronjob.code";

	private final static Logger LOG = Logger.getLogger(LoyaltyPointCalculationJob.class.getName());

	@Override
	public PerformResult perform(final LoyaltyPointCalculationCronJobModel job)
	{
		boolean cronJobStatus = false;
		if (job.getSite()!= null && job.getBaseStore()!=null)
		{
			List<Object>cronJobValues=getCreationTimeHistory(cronJobStatus);
			
			if (!cronJobValues.isEmpty())
			{
				getGamificationEventPointsService().saveCustomerBonusPoints(cronJobValues,job.getSite(),job.getBaseStore());
			}
			return new PerformResult(CronJobResult.SUCCESS, CronJobStatus.FINISHED);
		}
		
		else
		{
			LOG.info("Aborted Bonus Points Update CronJob. ");
			return new PerformResult(CronJobResult.FAILURE, CronJobStatus.ABORTED);
		}
	}



	/**
	 * getPreviousYearDate method. 
	 *  
	 * @param value the days
	 */
	public static Date getPreviousYearDate(final int days)
	{
		final Calendar cal = Calendar.getInstance();

		cal.add(Calendar.YEAR, days);
		final Date configDate = cal.getTime();

		return configDate;
	}

	/**
	 * getCreationTimeHistory method. 
	 *  
	 * @param value the cronStatus
	 */
	private List<Object> getCreationTimeHistory(boolean cronStatus) {

		Date creationTimeHistory = null;
		final String cronJobCode = Config.getParameter(CRON_JOB_CODE);
		final List<CronJobHistoryModel> cronJobHistoryModels = cronJobHistoryService.getCronJobHistoryBy(cronJobCode);
		final String valueOfPrevYear = Config.getParameter(CONFIGURABLE_PREV_YEAR);
		List<Object> listOfObject = null;
		try {
			if (null != cronJobHistoryModels && !Collections.isEmpty(cronJobHistoryModels) && cronJobHistoryModels.size() > 1)
			{
				creationTimeHistory = cronJobHistoryModels.get(cronJobHistoryModels.size() - 2).getEndTime();
				
				if(creationTimeHistory==null)
				{
					cronStatus=true;
				}
			}
			if (creationTimeHistory == null)
			{
				creationTimeHistory = getPreviousYearDate(Integer.parseInt((valueOfPrevYear)));
			}
			listOfObject = new ArrayList<>();
			listOfObject.add(creationTimeHistory);
			listOfObject.add(cronStatus);
		} 
		catch (NumberFormatException e) {
			LOG.error("Getting error occur while fetching cron history time" + e);
		}
		
		return listOfObject;
	}



	public GamificationEventPointsService getGamificationEventPointsService() {
		return gamificationEventPointsService;
	}



	public void setGamificationEventPointsService(GamificationEventPointsService gamificationEventPointsService) {
		this.gamificationEventPointsService = gamificationEventPointsService;
	}
	
	
	
}