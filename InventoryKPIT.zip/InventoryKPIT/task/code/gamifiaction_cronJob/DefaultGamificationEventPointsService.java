/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2019 SAP SE
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * Hybris ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with SAP Hybris.
 */
package com.gamification.core.service.impl;

import java.util.List;

import javax.annotation.Resource;

import org.apache.log4j.Logger;
import org.springframework.util.Assert;

import com.gamification.core.dao.GamificationEventPointsDao;
import com.gamification.core.events.LoyaltyProgramEvent;
import com.gamification.core.service.GamificationEventPointsService;
import com.gamification.core.service.LoyaltyProgramEventService;

import de.hybris.platform.basecommerce.model.site.BaseSiteModel;
import de.hybris.platform.core.PK;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.event.EventService;
import de.hybris.platform.servicelayer.exceptions.ModelSavingException;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.user.UserService;
import de.hybris.platform.store.BaseStoreModel;

/**
 * mj
 */
public class DefaultGamificationEventPointsService implements GamificationEventPointsService {

	private final static Logger LOG = Logger.getLogger(DefaultGamificationEventPointsService.class.getName());

	@Resource
	private UserService userService;

	private ModelService modelService;

	@Resource
	GamificationEventPointsDao gamificationEventPointsDao;

	@Resource
	LoyaltyProgramEventService loyaltyProgramEventService;

	@Override
	public void saveCustomerBonusPoints(List<Object> fromDate, BaseSiteModel site, BaseStoreModel baseStore) {
		int finalPoints = 0;

		final List<Object> resOfPoints = gamificationEventPointsDao.getCurrentTotalEventPoints(fromDate);
		Assert.notNull(resOfPoints, "Overall Event listOfRecords cannot be null.");

		for (final Object customerAndPointList : resOfPoints) {
			try {
				final List<Object> customerAndPoint = (List<Object>) customerAndPointList;
				final String customerPK = (String) customerAndPoint.get(0);
				final String customerPoints = (String) customerAndPoint.get(1);
				final CustomerModel customerModel = modelService.get(PK.parse(customerPK));

				if (customerModel.getMonthlyBonusPoints() != null) {
					finalPoints = customerModel.getMonthlyBonusPoints().intValue() + Integer.parseInt(customerPoints);

					if (fromDate.get(1).equals(true)) {
						finalPoints = Integer.parseInt(customerPoints);
					}

				} else {
					finalPoints = Integer.parseInt(customerPoints);
				}

				customerModel.setMonthlyBonusPoints(finalPoints);
				modelService.save(customerModel);

				getLoyaltyProgramEventService().initializeEvent(new LoyaltyProgramEvent(), customerModel, site, baseStore);

			} 
			catch (final NumberFormatException e) 
			{
				LOG.error("Getting error occur while fetching points" + e);
			} 
			catch (final ModelSavingException e)
			{
				LOG.error("Getting error occur while fatching customer from model service" + e);
			}
		}
	}

	public ModelService getModelService() {
		return modelService;
	}

	public void setModelService(final ModelService modelService) {
		this.modelService = modelService;
	}

	public UserService getUserService() {
		return userService;
	}

	public void setUserService(final UserService userService) {
		this.userService = userService;
	}

	public GamificationEventPointsDao getGamificationEventPointsDao() {
		return gamificationEventPointsDao;
	}

	public void setGamificationEventPointsDao(GamificationEventPointsDao gamificationEventPointsDao) {
		this.gamificationEventPointsDao = gamificationEventPointsDao;
	}

	public LoyaltyProgramEventService getLoyaltyProgramEventService() {
		return loyaltyProgramEventService;
	}

	public void setLoyaltyProgramEventService(LoyaltyProgramEventService loyaltyProgramEventService) {
		this.loyaltyProgramEventService = loyaltyProgramEventService;
	}


	
}
