/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2019 SAP SE
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * Hybris ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with SAP Hybris.
 */
package com.gamification.core.dao.impl;

import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.util.Config;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import com.gamification.core.dao.GamificationEventPointsDao;
import com.gamification.core.model.EventRecordModel;


/**
 * MJ
 */
public class DefaultGamificationEventPointsDao implements GamificationEventPointsDao
{

	private static final String CONFIGURABLE_MONTH = "cron.gamification.config.month";

	@Resource(name = "flexibleSearchService")
	private FlexibleSearchService flexibleSearchService;


	@Override
	public List<Object> getCurrentTotalEventPoints(List<Object> fromDate)
	{

		final String valueOfConfigMonth = Config.getParameter(CONFIGURABLE_MONTH);

		final String frmDate = dateInStringFormat(fromDate.get(0));
		final String toDate = beforeCurrentDate(Integer.parseInt(valueOfConfigMonth));

		final Map<String, Object> params = new HashMap<String, Object>();
		final StringBuilder sql = new StringBuilder();
		params.put("startDate", frmDate);
		params.put("endDate", toDate);

		sql.append("select {e.customer} , sum({e.pointsEarned}) from {").append(EventRecordModel._TYPECODE + " as e}")
				.append(" where TO_CHAR({e.eventDate},'YYYY-MM-DD') >=?startDate and TO_CHAR({e.eventDate},'YYYY-MM-DD') <=?endDate")
				.append(" GROUP BY {e.customer}");

		final FlexibleSearchQuery query = new FlexibleSearchQuery(sql.toString());
		query.setResultClassList(Arrays.asList(String.class, String.class));
		query.getQueryParameters().putAll(params);

		return getFlexibleSearchService().search(query).getResult();

	}

	public FlexibleSearchService getFlexibleSearchService()
	{
		return flexibleSearchService;
	}

	public void setFlexibleSearchService(final FlexibleSearchService flexibleSearchService)
	{
		this.flexibleSearchService = flexibleSearchService;
	}

	// fatching before one day date
	public static String beforeCurrentDate(final int days)
	{
		final Calendar cal = Calendar.getInstance();

		final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		cal.add(Calendar.DATE, days);
		final Date configDate = cal.getTime();
		final String toDate = dateFormat.format(configDate);

		return toDate;
	}

	// Formatting date to string
	public static String dateInStringFormat(final Object fromDate)
	{
		final DateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
		final String lastExecutionDate = dateFormat.format(fromDate);

		return lastExecutionDate;
	}
}
