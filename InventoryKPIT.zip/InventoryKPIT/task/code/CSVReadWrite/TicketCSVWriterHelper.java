/**
 *
 */
package com.birlasoft.training.core.util;


import de.hybris.platform.util.CSVWriter;
import de.hybris.platform.util.Config;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.birlasoft.training.core.model.TicketModel;


/**
 * @author nitins5
 *
 */
public class TicketCSVWriterHelper
{


	public static void writeTicketInCSVFile(final List<TicketModel> ticketList)
	{
		final String CSV_FILE_PATH = Config.getParameter("CSV_FILE_PATH") + "result" + System.currentTimeMillis() + ".csv";
		final File file = new File(CSV_FILE_PATH);
		try
		{
			final FileWriter outputfile = new FileWriter(file);
			final CSVWriter writer = new CSVWriter(outputfile);

			writer.setFieldseparator(',');


			final List list = new ArrayList();

			final Map map1 = new HashMap();
			map1.put(0, Config.getParameter("txt_Ticket_Number"));
			map1.put(1, Config.getParameter("txt_Ticket_Date"));
			map1.put(2, Config.getParameter("txt_Passenger_Name"));
			map1.put(3, Config.getParameter("txt_Bus_Number"));
			map1.put(4, Config.getParameter("txt_Stopage_From"));
			map1.put(5, Config.getParameter("txt_Stopage_To"));
			map1.put(6, Config.getParameter("txt_Total_Fare"));
			map1.put(7, Config.getParameter("txt_Seat_Number"));
			list.add(map1);


			for (int i = 0; i < ticketList.size(); i++)
			{
				final Map map = new HashMap();
				map.put(0, " " + ticketList.get(i).getTicketNo());
				map.put(1, " " + CalenderHelper.convertDate(ticketList.get(i).getTicketDate()));
				map.put(2, " " + ticketList.get(i).getPassenger().getName());
				map.put(3, " " + ticketList.get(i).getBus().getBusNo());
				map.put(4, " " + ticketList.get(i).getStopage().getFrom());
				map.put(5, " " + ticketList.get(i).getStopage().getTo());
				map.put(6, " " + ticketList.get(i).getTotalFare());
				map.put(7, " " + ticketList.get(i).getSeatNo());
				list.add(map);
			}
			writer.write(list);
			System.out.println("Successfully print:::::");

			writer.close();
		}
		catch (final IOException e)
		{
			e.printStackTrace();
		}
	}





}
