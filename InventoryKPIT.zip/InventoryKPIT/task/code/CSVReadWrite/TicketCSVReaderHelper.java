/**
 *
 */
package com.birlasoft.training.core.util;

import de.hybris.platform.util.CSVReader;
import de.hybris.platform.util.Config;

import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


/**
 * @author nitins5
 *
 */
public class TicketCSVReaderHelper
{

	public List<Map<Integer, String>> readTicketFromCSV()
	{
		final List<Map<Integer, String>> csvData = new ArrayList<>();
		try
		{
			final String CSV_READER_FILE_PATH = Config.getParameter("CSV_READER_FILE_PATH") + "pricereadyreckoner.csv";
			final File file = new File(CSV_READER_FILE_PATH);

			final FileReader fileReader = new FileReader(file);

			final CSVReader csvReader = new CSVReader(fileReader);


			while (csvReader.readNextLine())
			{
				final Map<Integer, String> map11 = csvReader.getLine();
				csvData.add(map11);

			}

		}
		catch (final Exception e)
		{
			e.printStackTrace();
		}

		return csvData;
	}


}
