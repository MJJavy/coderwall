package com.safholland.core.interceptors;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.safholland.core.constants.SafhollandCoreConstants;
import com.safholland.core.model.AssemblyHotspotMappingModel;
import com.safholland.core.services.impl.DefaultSAFProductService;

import de.hybris.platform.catalog.CatalogVersionService;
import de.hybris.platform.catalog.model.CatalogVersionModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.product.ProductService;
import de.hybris.platform.servicelayer.interceptor.InterceptorContext;
import de.hybris.platform.servicelayer.interceptor.InterceptorException;
import de.hybris.platform.servicelayer.interceptor.PrepareInterceptor;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.util.CSVWriter;
import de.hybris.platform.util.Config;
/**
 * The Class AssemblyHotspotMappingPrepareInterceptor.
 *
 * @author muralik
 */
public class AssemblyHotspotMappingPrepareInterceptor implements PrepareInterceptor<AssemblyHotspotMappingModel> {

	private static final Logger LOG = LoggerFactory.getLogger(DefaultSAFProductService.class);
	
	/** The Constant PRODUCT_CSV_FILE_NAME. */
	public static final String ASSEMBLY_PRODUCT_CSV_FILE = "safhollandcore.product.noexist.file";
	
	/** The Constant CSV_SUFFIX. */
	public static final String CSV_SUFFIX = ".csv";

	/** The Constant HYBRIS_TEMP_DIR. */
	private static final String CSV_FILE_DIR = "temp.dir";

	/** The Constant LOCAL_FOR_LOCAL_BACKSLASH_FOR_PATH. */
	private static final String BACKSLASH_FOR_PATH = "/";
	
	/** The product service. */
	@Resource
	private ProductService productService;

	/** The model service. */
	@Resource
	private ModelService modelService;

	/** The catalog version service. */
	@Resource
	private CatalogVersionService catalogVersionService;

	/**
	 * Overridden method for PrepareInterceptor of AssemblyHotspotMapping.
	 *
	 * @param assemblyHotspotMappingModel AssemblyHotspotMappingModel
	 * @param interceptorContext          InterceptorContext
	 * @throws InterceptorException the interceptor exception
	 */
	@Override
	public void onPrepare(AssemblyHotspotMappingModel assemblyHotspotMappingModel,
			InterceptorContext interceptorContext) throws InterceptorException {
		final CatalogVersionModel catalogVersionModel = catalogVersionService.getCatalogVersion(
				SafhollandCoreConstants.PRODUCT_CATALOG_SAFHOLLAND_NA, SafhollandCoreConstants.VERSION_STAGED);
		ProductModel productModel = null;
		
		try {
			productModel = productService.getProductForCode(catalogVersionModel,
					assemblyHotspotMappingModel.getAssemblyCode());
		} catch (Exception e) {
			
			String filePath=Config.getParameter(CSV_FILE_DIR)+ BACKSLASH_FOR_PATH +Config.getParameter(ASSEMBLY_PRODUCT_CSV_FILE)+ CSV_SUFFIX;
			Path path = Paths.get(filePath);
			final File file = new File(filePath);
			
			if(file.exists())
			{
				appendCsvContentAndWrite(path,e.getMessage());
			}
			else
			{
				try(FileWriter fileWriter = new FileWriter(file)) 
				{
				writeExceptionInCSVFile(fileWriter,e.getMessage());
				fileWriter.close();
				} 
				catch (IOException e1) {
					LOG.error("Getting error while csv data write in file");
				}
			}
			LOG.error("Getting error while product not exist in assembly hot spot model");
		}
		if (productModel != null) {
			productModel.setAsm(true);
			modelService.save(productModel);
			modelService.refresh(productModel);

		} else {
			throw new InterceptorException(Config.getParameter(SafhollandCoreConstants.ASSEMBLY_PRODUCT_UNAVAILABLE));
		}

	}
	
	/**
	 * write csv file from hot spot data not exist.
	 *
	 *  @param code the FileWriter fileWriter
	 *  @param code the String messageContent
	 *  
	 */
	public static void writeExceptionInCSVFile(final FileWriter fileWriter, String messageContent)
	{
		try (CSVWriter csvWriter = new CSVWriter(fileWriter);) {
			csvWriter.setFieldseparator(',');

			final List list = new ArrayList();

			final Map headerField = new HashMap();
			headerField.put(0, "Assembly_Code");
			list.add(headerField);

			final Map cellData = new HashMap();
			cellData.put(0, " " + messageContent);
			list.add(cellData);

			csvWriter.write(list);
			
		} catch (final IOException e) {
			LOG.error("Getting error while set the product data in csv file");
		}
	}
	
	/**
	 * append in existing CSV file .
	 *
	 *  @param code thePath path
	 *  @param code the String content
	 *  
	 */
	private static void appendCsvContentAndWrite(final Path path,String content)
	{
		try (BufferedWriter writer = 
	            Files.newBufferedWriter(path, 
	                    StandardOpenOption.APPEND)) 
		{
			 writer.newLine();
			 writer.write(content);
		}
		catch (Exception e) {
			LOG.error("Getting error while append data in csv file");
		}
	}
}
