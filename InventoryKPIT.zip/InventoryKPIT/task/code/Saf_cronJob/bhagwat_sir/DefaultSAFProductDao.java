package com.safholland.core.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.safholland.core.dao.SAFProductDao;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.internal.dao.DefaultGenericDao;

public class DefaultSAFProductDao extends DefaultGenericDao<ProductModel> implements SAFProductDao {

	public DefaultSAFProductDao(String typecode) {
		super(ProductModel._TYPECODE);
	}

	/**
	 * Fetch assmebly codes product.
	 *
	 * 
	 * @return the List<Object>
	 */
	@Override
	public List<ProductModel> getAllASMProduct(boolean status) {

		int asmStatus = status ? 1 : 0;

		final Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("asmStatus", String.valueOf(asmStatus));
		final List<ProductModel> prodModelList = find(parameterMap);
	/*	if (CollectionUtils.isNotEmpty(customCpqConfigurationModelsModelList))
		{
			return customCpqConfigurationModelsModelList;
		}*/
		return prodModelList;
	}


}
