package com.safholland.core.job;

import javax.annotation.Resource;

import com.safholland.core.services.SAFProductService;

import de.hybris.platform.cronjob.enums.CronJobResult;
import de.hybris.platform.cronjob.enums.CronJobStatus;
import de.hybris.platform.cronjob.model.CronJobModel;
import de.hybris.platform.servicelayer.cronjob.AbstractJobPerformable;
import de.hybris.platform.servicelayer.cronjob.PerformResult;



/**
 * The Job Saved opentextMedia data with Height and Width by reading SAF_PRODUCT_CSV File of assetName
 * 
 * @MJ
 */
public class SAFExplodedImageViewJobPerformable extends AbstractJobPerformable<CronJobModel> {

	@Resource
	private SAFProductService safProductService;

	@Override
	public PerformResult perform(CronJobModel cronJob) {
		
			getSafProductService().getAllAssemblyProduct(true);
			return new PerformResult(CronJobResult.SUCCESS, CronJobStatus.FINISHED);
	}

	public SAFProductService getSafProductService() {
		return safProductService;
	}

	public void setSafProductService(SAFProductService safProductService) {
		this.safProductService = safProductService;
	}
	
}
