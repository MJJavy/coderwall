package com.safholland.core.services.impl;

import java.io.File;
import java.io.FileReader;
import java.util.HashMap;
import java.awt.image.BufferedImage;
import java.net.URL;






import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.imageio.ImageIO;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.util.StringUtils;

import com.opentext.hybris.otmmconnector.model.OpenTextMediaModel;
import com.safholland.core.dao.SAFProductDao;
import com.safholland.core.services.SAFProductService;

import de.hybris.platform.core.model.media.MediaModel;
import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.util.CSVReader;
import de.hybris.platform.util.Config;




/**
 * The Class DefaultSAFProductService.
 *
 * @author MJ
 */
public class DefaultSAFProductService implements SAFProductService {

	/** The Constant PRODUCT_CSV_FILE_NAME. */
	public static final String PRODUCT_CSV_FILE_NAME = "safhollandcore.product.file";

	/** The Constant CSV_SUFFIX. */
	public static final String PDF_SUFFIX = ".csv";

	/** The Constant HYBRIS_TEMP_DIR. */
	private static final String PRODUCT_CSV_FILE = "temp.dir";

	/** The Constant LOCAL_FOR_LOCAL_BACKSLASH_FOR_PATH. */
	private static final String BACKSLASH_FOR_PATH = "/";

	private static final Logger LOG = LoggerFactory.getLogger(DefaultSAFProductService.class);

	@Resource
	private SAFProductDao safProductDao;

	private ModelService modelService;

	/**
	 * Saved the AllAssemblyProduct with ASM true.
	 *
	 */
	@Override
	public void getAllAssemblyProduct(boolean asmStatus) {

		List<ProductModel> assemblyProduct = getSafProductDao().getAllASMProduct(asmStatus);
		Map<String, Map<String, String>> csvProductData = readProductFromCSV(Config.getParameter(PRODUCT_CSV_FILE)
				+ BACKSLASH_FOR_PATH + Config.getParameter(PRODUCT_CSV_FILE_NAME) + PDF_SUFFIX);
		MediaModel mediaModel = null;

		for (final ProductModel productModel : assemblyProduct) {
			try {
				if (productModel.getExplodedImage() != null) {
					mediaModel = productModel.getExplodedImage();

					if (mediaModel instanceof OpenTextMediaModel) {
						saveTextMediaData(csvProductData, mediaModel);

					if(null!=mediaModel.getURL()){
                        URL url = new URL(mediaModel.getURL());
                        final BufferedImage imageInstance = ImageIO.read(url);
                        mediaModel.setWidth(imageInstance.getWidth());
                        mediaModel.setHeight(imageInstance.getHeight());
                        getModelService().save(mediaModel);
					}
					
				}
			} catch (Exception e) {
				LOG.error("Getting error while fatching product");
			}
		}
	}

	/**
	 * Save Height and width in OpenTextMediaModel by reading asset file name
	 * from CSV
	 * 
	 * @param code
	 *            the Map and MediaModel
	 * 
	 */
	private void saveTextMediaData(Map<String, Map<String, String>> csvProductData, MediaModel mediaModel) {
		OpenTextMediaModel openTextMediaModel = (OpenTextMediaModel) mediaModel;
		String assetName = openTextMediaModel.getOtmmAssetName();
		if (null != csvProductData.get(assetName)) {

			for (Entry<String, String> entry : csvProductData.get(assetName).entrySet()) {
				mediaModel.setWidth(Integer.parseInt(entry.getKey()));
				mediaModel.setHeight(Integer.parseInt(entry.getValue()));
				getModelService().save(mediaModel);
			}

		}
	}

	/**
	 * Read the Product from CSV in Default SAF Product service.
	 *
	 * @return the Map of String with Map of string pair
	 */
	public static Map<String, Map<String, String>> readProductFromCSV(String csvPath) {
		Map<String, Map<String, String>> csvData = new HashMap<>();
		try {
			File file = new File(csvPath);

			final FileReader fileReader = new FileReader(file);

			final CSVReader csvReader = new CSVReader(fileReader);

			while (csvReader.readNextLine()) {
				final Map<Integer, String> map11 = csvReader.getLine();

				String[] tokenizedStringArray = StringUtils.tokenizeToStringArray(map11.get(0), ",");

				Map<String, String> widthAndHeight = new HashMap<>();
				widthAndHeight.put(tokenizedStringArray[2], tokenizedStringArray[3]);
				csvData.put(tokenizedStringArray[4], widthAndHeight);

			}

		} catch (final Exception e) {
			LOG.error("Getting error while reading csv");
		}

		return csvData;
	}

	public SAFProductDao getSafProductDao() {
		return safProductDao;
	}

	public void setSafProductDao(SAFProductDao safProductDao) {
		this.safProductDao = safProductDao;
	}

	public ModelService getModelService() {
		return modelService;
	}

	public void setModelService(ModelService modelService) {
		this.modelService = modelService;
	}
}