package com.safholland.core.dao;

import java.util.List;

import de.hybris.platform.core.model.product.ProductModel;


/**
 * MJ
 */
public interface SAFProductDao
{

	public  List<ProductModel> getAllASMProduct(boolean status);

}
