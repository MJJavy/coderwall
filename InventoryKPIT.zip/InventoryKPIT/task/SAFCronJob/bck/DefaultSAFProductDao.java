package com.safholland.core.dao.impl;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.collections4.CollectionUtils;

import com.safholland.core.dao.SAFProductDao;

import de.hybris.platform.core.model.product.ProductModel;
import de.hybris.platform.servicelayer.search.FlexibleSearchQuery;
import de.hybris.platform.servicelayer.search.FlexibleSearchService;
import de.hybris.platform.servicelayer.search.SearchResult;

public class DefaultSAFProductDao implements SAFProductDao {

	private FlexibleSearchService flexibleSearchService;

	/**
	 * Fetch all assembly product.
	 *
	 * 
	 * @return the List<ProductModel>
	 */
	@Override
	public List<ProductModel> getAllASMProduct(boolean status) {

		int asmStatus = status ? 1 : 0;

		final Map<String, String> parameterMap = new HashMap<>();
		parameterMap.put("asmStatus", String.valueOf(asmStatus));
		
		final String query = "SELECT {pk} FROM {"+ ProductModel._TYPECODE + " } WHERE {" + ProductModel.ASM + "} =?asmStatus";
		
		final FlexibleSearchQuery flexibleSearchQuery = new FlexibleSearchQuery(query, parameterMap);
		final SearchResult<ProductModel> searchResult = getFlexibleSearchService().search(flexibleSearchQuery);
		if(CollectionUtils.isNotEmpty(searchResult.getResult())){
			return searchResult.getResult();
		}
		else{
			return null;
		}
	}
	
	public FlexibleSearchService getFlexibleSearchService() {
		return flexibleSearchService;
	}
	public void setFlexibleSearchService(FlexibleSearchService flexibleSearchService) {
		this.flexibleSearchService = flexibleSearchService;
	}

}
