setTimeout(function(){
$("textarea").attr('maxlength','50');
}, 150);