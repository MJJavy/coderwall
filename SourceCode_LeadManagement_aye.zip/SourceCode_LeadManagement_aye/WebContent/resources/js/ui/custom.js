setTimeout(function(){
$("textarea").attr('maxlength','20');
}, 150);