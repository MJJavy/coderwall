package com.qc.starter.dao;

import com.qc.starter.dto.PersonListDto;

public interface AllocateCasesDaoInf {

	public void allocate_cases(PersonListDto persondto);
}
