package com.qc.starter.dao;


public interface MasterForMobileDao {

	public String getAllMasters(String value);
	public  String saveAgentSummary(String requestJson);
	public  String getAgentSummary(String requestJson);
}
