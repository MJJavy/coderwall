package com.qc.starter.dao;


public interface NewLeadDao {

	public String getLeadId();
	public String createLead(String params);

}
