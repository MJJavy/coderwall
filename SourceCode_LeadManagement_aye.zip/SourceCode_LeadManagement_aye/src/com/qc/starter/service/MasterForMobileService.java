package com.qc.starter.service;



public interface MasterForMobileService {

	public String getAllMasters(String value);
	public  String saveAgentSummary(String requestJson);
	public  String getAgentSummary(String requestJson);
	
}
