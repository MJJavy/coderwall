package com.qc.starter.service;

import com.qc.starter.dto.PersonListDto;

public interface AllocateCases {
  public void allocateCases(PersonListDto persondto);
}
