package com.qc.starter.service;

import com.qc.starter.dto.ContactDto;


public interface ActionService {

	public String saveCaseAction(ContactDto contactDto);
}
