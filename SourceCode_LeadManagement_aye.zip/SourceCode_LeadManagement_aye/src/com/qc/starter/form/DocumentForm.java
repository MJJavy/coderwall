package com.qc.starter.form;

import java.util.List;

import com.qc.starter.dto.DocumentDto;

public class DocumentForm {


	List<DocumentDto> documentList;

	public List<DocumentDto> getDocumentList() {
		return documentList;
	}

	public void setDocumentList(List<DocumentDto> documentList) {
		this.documentList = documentList;
	}



}
