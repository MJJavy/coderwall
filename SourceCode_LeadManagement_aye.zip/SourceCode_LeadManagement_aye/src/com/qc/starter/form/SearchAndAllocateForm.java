package com.qc.starter.form;

import java.util.List;

import com.qc.starter.dto.SearchAndAllocateDto;



public class SearchAndAllocateForm {
	private List<SearchAndAllocateDto> searchAndAllocateDto;

	public List<SearchAndAllocateDto> getSearchAndAllocateDto() {
		return searchAndAllocateDto;
	}

	public void setSearchAndAllocateDto(
			List<SearchAndAllocateDto> searchAndAllocateDto) {
		this.searchAndAllocateDto = searchAndAllocateDto;
	}



}
