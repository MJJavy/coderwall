package com.qc.starter.dto;

import org.springframework.stereotype.Component;

@Component
public class UserDto {

	private String userName;
	private String password;
	private String ipaddress;

	public String getIpaddress() {
		return ipaddress;
	}
	public void setIpaddress(String ipaddress) {
		this.ipaddress = ipaddress;
	}
	public UserDto(){

	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}

}
