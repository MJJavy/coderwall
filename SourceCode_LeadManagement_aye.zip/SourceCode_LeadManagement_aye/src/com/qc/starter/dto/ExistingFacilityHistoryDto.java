/*package com.qc.starter.dto;

public class ExistingFacilityHistoryDto {

	private String checkRow;
	private String existingFacilityId;
	private String existingFacility;
	private String existingFacilityBankId;
	private String existingFacilityBank;
	private String existingFacilityLoanCcAmout;
	private String existingFacilityEmiCcOutstanding;
	private String existingFacilityTenorBalanceMonths;
	private String existingFacilityRemarks;


	public String getCheckRow() {
		return checkRow;
	}
	public void setCheckRow(String checkRow) {
		this.checkRow = checkRow;
	}
	public String getExistingFacilityBankId() {
		return existingFacilityBankId;
	}
	public void setExistingFacilityBankId(String existingFacilityBankId) {
		this.existingFacilityBankId = existingFacilityBankId;
	}
	public String getExistingFacilityId() {
		return existingFacilityId;
	}
	public void setExistingFacilityId(String existingFacilityId) {
		this.existingFacilityId = existingFacilityId;
	}
	public String getExistingFacility() {
		return existingFacility;
	}
	public void setExistingFacility(String existingFacility) {
		this.existingFacility = existingFacility;
	}
	public String getExistingFacilityBank() {
		return existingFacilityBank;
	}
	public void setExistingFacilityBank(String existingFacilityBank) {
		this.existingFacilityBank = existingFacilityBank;
	}
	public String getExistingFacilityLoanCcAmout() {
		return existingFacilityLoanCcAmout;
	}
	public void setExistingFacilityLoanCcAmout(String existingFacilityLoanCcAmout) {
		this.existingFacilityLoanCcAmout = existingFacilityLoanCcAmout;
	}
	public String getExistingFacilityEmiCcOutstanding() {
		return existingFacilityEmiCcOutstanding;
	}
	public void setExistingFacilityEmiCcOutstanding(
			String existingFacilityEmiCcOutstanding) {
		this.existingFacilityEmiCcOutstanding = existingFacilityEmiCcOutstanding;
	}
	public String getExistingFacilityTenorBalanceMonths() {
		return existingFacilityTenorBalanceMonths;
	}
	public void setExistingFacilityTenorBalanceMonths(
			String existingFacilityTenorBalanceMonths) {
		this.existingFacilityTenorBalanceMonths = existingFacilityTenorBalanceMonths;
	}
	public String getExistingFacilityRemarks() {
		return existingFacilityRemarks;
	}
	public void setExistingFacilityRemarks(String existingFacilityRemarks) {
		this.existingFacilityRemarks = existingFacilityRemarks;
	}

}
 */