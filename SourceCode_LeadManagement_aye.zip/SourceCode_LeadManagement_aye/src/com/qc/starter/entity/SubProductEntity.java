/*package com.qc.starter.entity;

import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name="QM_SUB_PRODUCT", schema="QC_PROSPECT_MASTER")
public class SubProductEntity {

}
*/