package com.qc.starter.entity;



public class DevloperEntity {
	//@Column(name="DEVELOPER_ID")
	private String devloperId;
	//@Column(name="DEVELOPER_NAME")
	private String devloperName;
	public String getDevloperId() {
		return devloperId;
	}
	public void setDevloperId(String devloperId) {
		this.devloperId = devloperId;
	}
	public String getDevloperName() {
		return devloperName;
	}
	public void setDevloperName(String devloperName) {
		this.devloperName = devloperName;
	} 



}


