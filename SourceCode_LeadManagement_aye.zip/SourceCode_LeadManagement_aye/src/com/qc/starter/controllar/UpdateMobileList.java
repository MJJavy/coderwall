package com.qc.starter.controllar;

public class UpdateMobileList {
	

}
