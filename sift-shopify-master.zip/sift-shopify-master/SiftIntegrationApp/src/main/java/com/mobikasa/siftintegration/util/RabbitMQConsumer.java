package com.mobikasa.siftintegration.util;

import com.mobikasa.siftintegration.dto.BillingQueueMessage;
import com.mobikasa.siftintegration.service.BillingService;
import org.springframework.amqp.rabbit.annotation.RabbitListener;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class RabbitMQConsumer {

    @Autowired
    private BillingService billingService;

    @RabbitListener(queues = "${sift.order.billing.queue}")
    public void processOrderBilling(BillingQueueMessage billingQueueMessage){
        billingService.processOrderBilling(billingQueueMessage.getOrderId(),billingQueueMessage.getShopId());
    }
}