package com.mobikasa.siftintegration.entity;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * The persistent class for the usermaster database table.
 */
@Entity
@Table(name = "orders")
public class OrderEntity {

    private static final long serialVersionUID = 1L;

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private Long id;

    @Column(name = "order_id")
    private String orderId;

    @Column(name = "shop_id")
    private Long shopId;

    @Column(name = "orderno")
    private String orderNo;

    @Column(name = "customer_name")
    private String customerName;

    @Column(name = "amount")
    private BigDecimal amount;

    @Column(name = "sift_score")
    private BigDecimal siftScore;

    @Column(name = "action_taken")
    private String actionTaken;

    @Column(name = "customer_id")
    private String customerId;

    @Column(name = "status")
    private int status;

    @Column(name = "email")
    private String email;

    @Column(name = "order_crt_date")
    private Date orderCrtDate;

    @Column(name = "order_upd_date")
    private Date orderUpdDate;

    @Column(name = "crt_date")
    private Date crtDate;

    @Column(name = "upd_date")
    private Date updDate;

    private String decision;

    private int environment;

    @Column(name = "order_billed")
    private int orderBilled;

    @Column(name = "tag")
    private String tag;

    @Column(name = "gateway")
    private String gateway;

    @Column(name = "browser_ip")
    private String browserIp;

    @Column(name = "accept_language")
    private String acceptLanguage;

    @Column(name = "user_agent")
    private String userAgent;

    public String getDecision() {
        return decision;
    }

    public void setDecision(String decision) {
        this.decision = decision;
    }

    public int getEnvironment() {
        return environment;
    }

    public void setEnvironment(int environment) {
        this.environment = environment;
    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getOrderNo() {
        return orderNo;
    }

    public void setOrderNo(String orderNo) {
        this.orderNo = orderNo;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public BigDecimal getAmount() {
        return amount;
    }

    public void setAmount(BigDecimal amount) {
        this.amount = amount;
    }

    public BigDecimal getSiftScore() {
        return siftScore;
    }

    public void setSiftScore(BigDecimal siftScore) {
        this.siftScore = siftScore;
    }

    public String getActionTaken() {
        return actionTaken;
    }

    public void setActionTaken(String actionTaken) {
        this.actionTaken = actionTaken;
    }

    public String getCustomerId() {
        return customerId;
    }

    public void setCustomerId(String customerId) {
        this.customerId = customerId;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Date getOrderCrtDate() {
        return orderCrtDate;
    }

    public void setOrderCrtDate(Date orderCrtDate) {
        this.orderCrtDate = orderCrtDate;
    }

    public Date getCrtDate() {
        return crtDate;
    }

    public void setCrtDate(Date crtDate) {
        this.crtDate = crtDate;
    }

    public Date getUpdDate() {
        return updDate;
    }

    public void setUpdDate(Date updDate) {
        this.updDate = updDate;
    }

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public Date getOrderUpdDate() {
        return orderUpdDate;
    }

    public void setOrderUpdDate(Date orderUpdDate) {
        this.orderUpdDate = orderUpdDate;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public int getOrderBilled() {
        return orderBilled;
    }

    public void setOrderBilled(int orderBilled) {
        this.orderBilled = orderBilled;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getGateway() {
        return gateway;
    }

    public void setGateway(String gateway) {
        this.gateway = gateway;
    }

    public String getBrowserIp() {
        return browserIp;
    }

    public void setBrowserIp(String browserIp) {
        this.browserIp = browserIp;
    }

    public String getAcceptLanguage() {
        return acceptLanguage;
    }

    public void setAcceptLanguage(String acceptLanguage) {
        this.acceptLanguage = acceptLanguage;
    }

    public String getUserAgent() {
        return userAgent;
    }

    public void setUserAgent(String userAgent) {
        this.userAgent = userAgent;
    }
}