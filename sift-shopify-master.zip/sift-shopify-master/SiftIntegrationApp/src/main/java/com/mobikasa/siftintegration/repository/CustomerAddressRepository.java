package com.mobikasa.siftintegration.repository;


import com.mobikasa.siftintegration.entity.SiftCustomerAddressEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerAddressRepository extends JpaRepository<SiftCustomerAddressEntity, Long> {

    SiftCustomerAddressEntity findByCustomerId(Long customerId);
}

