package com.mobikasa.siftintegration.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.ShopifyUpdateOrder;
import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.consumer.DecisionConsumer;
import com.mobikasa.siftintegration.entity.DecisionEntity;
import com.mobikasa.siftintegration.entity.OrderEntity;
import com.mobikasa.siftintegration.entity.ShopDecisionId;
import com.mobikasa.siftintegration.entity.ShopifyDataEntity;
import com.mobikasa.siftintegration.repository.DecisionRepository;
import com.mobikasa.siftintegration.repository.OrderRepository;
import com.mobikasa.siftintegration.repository.SiftDataRepository;
import com.mobikasa.siftintegration.service.DecisionService;
import com.mobikasa.siftintegration.util.CommonUtil;
import com.siftscience.SiftClient;

@Service
public class DecisionServiceImpl implements DecisionService {

    @Autowired
    private ShopifyUpdateOrder shopifyUpdateOrder;
    @Autowired
    private DecisionRepository decisionRepository;
    @Autowired
    private DecisionConsumer decisionConsumer;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private SiftDataRepository siftDataRepository;
    @Autowired
    private ObjectMapper mapper;

    @Override
    public void processDecision(String decisionId, Long storeId, Long orderId) {
        try {
            System.out.println("Processiogn decision for"+storeId+","+orderId+","+decisionId);
            Optional<OrderEntity> orderEntity = orderRepository.findOneByOrderId(orderId.toString());
            SiftClient siftClient = CommonUtil.createSiftClient(storeId);
            if (orderEntity.isPresent() && decisionId!=null) {
                orderEntity.get().setDecision(orderEntity.get().getDecision() == null ? "" : orderEntity.get().getDecision().concat(":" + decisionId));
                orderRepository.save(orderEntity.get());
                DecisionEntity decisionEntity = checkAndUpdateDecisions(decisionId, storeId);
                if (SiftApplicationConstant.sentToShopifyDecisionsList.contains(decisionId) && orderEntity.get().getEnvironment() == 0
                		&& decisionEntity != null) {
                    shopifyUpdateOrder.updateShopifyOrder(storeId, orderId, null, "BLOCK");
                } else {
                	shopifyUpdateOrder.updateShopifyOrder(storeId, orderId, null, decisionEntity.getCategory());
                }

            }
            System.out.println("order or decison is null"+storeId+","+orderId+","+decisionId);
        } catch (Exception e) {
            e.printStackTrace();
        }

    }


    @Override
    public void saveWebhookData(Long shopId, Long orderId, String decisionData, String event) {
        ShopifyDataEntity siftDataEntity=new ShopifyDataEntity();
        try{
            siftDataEntity.setStoreId(Math.toIntExact(shopId));
            siftDataEntity.setOrderId(orderId.toString());
            siftDataEntity.setData(decisionData);
            siftDataEntity.setEvent(event);
            siftDataRepository.save(siftDataEntity);
        }catch(Exception e){
            e.printStackTrace();
        }
    }
    
    private DecisionEntity checkAndUpdateDecisions(String decisionId, Long shopId) {
        Optional<DecisionEntity> decisionEntity = null;
        if (decisionId != null) {
            decisionEntity = decisionRepository.findById(new ShopDecisionId(decisionId, shopId));
            if (!decisionEntity.isPresent()) {
                decisionConsumer.updateDecision(shopId);
                decisionEntity = decisionRepository.findById(new ShopDecisionId(decisionId, shopId));
                return decisionEntity.get();
            }
        else{
            decisionConsumer.updateDecision(shopId);
            decisionEntity = decisionRepository.findById(new ShopDecisionId(decisionId, shopId));
            return decisionEntity.get();
        }}
        return null;
    }
}
