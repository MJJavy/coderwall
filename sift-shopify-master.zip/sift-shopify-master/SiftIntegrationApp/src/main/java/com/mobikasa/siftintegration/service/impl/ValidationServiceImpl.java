package com.mobikasa.siftintegration.service.impl;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import com.mobikasa.siftintegration.entity.ShopEntity;
import com.mobikasa.siftintegration.entity.SiftConfigEntity;
import com.mobikasa.siftintegration.repository.SiftConfigRepository;
import com.mobikasa.siftintegration.service.ValidationService;
import com.mobikasa.siftintegration.util.Hmac;

@Service
public class ValidationServiceImpl implements ValidationService {

	@Autowired
	private SiftConfigRepository siftConfigRepository;
	
	@Value("${app.install.secretkey}")
	private String secretKey;

	
	@Override
	public boolean validateHmac(Map<String, String> headers, String data, ShopEntity shopEntity)
			throws Exception {
		
		String hmac = headers.get("x-shopify-hmac-sha256");
		return Hmac.checkHmac(data, hmac, secretKey);
	}
	

	@Override
	public boolean validateShopifyWebhook(Map<String, String> headers, String data, ShopEntity shopEntity)
			throws Exception {
		
		SiftConfigEntity siftConfig = siftConfigRepository.findByshopId(shopEntity.getId());
		if(siftConfig.getSiftEnable().equals("0")) {
			return false;
		}
		if(shopEntity.getStatus().equals("0") || shopEntity.getBillingApproveStatus().equals("0") || shopEntity.getCreditAvailable()==0) {
			return false;
		}
		
		return true;
	}

}