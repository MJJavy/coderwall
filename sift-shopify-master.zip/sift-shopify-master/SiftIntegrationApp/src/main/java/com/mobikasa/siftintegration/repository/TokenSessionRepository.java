package com.mobikasa.siftintegration.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.siftintegration.entity.TokenSessionEntity;

import java.util.List;

@Repository
public interface TokenSessionRepository extends CrudRepository<TokenSessionEntity, Long>{

    List<TokenSessionEntity> findByToken(String token);
}
