package com.mobikasa.siftintegration.consumer;

import java.util.*;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.dto.BillingAddress;
import com.mobikasa.siftintegration.dto.Order;
import com.mobikasa.siftintegration.entity.*;
import com.mobikasa.siftintegration.repository.*;
import com.siftscience.model.Address;
import com.siftscience.model.PaymentMethod;
import org.apache.http.HttpStatus;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mobikasa.siftintegration.constant.TransactionTypes;
import com.mobikasa.siftintegration.dto.Transaction;
import com.mobikasa.siftintegration.util.CommonUtil;
import com.siftscience.EventRequest;
import com.siftscience.EventResponse;
import com.siftscience.SiftClient;
import com.siftscience.model.TransactionFieldSet;
import org.springframework.util.StringUtils;

@Component
public class TransactionConsumer {

    @Autowired
    private SiftShopifyDataRepository shopifyDataRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private ObjectMapper mapper;
    @Autowired
    SiftConfigRepository siftConfigRepository;
    @Autowired
    OrderRepository orderRepository;
    @Autowired
    private TokenSessionRepository tokenSessionRepository;

    @Async("fixedThreadPool")
    public void createTransaction(Long id) {
        Transaction transaction = null;
        Gson g = new Gson();
        try {
            Optional<SiftDataEntity> shopifyDataEntity = shopifyDataRepository.findById(id);
            transaction = g.fromJson(shopifyDataEntity.get().getData(), Transaction.class);
            if (transaction != null) {
                saveTransaction(transaction, shopifyDataEntity.get().getStoreId());
            }
            if(transaction.getKind().equals("capture")){
                Optional<SiftDataEntity> siftDataEntity = shopifyDataRepository.findByOrderIdAndEvent(transaction.getOrder_id(),"Order Create");
                Order order = g.fromJson(siftDataEntity.get().getData(), Order.class);
                if (order != null) {
                    order = updateSessionId(order);
                    sendTransactions(order);
            }
        } }catch (Exception e) {
            e.printStackTrace();
        }
    }

    private Order updateSessionId(Order order) {
        Order updtedOrder = order;
        try {
            if (StringUtils.hasText(order.getCart_token())) {
                List<TokenSessionEntity> tokenSessionEntity = tokenSessionRepository.findByToken(order.getCart_token());
                updtedOrder.setSessionId(tokenSessionEntity.get(0).getSessionId());
            } else {
                updtedOrder.setSessionId("1234");
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return updtedOrder;
    }

    private EventResponse createTransactionInSift(SiftClient siftClient, TransactionEntity transactionEntity, String sessionId, String userId) {
        EventRequest request = null;
        EventResponse response = null;
        ObjectMapper Obj = new ObjectMapper();
        TransactionFieldSet transactionFieldSet = createTransactionFieldSet(userId, sessionId, transactionEntity);
        try {
            request = siftClient.buildRequest(transactionFieldSet);
            ApiLogEntity apiLog = CommonUtil.createApiLog("transaction", Obj.writeValueAsString(request.getFieldSet()), transactionEntity.getShopId(), "");
            response = request.send();
            CommonUtil.updateApiLog(apiLog, Obj.writeValueAsString(response.getBody()));
        } catch (Exception e) {
            e.printStackTrace();
            return response;
        }
        return response;
    }

    private TransactionFieldSet createTransactionFieldSet(String userId, String sessionId, TransactionEntity transactionEntity) {
        TransactionFieldSet transactionFieldSet=new TransactionFieldSet();
        PaymentMethod paymentMethod=createPaymentMethod(transactionEntity);
        Address address= createBillingAddress(transactionEntity);
        String declineCategory=getDeclineCategory(transactionEntity);
        try{
            transactionFieldSet.setUserId(userId);
            transactionFieldSet.setAmount(CommonUtil.parseLong(transactionEntity.getAmount())*SiftApplicationConstant.MICRO_CONVERTER);
            transactionFieldSet.setCurrencyCode(transactionEntity.getCurrency());
            transactionFieldSet.setSessionId(sessionId);
            transactionFieldSet.setTransactionType(transactionEntity.getTransactionType());
            transactionFieldSet.setTransactionStatus(transactionEntity.getTransactionStatus());
            transactionFieldSet.setOrderId(transactionEntity.getOrderId());
            transactionFieldSet.setTransactionId(transactionEntity.getTransactionId());
            transactionFieldSet.setUserEmail(transactionEntity.getEmail());
            transactionFieldSet.setBillingAddress(address);
            if(!paymentMethod.getCardBin().equals(""))
                transactionFieldSet.setPaymentMethod(paymentMethod);
            if(declineCategory!=null)
            transactionFieldSet.setDeclineCategory(declineCategory);
        }catch(Exception e){
            e.printStackTrace();
        }
        return transactionFieldSet;
    }

    private String getDeclineCategory(TransactionEntity transactionEntity) {
        if(transactionEntity.getErrorCode()!=null){
            return mappedErrorCode(transactionEntity.getErrorCode());
        }
        return null;
    }

    private String mappedErrorCode(String errorCode) {
        String mappedErrorCode=null;
        switch (errorCode) {
            case "incorrect_number":
            case "invalid_number":
            case "invalid_expiry_date":
            case "invalid_cvc":
            case "incorrect_zip":
            case "incorrect_address":
                mappedErrorCode=  "$invalid";
                break;
            case "expired_card":
                mappedErrorCode=  "$expired";
                break;
            case "incorrect_cvc":
                mappedErrorCode=  "$invalid_verification";
                break;
            case "card_declined":
                mappedErrorCode=  "$bank_decline";
            break;
            case "processing_error":
            case "call_issuer":
            case "pick_up_card":
                mappedErrorCode=  "$other";
            break;
            default:
                mappedErrorCode=  "$other";
                break;
        }
        return   mappedErrorCode;
    }

    private Address createBillingAddress(TransactionEntity transactionEntity) {
        ObjectMapper mapper = new ObjectMapper();
        Address address = new Address();
        try {
            BillingAddress billingAddress = mapper.readValue(transactionEntity.getBillingAddress(), BillingAddress.class);
            address.setAddress1(billingAddress.getAddress1());
            address.setAddress2(billingAddress.getAddress2());
            address.setCity(billingAddress.getCity());
            address.setCountry(billingAddress.getCountryCode());
            address.setZipCode(billingAddress.getZip());
            address.setName(billingAddress.getName());
            address.setRegion(billingAddress.getProvince());
            address.setPhone(billingAddress.getPhone());
        } catch (JsonProcessingException e) {
            e.printStackTrace();
        }
        return address;
    }

    private PaymentMethod createPaymentMethod(TransactionEntity transactionEntity) {
        PaymentMethod paymentMethod=new PaymentMethod().setPaymentGateway("$"+transactionEntity.getGateway())
                        .setPaymentType("$credit_card")
                        .setCardBin(transactionEntity.getCreditCardBin())
                        .setCardLast4(transactionEntity.getCreditCardNumber().equals("")?"":transactionEntity.getCreditCardNumber().substring(transactionEntity.getCreditCardNumber().length() - 4))
                .setAvsResultCode(transactionEntity.getAvsResultCode()).setCvvResultCode(transactionEntity.getCvvResultCode());
    return paymentMethod;
    }

    private TransactionEntity saveTransaction(Transaction transaction, Long shopId) {
        TransactionEntity transactionEntity = new TransactionEntity();
        Date date = new Date();
        try {
            transactionEntity.setAmount(CommonUtil.parseBigDecimal(transaction.getAmount()));
            transactionEntity.setAuthorization(transaction.getAuthorization());
            transactionEntity.setCreatedAt(transaction.getCreated_at());
            transactionEntity.setCrtDate(date);
            transactionEntity.setCurrency("USD");
            transactionEntity.setErrorCode(transaction.getError_code());
            transactionEntity.setGateway(transaction.getGateway());
            transactionEntity.setLocationId(transaction.getLocation_id());
            transactionEntity.setMessage(transaction.getMessage());
            transactionEntity.setOrderId(transaction.getOrder_id());
            transactionEntity.setShopId(shopId);
            transactionEntity.setSourceName(transaction.getSource_name());
            transactionEntity.setStatus(SiftApplicationConstant.INT_ZERO);
            transactionEntity.setTransactionId(transaction.getId());
            transactionEntity.setTransactionStatus("$" + transaction.getStatus());
            transactionEntity.setTransactionType(getTransactionType(transaction.getKind()));
            transactionEntity.setUpdDate(date);
            transactionEntity.setUserId(transaction.getUser_id());
            transactionEntity.setAvsResultCode(transaction.getPayment_details()== null ? "" : transaction.getPayment_details().getAvs_result_code());
            transactionEntity.setCvvResultCode(transaction.getPayment_details()== null ? "" : transaction.getPayment_details().getCvv_result_code());
            transactionEntity.setCreditCardNumber(transaction.getPayment_details()== null ? "" : transaction.getPayment_details().getCredit_card_number());
            transactionEntity.setCreditCardBin(transaction.getPayment_details()== null ? "" : transaction.getPayment_details().getCredit_card_bin());
            transactionEntity.setCreditCardCompany(transaction.getPayment_details()== null ? "" : transaction.getPayment_details().getCredit_card_company());
            transactionRepository.save(transactionEntity);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return transactionEntity;
    }

    private String getTransactionType(String kind) {
        if (kind.equals("capture")) {
            return "$capture";
        } else if (kind.equals("authorization")) {
            return "$authorize";
        } else if (kind.equals("refund")) {
            return "$refund";
        } else {
            return "$sale";
        }
    }

    public void sendTransactions(Order order) {
        Gson gson = new Gson();
        Optional<List<TransactionEntity>> orderTransactions = transactionRepository.findByOrderIdAndStatusOrderByTransactionStatusAsc
                (order.getId(),SiftApplicationConstant.INT_ZERO);
        String sessionId=order.getSessionId();
        if (orderTransactions.isPresent() && !orderTransactions.get().isEmpty()) {
            orderTransactions.get().forEach(orderTransaction -> {
                orderTransaction.setBillingAddress(gson.toJson(order.getBilling_address()));
                orderTransaction.setEmail(order.getEmail());
                createOrderTransaction(orderTransaction, sessionId, order.getCustomer().getId().toString());
            });
        }
    }

    private String getSessionId(Order order) {
        try {
            if (StringUtils.hasText(order.getCart_token())) {
                List<TokenSessionEntity> tokenSessionEntity = tokenSessionRepository.findByToken(order.getCart_token());
                return tokenSessionEntity.get(0).getSessionId();
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    private void createOrderTransaction(TransactionEntity transactionEntity, String sessionId, String userId) {
        EventResponse response;
        try {
            SiftClient siftClient=CommonUtil.createSiftClient(transactionEntity.getShopId());
            response = createTransactionInSift(siftClient, transactionEntity, sessionId, userId);
            if (response.getHttpStatusCode() == HttpStatus.SC_OK) {
                transactionEntity.setStatus(SiftApplicationConstant.INT_ONE);
            } else {
                transactionEntity.setStatus(SiftApplicationConstant.INT_ZERO);
            }
            transactionEntity.setUpdDate(new Date());
            transactionRepository.save(transactionEntity);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
