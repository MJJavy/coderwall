package com.mobikasa.siftintegration.repository;

import com.mobikasa.siftintegration.entity.SiftCustomerAccountEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface CustomerAccountRepository extends JpaRepository<SiftCustomerAccountEntity, Long> {

    public SiftCustomerAccountEntity findBySpId(Long spId);

}
