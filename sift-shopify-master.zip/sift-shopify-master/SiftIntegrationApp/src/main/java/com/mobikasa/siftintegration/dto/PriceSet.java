package com.mobikasa.siftintegration.dto;

public class PriceSet {
    private Money shop_money;
    private Money presentment_money;

    public Money getShop_money() {
        return shop_money;
    }

    public void setShop_money(Money shop_money) {
        this.shop_money = shop_money;
    }

    public Money getPresentment_money() {
        return presentment_money;
    }

    public void setPresentment_money(Money presentment_money) {
        this.presentment_money = presentment_money;
    }
}
