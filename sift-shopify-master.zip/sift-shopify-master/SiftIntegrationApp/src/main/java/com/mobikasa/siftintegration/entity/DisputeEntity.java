package com.mobikasa.siftintegration.entity;

import java.math.BigDecimal;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.EmbeddedId;
import javax.persistence.Entity;
import javax.persistence.Table;

@Entity
@Table(name = "disputes")
public class DisputeEntity {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;


	@EmbeddedId
	private DisputeEntityPK disputeEntityPK;

	@Column(name = "type")
	private String type;

	@Column(name = "amount")
	private BigDecimal amount;

	@Column(name = "currency")
	private String currency;

	@Column(name = "reason")
	private String reason;

	@Column(name = "network_reason_code")
	private String networkReason;

	@Column(name = "status")
	private String status;

	@Column(name = "sift_status")
	private String siftStatus;
	

	public DisputeEntity() {}
	
	public DisputeEntity(DisputeEntityPK pk) {
		this.disputeEntityPK = pk;
	}

	public DisputeEntityPK getDisputeEntityPK() {
		return disputeEntityPK;
	}

	public void setDisputeEntityPK(DisputeEntityPK disputeEntityPK) {
		this.disputeEntityPK = disputeEntityPK;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public BigDecimal getAmount() {
		return amount;
	}

	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}

	public String getCurrency() {
		return currency;
	}

	public void setCurrency(String currency) {
		this.currency = currency;
	}

	public String getReason() {
		return reason;
	}

	public void setReason(String reason) {
		this.reason = reason;
	}

	public String getNetworkReason() {
		return networkReason;
	}

	public void setNetworkReason(String networkReason) {
		this.networkReason = networkReason;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getSiftStatus() {
		return siftStatus;
	}

	public void setSiftStatus(String siftStatus) {
		this.siftStatus = siftStatus;
	}
}
