package com.mobikasa.siftintegration.repository;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.siftintegration.entity.OrderEntity;

@Repository
public interface OrderRepository extends JpaRepository<OrderEntity, Long> {

	public Optional<List<OrderEntity>> findByOrderId(String orderId);

	Optional<OrderEntity> findOneByOrderId(String id);

	Optional<OrderEntity> findOneByOrderIdAndOrderBilled(String orderId, int intZero);
}
