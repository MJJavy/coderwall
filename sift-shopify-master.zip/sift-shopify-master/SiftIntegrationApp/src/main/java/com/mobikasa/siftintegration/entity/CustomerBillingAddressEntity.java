package com.mobikasa.siftintegration.entity;

public class CustomerBillingAddressEntity {


}
