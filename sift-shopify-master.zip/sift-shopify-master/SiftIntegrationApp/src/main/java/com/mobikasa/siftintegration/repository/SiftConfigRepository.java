package com.mobikasa.siftintegration.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mobikasa.siftintegration.entity.SiftConfigEntity;

public interface SiftConfigRepository extends JpaRepository<SiftConfigEntity, Long> {
	
	
	SiftConfigEntity findByshopId(Long storeId);
	
}
