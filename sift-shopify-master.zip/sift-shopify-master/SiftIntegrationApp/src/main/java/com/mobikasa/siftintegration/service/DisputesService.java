package com.mobikasa.siftintegration.service;

public interface DisputesService {
	
	public void fetchDisputesByShop() throws Exception;

}
