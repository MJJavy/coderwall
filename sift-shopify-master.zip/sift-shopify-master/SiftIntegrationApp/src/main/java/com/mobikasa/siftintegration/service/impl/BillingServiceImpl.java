package com.mobikasa.siftintegration.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.client.APIClient;
import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.dto.Mail;
import com.mobikasa.siftintegration.dto.UsageCharge;
import com.mobikasa.siftintegration.dto.UsageChargeRequest;
import com.mobikasa.siftintegration.entity.*;
import com.mobikasa.siftintegration.repository.*;
import com.mobikasa.siftintegration.service.BillingService;
import com.mobikasa.siftintegration.util.MailSender;
import com.mobikasa.siftintegration.util.RequestUrlUtility;
import freemarker.template.TemplateException;
import org.apache.commons.lang.time.DateUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.mail.MessagingException;
import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

@Service
public class BillingServiceImpl implements BillingService {

	@Value("${app.shopify.usagecharge.url}")
    private String usageChargeUrl;
    @Value("${app.shopify.recurringcharge.url}")
    private String recurringChargeUrl;
    @Value("${recurringcharge.cappedAmount}")
    private String cappedAmount;

    @Autowired
    private ShopRepository shopRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private SiftConfigRepository siftConfigRepository;
    @Autowired
    private MailSender mailSender;
    @Autowired
    private BillingDetailRepository billingDetailRepository;
    @Autowired
    private SentBillingDetailsRepository sentBillingDetailsRepository;

    @Override
    public void calculateAndSaveUsageCharges() {
        Optional<List<BillingDetailEntity>> billingDetailEntityList = billingDetailRepository.findRecordsToSave();
        if(billingDetailEntityList.isPresent() && !billingDetailEntityList.get().isEmpty()){
            billingDetailEntityList.get().forEach(billingDetailEntity->{
                BigDecimal billedAmount=billingDetailEntity.getSentBilling();
                billingDetailEntity.setSentBilling(new BigDecimal(0.00));
                billingDetailEntity.setUsedAmount(new BigDecimal(0.00));
                billingDetailEntity.setNextBillingDate(DateUtils.addDays(billingDetailEntity.getNextBillingDate(),30));
                billingDetailRepository.save(billingDetailEntity);
                SaveBilledDetail(billingDetailEntity.getShopId(),billedAmount);
            });
        }
    }

    private void SaveBilledDetail(Long shopId, BigDecimal billedAmount) {
        SentBillingDetailsEntity sentBillingDetailsEntity=new SentBillingDetailsEntity();
        try{
            sentBillingDetailsEntity.setShopId(shopId);
            sentBillingDetailsEntity.setBilledAmount(billedAmount);
            sentBillingDetailsEntity.setBilledDate(new Date());
            sentBillingDetailsEntity.setCreatedDate(new Date());
            sentBillingDetailsEntity.setUpdatedDate(new Date());
            sentBillingDetailsRepository.save(sentBillingDetailsEntity);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    @Override
    public void sendUsageChargesToShopify(BillingDetailEntity billDetailEntity) {
        Optional<BillingDetailEntity> billingDetailEntity=billingDetailRepository.findById(billDetailEntity.getId());
        Optional<ShopEntity> shopEntity = shopRepository.findById(billingDetailEntity.get().getShopId());
        if (shopEntity.isPresent()) {
        	UsageChargeRequest usageChargeRequest = new UsageChargeRequest();
        	UsageCharge usageCharge=new UsageCharge();
        	usageCharge.setPrice(billingDetailEntity.get().getPerOrderCharge());
            usageCharge.setDescription("Sift usage Charges");
            usageChargeRequest.setUsageCharge(usageCharge);
                Map<String, String> headerMap = new HashMap<String, String>();
                headerMap.put("X-Shopify-Access-Token", shopEntity.get().getAccessToken());
                headerMap.put("Accept", "application/json");
                String cancelUrl = RequestUrlUtility.updateRequestUrlUsageCharge(usageChargeUrl, shopEntity.get().getDomain(), shopEntity.get().getProcessId());
                try {
                    String response = APIClient.callAPI(new ObjectMapper().writeValueAsString(usageChargeRequest), cancelUrl, headerMap, "POST");
                    Map data = (Map) APIClient.parseJsonObject(response, Map.class);
                    billingDetailEntity.get().setSentBilling(billingDetailEntity.get().getSentBilling().add(billingDetailEntity.get().getPerOrderCharge()));
                    billingDetailRepository.save(billingDetailEntity.get());
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        }


    @Override
    public void processOrderBilling(String orderId, String shopId) {
        Optional<OrderEntity> orderEntity = orderRepository.findOneByOrderIdAndOrderBilled(orderId, SiftApplicationConstant.INT_ZERO);
        if (orderEntity.isPresent()) {
            Optional<BillingDetailEntity> billingDetailEntity = billingDetailRepository.findByShopId(orderEntity.get().getShopId());
            if (billingDetailEntity.isPresent()) {
                BigDecimal userCredit = billingDetailEntity.get().getUsedAmount();
                BigDecimal availableCredit = billingDetailEntity.get().getSubscriptionAmount().add(billingDetailEntity.get().getUsageAmount());
                userCredit = userCredit.setScale(0, RoundingMode.UP).add(billingDetailEntity.get().getPerOrderCharge());
                if (userCredit.compareTo(availableCredit) == 1 || userCredit.compareTo(availableCredit) == 0) {
                    disableSiftAndSendMail(shopId,billingDetailEntity.get().getTopupUrl());
                } else {
                    BigDecimal multiplier = billingDetailEntity.get().getThresholdPercentage().divide(new BigDecimal(100.00));
                    BigDecimal thresholdCredit = billingDetailEntity.get().getSubscriptionAmount().add(
                            billingDetailEntity.get().getUsageAmount().multiply(multiplier));
                    if (userCredit.compareTo(thresholdCredit) == 1 || userCredit.compareTo(thresholdCredit) == 0) {
                       if(billingDetailEntity.get().getMailSent()==0){
                           sendMailForTopup(shopId,billingDetailEntity.get());
                      }
                    }
                }
                updateUsedAmount(billingDetailEntity.get());
                updateOrderBillingStatus(orderEntity.get());
                if(billingDetailEntity.get().getUsedAmount().compareTo(billingDetailEntity.get().getSubscriptionAmount())==1) {
                	sendUsageChargesToShopify(billingDetailEntity.get());
                }
            }
        }
    }

    private void disableSiftAndSendMail(String shopId,String topupURL) {
        Mail mailData = new Mail();
        Optional<ShopEntity> shopEntity = shopRepository.findById(Long.parseLong(shopId));
        createMailContent(mailData, shopEntity, topupURL,"usage-limit-reached.html");
        try {
            mailSender.sendEmail(mailData);
            SiftConfigEntity config = siftConfigRepository.findByshopId(Long.parseLong(shopId));
            shopEntity.get().setCreditAvailable(SiftApplicationConstant.INT_ZERO);
            siftConfigRepository.save(config);
            shopRepository.save(shopEntity.get());
        } catch (MessagingException | IOException | TemplateException e) {
            e.printStackTrace();
        }
    }

    private void sendMailForTopup(String shopId, BillingDetailEntity billingDetailEntity) {
        Optional<ShopEntity> shopEntity = shopRepository.findById(Long.parseLong(shopId));
        Mail mailData = new Mail();
        if (shopEntity.isPresent()) {
            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put("X-Shopify-Access-Token", shopEntity.get().getAccessToken());
            headerMap.put("Accept", "application/json");
            String recurringChargesUrl = RequestUrlUtility.createRerecurringApplicationChargesUrl(recurringChargeUrl, shopEntity.get().getDomain(), shopEntity.get().getProcessId(), billingDetailEntity.getUsageAmount().add(new BigDecimal(500)).toString());
            try {
                String response = APIClient.callAPI(new ObjectMapper().writeValueAsString(""), recurringChargesUrl, headerMap, "PUT");
                Map data = (Map) APIClient.parseJsonObject(response, Map.class);
                Map updateCappedAmountUrl = (Map) data.get("recurring_application_charge");
                SaveCappedAmountURL(billingDetailEntity.getId(),updateCappedAmountUrl.get("update_capped_amount_url").toString());
                createMailContent(mailData, shopEntity, updateCappedAmountUrl.get("update_capped_amount_url").toString(),"capped-amount.html");
                mailSender.sendEmail(mailData);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }

    private void SaveCappedAmountURL(Long id, String updateCappedAmountUrl) {
        try{
            Optional<BillingDetailEntity> billingDetailEntity=billingDetailRepository.findById(id);
            billingDetailEntity.get().setMailSent(1);
            billingDetailEntity.get().setTopupUrl(updateCappedAmountUrl);
            billingDetailRepository.save(billingDetailEntity.get());

        }catch(Exception e){
            e.printStackTrace();
        }

    }

    private void createMailContent(Mail mailData, Optional<ShopEntity> shopEntity, String url,String templateName) {
        Map<String, String> cont = new HashMap<>();
        cont.put("url", url);
        cont.put("templateName", templateName);
        mailData.setContent(cont);
        mailData.setTo(shopEntity.get().getEmail());
        mailData.setName("");
    }

    private void updateOrderBillingStatus(OrderEntity orderEntity) {
        orderEntity.setOrderBilled(1);
        orderRepository.save(orderEntity);
    }

    private void updateUsedAmount(BillingDetailEntity billingDetailEntity) {
        billingDetailEntity.setUsedAmount(billingDetailEntity.getUsedAmount().add(billingDetailEntity.getPerOrderCharge()));
        billingDetailRepository.save(billingDetailEntity);
    }


	@Override
	public boolean isCreditAvailable(Long storeId) {
            Optional<BillingDetailEntity> billingDetailEntity = billingDetailRepository.findByShopId(storeId);
            if (billingDetailEntity.isPresent()) {
                BigDecimal usedCredit = billingDetailEntity.get().getUsedAmount();
                BigDecimal availableCredit = billingDetailEntity.get().getSubscriptionAmount().add(billingDetailEntity.get().getUsageAmount());
                usedCredit = usedCredit.setScale(0, RoundingMode.UP).add(billingDetailEntity.get().getPerOrderCharge());
                if (usedCredit.compareTo(availableCredit) == 1 || usedCredit.compareTo(availableCredit) == 0) {
                    disableSiftAndSendMail(storeId.toString(),billingDetailEntity.get().getTopupUrl());
                    return false;
                } else {
                    BigDecimal multiplier = billingDetailEntity.get().getThresholdPercentage().divide(new BigDecimal(100.00));
                    BigDecimal thresholdCredit = billingDetailEntity.get().getSubscriptionAmount().add(
                            billingDetailEntity.get().getUsageAmount().multiply(multiplier));
                    if (usedCredit.compareTo(thresholdCredit) == 1 || usedCredit.compareTo(thresholdCredit) == 0) {
                        sendMailForTopup(storeId.toString(),billingDetailEntity.get());
                        return true;
                    }else {
                    	return true;
                    }
                }
            }
			return false;
        }
	
}