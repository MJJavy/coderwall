package com.mobikasa.siftintegration.repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.siftintegration.entity.DisputeEntity;
import com.mobikasa.siftintegration.entity.DisputeEntityPK;

import java.util.List;

@Repository
public interface DisputeRepository extends CrudRepository<DisputeEntity, DisputeEntityPK> {

    List<DisputeEntity> findBySiftStatus(String status);

}
