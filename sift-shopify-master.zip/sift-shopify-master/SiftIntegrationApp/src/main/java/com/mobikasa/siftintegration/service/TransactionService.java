package com.mobikasa.siftintegration.service;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface TransactionService {

    ResponseEntity<?> createTransaction(Map<String, String> headers, String transactionData) throws Exception;
}
