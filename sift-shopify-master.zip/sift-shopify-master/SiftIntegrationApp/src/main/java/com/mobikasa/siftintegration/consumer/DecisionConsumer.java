package com.mobikasa.siftintegration.consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.entity.ApiLogEntity;
import com.mobikasa.siftintegration.entity.DecisionEntity;
import com.mobikasa.siftintegration.entity.OrderEntity;
import com.mobikasa.siftintegration.entity.ShopDecisionId;
import com.mobikasa.siftintegration.repository.DecisionRepository;
import com.mobikasa.siftintegration.repository.SiftConfigRepository;
import com.mobikasa.siftintegration.util.CommonUtil;
import com.siftscience.*;
import com.siftscience.exception.SiftException;
import com.siftscience.model.ApplyDecisionFieldSet;
import com.siftscience.model.GetDecisionFieldSet;
import com.siftscience.model.GetDecisionsResponseBody;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Date;
import java.util.List;


@Component
public class DecisionConsumer {

    @Autowired
    SiftConfigRepository siftConfigRepository;
    @Autowired
    private DecisionRepository decisionRepository;

    public Boolean updateDecision(Long shopId) {
        SiftClient siftClient = CommonUtil.createSiftClient(shopId);
        GetDecisionsResponse response = null;
        ObjectMapper Obj = new ObjectMapper();
        GetDecisionsRequest request = siftClient.buildRequest(new GetDecisionFieldSet()
                .setEntityType(GetDecisionFieldSet.EntityType.ORDER)
                .setAbuseTypes(Collections.singletonList(GetDecisionFieldSet.AbuseType.PAYMENT_ABUSE)));
        try {
            ApiLogEntity apiLog = CommonUtil.createApiLog("decisions", Obj.writeValueAsString(request.getFieldSet()), shopId,"");
            response = request.send();
            CommonUtil.updateApiLog(apiLog, Obj.writeValueAsString(response.getBody()));
            List<GetDecisionsResponseBody.Decision> decisions = response.getBody().getDecisions();
            List<DecisionEntity> decisionsList = mapDecisionstoEntity(decisions, shopId);
            decisionRepository.saveAll(decisionsList);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return true;
    }

    private List<DecisionEntity> mapDecisionstoEntity(List<GetDecisionsResponseBody.Decision> decisions, Long shopId) {
        List<DecisionEntity> DecisionEntityList = new ArrayList();
        decisions.forEach(decision -> {
            DecisionEntity decisionEntity = new DecisionEntity();
            decisionEntity.setShopDecisionId(new ShopDecisionId(decision.getId(), shopId));
            decisionEntity.setName(decision.getName());
            decisionEntity.setCategory(decision.getCategory().name());
            decisionEntity.setAbuseType(decision.getAbuseType().name());
            decisionEntity.setCreatedAt(new Date(decision.getCreatedAt()));
            decisionEntity.setCreatedBy(decision.getCreatedBy());
            decisionEntity.setUpdatedAt(new Date(decision.getUpdatedAt()));
            decisionEntity.setUpdatedBy(decision.getUpdatedBy());
            decisionEntity.setEntityType(decision.getEntityType().name());
            decisionEntity.setDescription(decision.getDescription());
            DecisionEntityList.add(decisionEntity);
        });
        return DecisionEntityList;
    }

    public void applyDecisionForChargeBack(SiftClient siftClient, OrderEntity orderEntity, String status) {
        String decisionId = getDecisionId(status);
        ApplyDecisionRequest request = siftClient.buildRequest(
                new ApplyDecisionFieldSet()
                        .setUserId(orderEntity.getCustomerId())
                        .setDecisionId(decisionId)
                        .setSource(ApplyDecisionFieldSet.DecisionSource.AUTOMATED_RULE)
                        .setOrderId(orderEntity.getOrderId()));
        ApplyDecisionResponse response = null;
        try {
            try {
                System.out.print(request.getFieldSet().toJson());
                response = request.send();
            } catch (IOException e) {
                System.out.print(response);
                e.printStackTrace();
            }
        } catch (SiftException e) {
            System.out.println(e.getApiErrorMessage());
        }
    }

    private String getDecisionId(String status) {
        String decisionId = null;
        switch (status) {
            case "needs_response":
                decisionId = "chargeback_needs_response_payment_abuse";
                break;
            case "under_review":
                decisionId = "chargeback_under_review__payment_abuse";
                break;
            case "charge_refunded":
                decisionId = "chargeback_refunded_payment_abuse";
                break;
            case "accepted":
                decisionId = "chargeback_accepted_payment_abuse";
                break;
            case "won":
                decisionId = "chargeback_won_payment_abuse";
                break;
            case "lost":
                decisionId = "block_order_payment_abuse";
                break;
        }
        return decisionId;
    }

    public void applyDecisionForOrder(SiftClient siftClient, OrderEntity orderEntity, String decisionId) {
        System.out.println("orderEntity.getOrderId()"+orderEntity.getOrderId());
        ApplyDecisionRequest request = siftClient.buildRequest(
                new ApplyDecisionFieldSet()
                        .setUserId(orderEntity.getCustomerId())
                        .setDecisionId(decisionId)
                        .setSource(ApplyDecisionFieldSet.DecisionSource.AUTOMATED_RULE)
                        .setOrderId(orderEntity.getOrderId())
                        .setDescription("others"));
        ApplyDecisionResponse response = null;
        try {
            try {
                System.out.print(request.getFieldSet().toJson());
                response = request.send();
            } catch (IOException e) {
                System.out.print(response);
                e.printStackTrace();
            }
        } catch (SiftException e) {
            System.out.println(e.getApiErrorMessage());
        }
    }
}