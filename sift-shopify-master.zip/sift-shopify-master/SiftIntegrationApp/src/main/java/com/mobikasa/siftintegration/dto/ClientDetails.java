package com.mobikasa.siftintegration.dto;

import com.fasterxml.jackson.annotation.JsonProperty;

public class ClientDetails {

    private String browser_ip;
    private String accept_language;
    private String user_agent;

    public String getBrowser_ip() {
        return browser_ip;
    }

    public void setBrowser_ip(String browser_ip) {
        this.browser_ip = browser_ip;
    }

    public String getAccept_language() {
        return accept_language;
    }

    public void setAccept_language(String accept_language) {
        this.accept_language = accept_language;
    }

    public String getUser_agent() {
        return user_agent;
    }

    public void setUser_agent(String user_agent) {
        this.user_agent = user_agent;
    }
}
