package com.mobikasa.siftintegration.controller;


import java.util.HashMap;
import java.util.Map;


import com.mobikasa.siftintegration.ShopifyUpdateOrder;
import com.mobikasa.siftintegration.consumer.AccountConsumer;
import com.mobikasa.siftintegration.consumer.ChargebackConsumer;
import com.mobikasa.siftintegration.consumer.OrderConsumer;
import com.mobikasa.siftintegration.consumer.TransactionConsumer;
import com.mobikasa.siftintegration.entity.BillingDetailEntity;
import com.mobikasa.siftintegration.repository.BillingDetailRepository;
import com.mobikasa.siftintegration.service.BillingService;
import com.mobikasa.siftintegration.service.DisputesService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mobikasa.siftintegration.dto.Mail;
import com.mobikasa.siftintegration.util.MailSender;

@RestController
public class TestController {

    @Autowired
    private MailSender mailSender;
@Autowired
    private TransactionConsumer transactionConsumer;
    @Autowired
    private OrderConsumer orderConsumer;
    @Autowired
    private BillingDetailRepository billingDetailRepository;

    @Autowired
    private BillingService billingService;

    @Autowired
    private DisputesService disputesService;
    @Autowired
    private AccountConsumer accountConsumer;



    @RequestMapping(value = "/call-api")
    public ResponseEntity createCustomer() {
        try {
        	Mail mailData = new Mail();
        	Map<String, String> cont = new HashMap<>();
            cont.put("orderNo", "1234");
            cont.put("amount", "$"+"675");
            cont.put("score", "25");
            cont.put("templateName", "review.html");
            cont.put("url", "");
            mailData.setContent(cont);
            mailData.setTo("gupta.sahil1234@gmail.com");
            mailData.setName("Sahil gupta");
            
            mailSender.sendEmail(mailData);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.CREATED);
    }

    @RequestMapping(value = "/health-check")
    public ResponseEntity healthCheck() {
        try {
            return new ResponseEntity<>(null, HttpStatus.OK);
        } catch (Exception exp) {
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
    }

    @RequestMapping(value = "/start-chargeback")
    public ResponseEntity startChargeBack() {
        try {
            disputesService.fetchDisputesByShop();
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @RequestMapping(value = "/transaction")
    public ResponseEntity transaction() {
        try {
            transactionConsumer.createTransaction(175L);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @RequestMapping(value = "/order")
    public ResponseEntity order() {
        try {
          orderConsumer.processTransactionAndOrder(171L);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.OK);
    }

    @RequestMapping(value = "/account")
    public ResponseEntity account() {
        try {
            accountConsumer.createSiftCustomerAccount(33L);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.OK);
    }






}