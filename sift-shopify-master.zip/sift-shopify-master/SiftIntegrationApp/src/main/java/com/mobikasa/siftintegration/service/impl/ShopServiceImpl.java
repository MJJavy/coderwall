/**
 *
 */
package com.mobikasa.siftintegration.service.impl;

import java.io.IOException;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.dto.Mail;
import com.mobikasa.siftintegration.entity.BillingDetailEntity;
import com.mobikasa.siftintegration.entity.ShopEntity;
import com.mobikasa.siftintegration.entity.SiftConfigEntity;
import com.mobikasa.siftintegration.repository.BillingDetailRepository;
import com.mobikasa.siftintegration.repository.ShopRepository;
import com.mobikasa.siftintegration.repository.SiftConfigRepository;
import com.mobikasa.siftintegration.service.ShopService;
import com.mobikasa.siftintegration.util.MailSender;

import freemarker.template.TemplateException;

@Service("shopService")
public class ShopServiceImpl implements ShopService {

    @Value("${app.install.secretkey}")
    private String secretKey;

    @Autowired
    private ShopRepository shopRepository;
    @Autowired
    private SiftConfigRepository siftConfigRepository;
    @Autowired
    private MailSender mailSender;
    @Autowired
    private BillingDetailRepository billingRepository;
    @Override
    public void appUninstalled(Map<String, String> headers, String storeData) throws Exception {
        try {

            ShopEntity shopEntity = shopRepository.findByDomain(headers.get("x-shopify-shop-domain"));
            shopEntity.setUninstalledTime(Calendar.getInstance().getTime());
            shopEntity.setStatus("0");
            shopEntity.setProcessId(null);
            shopEntity.setBillingApproveStatus(0);
            shopEntity.setBillingApproveDate(null);
            shopEntity.setCreditAvailable(0);
            shopRepository.save(shopEntity);
            
            
            Optional<BillingDetailEntity> billing = billingRepository.findByShopId(shopEntity.getId());
            if(billing.isPresent()) {
            	billingRepository.delete(billing.get());
            }
            
            this.deleteShopConfig(shopEntity.getId());
            
            sendEmail(shopEntity.getEmail());
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }


    private void sendEmail(String email)
            throws MessagingException, IOException, TemplateException {
        Mail mailData = new Mail();
        Map<String, String> cont = new HashMap<>();
        cont.put("templateName", "uninstall.html");
        mailData.setContent(cont);
        mailData.setTo(email);
        mailSender.sendEmail(mailData);
    }


    //@Cacheable("shopConfig")
    @Override
    public Map<String, String> fetchShopConfig(Long shopId) {
        Map<String, String> configMap = new HashMap();
        try {
            SiftConfigEntity siftConfigEntity = siftConfigRepository.findByshopId(shopId);
            if (siftConfigEntity.getEnvironment().equals(SiftApplicationConstant.ZERO)) {
                configMap.put("apiKey", siftConfigEntity.getStagingApiKey());
                configMap.put("accountId", siftConfigEntity.getStagingAccountId());
                configMap.put("environment", siftConfigEntity.getEnvironment());
            } else {
                configMap.put("apiKey", siftConfigEntity.getProductionApiKey());
                configMap.put("accountId", siftConfigEntity.getProductionAccountId());
                configMap.put("environment", siftConfigEntity.getEnvironment());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return configMap;
    }
    
    
    public void deleteShopConfig(Long shopId) {
        try {
            SiftConfigEntity siftConfigEntity = siftConfigRepository.findByshopId(shopId);
            
            if(siftConfigEntity != null && siftConfigEntity.getId() != null) {
            	siftConfigRepository.deleteById(siftConfigEntity.getId());
            }
            
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

}