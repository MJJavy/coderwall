package com.mobikasa.siftintegration.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.mobikasa.siftintegration.service.OrderService;

@RequestMapping("refunds")
@RestController
public class RefundController {

        @Autowired
        private OrderService orderService;


        @PostMapping(value = "/create")
        public ResponseEntity createTransaction(@RequestHeader Map<String, String> headers, @RequestBody String refundData) {
            try {
            	orderService.createRefundTransaction(headers, refundData, null, "refunds/create");
            } catch(Exception exp) {
                exp.printStackTrace();
            }
            return new ResponseEntity<>(null, HttpStatus.OK);
        }

}
