package com.mobikasa.siftintegration.service;

import com.mobikasa.siftintegration.entity.BillingDetailEntity;

public interface BillingService {

    void calculateAndSaveUsageCharges();

    void sendUsageChargesToShopify(BillingDetailEntity billingDetailEntity);

    void processOrderBilling(String orderId, String shopId);

	boolean isCreditAvailable(Long storeId);

}
