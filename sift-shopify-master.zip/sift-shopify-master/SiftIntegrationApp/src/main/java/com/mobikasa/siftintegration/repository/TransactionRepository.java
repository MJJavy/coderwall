package com.mobikasa.siftintegration.repository;

import com.mobikasa.siftintegration.entity.TransactionEntity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface TransactionRepository extends JpaRepository<TransactionEntity, Long> {


    Optional<List<TransactionEntity>> findByOrderIdOrderByTransactionStatusAsc(String id);

    Optional<List<TransactionEntity>> findByOrderIdAndTransactionStatus(String id,String status);

    Optional<List<TransactionEntity>> findByOrderIdAndStatusOrderByTransactionStatusAsc(String id, int intZero);
}
