package com.mobikasa.siftintegration;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;

import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.client.APIClient;
import com.mobikasa.siftintegration.entity.OrderEntity;
import com.mobikasa.siftintegration.entity.ShopEntity;
import com.mobikasa.siftintegration.entity.SiftConfigEntity;
import com.mobikasa.siftintegration.repository.OrderRepository;
import com.mobikasa.siftintegration.repository.ShopRepository;
import com.mobikasa.siftintegration.repository.SiftConfigRepository;
import com.mobikasa.siftintegration.shopify.request.OrderTagUpdate;
import com.mobikasa.siftintegration.util.RequestUrlUtility;

@Component
public class ShopifyUpdateOrder {

    private static final String SHOPIFY_SCORE_TAG = "sift_score:";
    private static final String SIFT_ENVIRONMENT = "sift_env:";
    private static final String SHOPIFY_DECISION_TAG = "sift_decision_action:";

    @Value("${app.shopify.ordercancel.url}")
    private String orderCancelUrl;

    @Value("${app.shopify.ordertag.url}")
    private String orderTagUrl;
    
    @Value("${app.shopify.getOrdertag.url}")
    private String fetchOrderTagUrl;
    
    @Autowired
    private ShopRepository shopRepository;
	
    @Autowired
    private SiftConfigRepository siftConfigRepository;
	
    @Autowired
    private OrderRepository orderRepository;

	public void updateShopifyOrder(Long shopId, Long orderId, BigDecimal score, String decision) {
		Optional<ShopEntity> shop = null;
		try {
			System.out.println("updating tag in shopify"+shopId+","+orderId+","+decision);
			Optional<OrderEntity> order = orderRepository.findOneByOrderId(orderId+"");
			shop = shopRepository.findById(shopId);
			SiftConfigEntity config = siftConfigRepository.findByshopId(shopId);
			String tag = this.fetchShopifyTagFromOrder(shop, orderId);
			if( StringUtils.hasText(tag) ) {
				
				tag = tag + "," + (decision == null ? "" : SHOPIFY_DECISION_TAG + decision);
				this.updateShopifyTag(shop, orderId, tag);
			} else {
				if (score != null) {
					tag = SHOPIFY_DECISION_TAG + 
							(decision == null ? "" : decision)
							.concat( StringUtils.hasText(order.get().getTag()) ? ":" + order.get().getTag() : "" ) 
							+ "," + SHOPIFY_SCORE_TAG + score + ","
							+ SIFT_ENVIRONMENT + config.getSiftEnvironmentName();
					System.out.println("tag updated in shopify"+shopId+","+orderId+","+decision);
					this.updateShopifyTag(shop, orderId, tag);
				}
			}
			if ( StringUtils.hasText(decision) && decision.equals("BLOCK")) {
				this.updateShopifyStatus(shop, orderId, shop.get().getCurrency(), order.get().getAmount());
			}
			order = orderRepository.findOneByOrderId(orderId+"");
			order.get().setTag(tag);
            order.get().setActionTaken(decision);
			orderRepository.save(order.get());
		} catch (Exception exp) {
			System.out.println();
		}
	}

    private void updateShopifyStatus(Optional<ShopEntity> shop, Long orderId, String currency, BigDecimal amount) {
        try {
            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put("X-Shopify-Access-Token", shop.get().getAccessToken());
            headerMap.put("Accept", "application/json");
            String cancelUrl = RequestUrlUtility.updateRequestUrlOrderId(orderCancelUrl, shop.get().getDomain(), orderId.toString());
            
            Map<String, String> requestData = new HashMap<String, String>();
            requestData.put("note", "Broke in shipping");
            requestData.put("amount", amount.toString());
    		requestData.put("currency", currency);		
            
            String response = APIClient.callAPI(new ObjectMapper().writeValueAsString(requestData), cancelUrl, headerMap, "POST");
            Map data = (Map) APIClient.parseJsonObject(response, Map.class);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    private void updateShopifyTag(Optional<ShopEntity> shop, Long orderId, String tag) {
        try {
            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put("X-Shopify-Access-Token", shop.get().getAccessToken());
            headerMap.put("Accept", "application/json");
            String tagUrl = RequestUrlUtility.updateRequestUrlOrderId(orderTagUrl, shop.get().getDomain(), orderId.toString());
            OrderTagUpdate tagRequest = new OrderTagUpdate(orderId, tag);
            String response = APIClient.callAPI(new ObjectMapper().writeValueAsString(tagRequest), tagUrl, headerMap, "PUT");
            Map data = (Map) APIClient.parseJsonObject(response, Map.class);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }
    
    private String fetchShopifyTagFromOrder(Optional<ShopEntity> shop, Long orderId) {
    	String data = "";
        try {
            Map<String, String> headerMap = new HashMap<String, String>();
            headerMap.put("X-Shopify-Access-Token", shop.get().getAccessToken());
            headerMap.put("Accept", "application/json");
            String tagUrl = RequestUrlUtility.updateRequestUrlOrderId(fetchOrderTagUrl, shop.get().getDomain(), orderId.toString());
            String response = APIClient.callAPI(new ObjectMapper().writeValueAsString(""), tagUrl, headerMap, "GET");
            Map parseResponse = (Map) APIClient.parseJsonObject(response, Map.class);
            
            data = (String) ((Map) parseResponse.get("order")).get("tags");
        } catch (Exception exp) {
            System.out.println();
        }
		return data;
    }
}	