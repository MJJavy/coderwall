package com.mobikasa.siftintegration.dto;

import org.springframework.stereotype.Component;

import javax.persistence.Column;
import java.math.BigDecimal;

@Component
public class  SiftCustomerAccount {
    private Long id;
    private Long storeId;
    private String email;
    private Integer acceptsMarketing;
    private String createdAt;
    private String updatedAt;
    private String firstName;
    private String lastName;
    private Integer ordersCount;
    private String state;
    private BigDecimal totalSpent;
    private Integer lastOrderId;
    private String note;
    private Integer verifiedEmail;
    private String multipassIdentifier;
    private Integer taxExempt;
    private String phone;
    private String tags;
    private String lastOrderName;
    private String currency;
    private String addresses;
    private String acceptsMarketingUpdatedAt;
    private String marketingOptInLevel;
    private String adminGraphqlApiId;
    private String name;
    private String status;
    private Long spId;
    private SiftCustomerAddress CustomerAddress;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getStoreId() {
        return storeId;
    }

    public void setStoreId(Long storeId) {
        this.storeId = storeId;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public Integer getAcceptsMarketing() {
        return acceptsMarketing;
    }

    public void setAcceptsMarketing(Integer acceptsMarketing) {
        this.acceptsMarketing = acceptsMarketing;
    }

    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Integer getOrdersCount() {
        return ordersCount;
    }

    public void setOrdersCount(Integer ordersCount) {
        this.ordersCount = ordersCount;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public BigDecimal getTotalSpent() {
        return totalSpent;
    }

    public void setTotalSpent(BigDecimal totalSpent) {
        this.totalSpent = totalSpent;
    }

    public Integer getLastOrderId() {
        return lastOrderId;
    }

    public void setLastOrderId(Integer lastOrderId) {
        this.lastOrderId = lastOrderId;
    }

    public String getNote() {
        return note;
    }

    public void setNote(String note) {
        this.note = note;
    }

    public Integer getVerifiedEmail() {
        return verifiedEmail;
    }

    public void setVerifiedEmail(Integer verifiedEmail) {
        this.verifiedEmail = verifiedEmail;
    }

    public String getMultipassIdentifier() {
        return multipassIdentifier;
    }

    public void setMultipassIdentifier(String multipassIdentifier) {
        this.multipassIdentifier = multipassIdentifier;
    }

    public Integer getTaxExempt() {
        return taxExempt;
    }

    public void setTaxExempt(Integer taxExempt) {
        this.taxExempt = taxExempt;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTags() {
        return tags;
    }

    public void setTags(String tags) {
        this.tags = tags;
    }

    public String getLastOrderName() {
        return lastOrderName;
    }

    public void setLastOrderName(String lastOrderName) {
        this.lastOrderName = lastOrderName;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getAddresses() {
        return addresses;
    }

    public void setAddresses(String addresses) {
        this.addresses = addresses;
    }

    public String getAcceptsMarketingUpdatedAt() {
        return acceptsMarketingUpdatedAt;
    }

    public void setAcceptsMarketingUpdatedAt(String acceptsMarketingUpdatedAt) {
        this.acceptsMarketingUpdatedAt = acceptsMarketingUpdatedAt;
    }

    public String getMarketingOptInLevel() {
        return marketingOptInLevel;
    }

    public void setMarketingOptInLevel(String marketingOptInLevel) {
        this.marketingOptInLevel = marketingOptInLevel;
    }

    public String getAdminGraphqlApiId() {
        return adminGraphqlApiId;
    }

    public void setAdminGraphqlApiId(String adminGraphqlApiId) {
        this.adminGraphqlApiId = adminGraphqlApiId;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Long getSpId() {
        return spId;
    }

    public void setSpId(Long spId) {
        this.spId = spId;
    }


    public com.mobikasa.siftintegration.dto.SiftCustomerAddress getCustomerAddress() {
        return CustomerAddress;
    }

    public void setCustomerAddress(com.mobikasa.siftintegration.dto.SiftCustomerAddress customerAddress) {
        CustomerAddress = customerAddress;
    }


}
