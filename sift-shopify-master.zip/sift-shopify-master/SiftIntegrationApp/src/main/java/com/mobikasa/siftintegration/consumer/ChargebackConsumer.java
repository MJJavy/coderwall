package com.mobikasa.siftintegration.consumer;

import java.util.List;
import java.util.Optional;

import com.mobikasa.siftintegration.util.RabbitMQPublisher;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.entity.ApiLogEntity;
import com.mobikasa.siftintegration.entity.DisputeEntity;
import com.mobikasa.siftintegration.entity.OrderEntity;
import com.mobikasa.siftintegration.entity.TransactionEntity;
import com.mobikasa.siftintegration.repository.DisputeRepository;
import com.mobikasa.siftintegration.repository.OrderRepository;
import com.mobikasa.siftintegration.repository.TransactionRepository;
import com.mobikasa.siftintegration.util.CommonUtil;
import com.siftscience.EventRequest;
import com.siftscience.EventResponse;
import com.siftscience.SiftClient;
import com.siftscience.model.ChargebackFieldSet;

@Component
public class ChargebackConsumer {

    @Autowired
    private DisputeRepository disputeRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private TransactionRepository transactionRepository;
    @Autowired
    private DecisionConsumer decisionConsumer;
    @Autowired
    private RabbitMQPublisher rabbitMQPublisher;

    @Async("fixedThreadPool")
    public void createChargeBack() {
        List<DisputeEntity> updatedDisputes = disputeRepository.findBySiftStatus(SiftApplicationConstant.ZERO);
        if (!updatedDisputes.isEmpty()) {
            updatedDisputes.forEach(dispute -> {
                SiftClient siftClient = CommonUtil.createSiftClient(dispute.getDisputeEntityPK().getShopId());
                Optional<List<OrderEntity>> orderEntity = orderRepository.findByOrderId(dispute.getDisputeEntityPK().getOrderId().toString());
                if (orderEntity.isPresent() && !orderEntity.get().isEmpty()) {
                	createChargeBackInSift(siftClient, dispute, orderEntity.get().get(0));
                	decisionConsumer.applyDecisionForChargeBack(siftClient, orderEntity.get().get(0), dispute.getStatus());
                    updateDisputeStatus(dispute);
                }
            });
        }
    }

    private void updateDisputeStatus(DisputeEntity dispute) {
        try {
            dispute.setSiftStatus(SiftApplicationConstant.ONE);
            disputeRepository.save(dispute);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void createChargeBackInSift(SiftClient siftClient, DisputeEntity dispute, OrderEntity orderEntity) {
        //mapValuesForSift(dispute);
        Optional<List<TransactionEntity>> transactionEntity = transactionRepository.findByOrderIdAndTransactionStatus(dispute.getDisputeEntityPK().getOrderId().toString(), SiftApplicationConstant.STATUS_SUCCESS);
        if (transactionEntity.isPresent() && !transactionEntity.get().isEmpty()) {
            ApiLogEntity apiLog;
            ObjectMapper Obj = new ObjectMapper();
            EventResponse response;
            EventRequest request = siftClient.buildRequest(new ChargebackFieldSet()
                    .setOrderId(dispute.getDisputeEntityPK().getOrderId().toString())
                    .setTransactionId(transactionEntity.get().get(0).getTransactionId())
                    .setUserId(orderEntity.getCustomerId())
                    .setChargebackState(mapStatusValuesForSift(dispute.getStatus()))
                    .setChargebackReason(mapReasonValuesForSift(dispute.getStatus())));
            try {
                apiLog = CommonUtil.createApiLog(SiftApplicationConstant.CREATE_CALLBACK, Obj.writeValueAsString(request.getFieldSet()), dispute.getDisputeEntityPK().getShopId(),"");
                response = request.send();
                CommonUtil.updateApiLog(apiLog, Obj.writeValueAsString(response.getBody()));
            } catch (Exception e) {
                e.printStackTrace();
            }
        } else {
            System.out.print("Transactions not found for dispute");
        }
    }

    private String mapStatusValuesForSift(String status) {
        switch (status) {
            case "needs_response":
                return "$received";
            case "under_review":
            	return "$disputed";
            case "charge_refunded":
            case "accepted":
            	return "$accepted";
            case "won":
            	return "$won";
            case "lost":
            	return "$lost";
        }
        return "";
    }
    
    private String mapReasonValuesForSift(String reason) {
        switch (reason) {
            case "needs_response":
            	return "$other";
            case "under_review":
            	return "$other";
            case "charge_refunded":
            case "accepted":
            	return "$other";
            case "won":
            	return "$other";
            case "lost":
            	return "$other";
        }
        return "";
    }

}
