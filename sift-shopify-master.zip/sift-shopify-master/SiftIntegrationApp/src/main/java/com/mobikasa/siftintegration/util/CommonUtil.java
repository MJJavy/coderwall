package com.mobikasa.siftintegration.util;

import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.entity.ApiLogEntity;
import com.mobikasa.siftintegration.repository.ApiLogRepository;
import com.mobikasa.siftintegration.service.OrderService;
import com.mobikasa.siftintegration.service.ShopService;
import com.siftscience.SiftClient;
import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.math.BigDecimal;
import java.util.Date;
import java.util.Map;

@Component
public class CommonUtil {

    private static String SIFT_WEBHOOK_SECRET_KEY = "#####";

    @Autowired
    public static ApiLogRepository apiLogRepository;
    @Autowired
    public static ShopService shopService;
    @Autowired
    private static OrderService orderService;

    @Autowired
    public void setUserRepo(ApiLogRepository apiLogRepository) {
        CommonUtil.apiLogRepository = apiLogRepository;
    }
    @Autowired
    public void setOrderService(OrderService orderService) {
        CommonUtil.orderService = orderService;
    }
    @Autowired
    public void setShopService(ShopService shopService) {
        CommonUtil.shopService = shopService;
    }

    public static BigDecimal parseBigDecimal(Object object) {
        if (object == null) {
            return BigDecimal.ZERO;
        } else {
            return new BigDecimal(object.toString());
        }
    }

    public static Integer parseInt(Object object) {
        if (object == null) {
            return 0;
        } else {
            return Integer.parseInt(object.toString());
        }
    }

    public static Long parseLong(Object object) {
        if (object == null) {
            return 0L;
        } else {
            return (long)Double.parseDouble(object.toString());
        }
    }

    public static ApiLogEntity createApiLog(String event, String requestData, Long storeId,String url){
        ApiLogEntity apiLog=new ApiLogEntity();
        Date date=new Date();
        try{
            apiLog.setEvent(event);
            apiLog.setRequestData(requestData);
            apiLog.setRequestTime(date);
            apiLog.setShopId(storeId);
            apiLog.setUrl(url);
            apiLogRepository.save(apiLog);
        }catch(Exception e){
            e.printStackTrace();
        }
        return apiLog;
    }

    public static void updateApiLog(ApiLogEntity apiLog, String responseData) {
        Date date=new Date();
        try{
            apiLog.setResponseData(responseData);
            apiLog.setResponseTime(date);
            apiLogRepository.save(apiLog);
        }catch(Exception e){
            e.printStackTrace();
        }
    }

    public static SiftClient createSiftClient(long shopId) {
        Map<String,String> shopConfigMap=shopService.fetchShopConfig(shopId);
        return new SiftClient(shopConfigMap.get("apiKey"), shopConfigMap.get("accountId"));
    }


    public static boolean validateSiftToken(Long shopId, String webhookSignature, String data) {
        String environment = orderService.getEnvironment(shopId);
        if (environment != null && environment.equals(SiftApplicationConstant.ONE)) {
            String verificationSignature = "sha1=" + HmacUtils.hmacSha1Hex(
                    SIFT_WEBHOOK_SECRET_KEY,
                    data);
            if (!webhookSignature.equals(verificationSignature)) {
                return false;
            } else {
                return true;
            }
        } else {
            return true;
        }
    }
}
