package com.mobikasa.siftintegration.shopify.response;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "order_id",
    "type",
    "amount",
    "currency",
    "reason",
    "network_reason_code",
    "status",
    "evidence_due_by",
    "evidence_sent_on",
    "finalized_on",
    "initiated_at"
})
public class Dispute {

    @JsonProperty("id")
    private Long id;
    
    @JsonProperty("order_id")
    private String orderId;
    
    @JsonProperty("type")
    private String type;
    
    @JsonProperty("amount")
    private String amount;
    
    @JsonProperty("currency")
    private String currency;
    
    @JsonProperty("reason")
    private String reason;
    
    @JsonProperty("network_reason_code")
    private String networkReasonCode;
    
    @JsonProperty("status")
    private String status;
    
    @JsonProperty("evidence_due_by")
    private String evidenceDueBy;
    
    @JsonProperty("evidence_sent_on")
    private String evidenceSentOn;
    
    @JsonProperty("finalized_on")
    private String finalizedOn;
    
    @JsonProperty("initiated_at")
    private String initiatedAt;
    
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("id")
    public Long getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty("order_id")
    public String getOrderId() {
        return orderId;
    }

    @JsonProperty("order_id")
    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    @JsonProperty("type")
    public String getType() {
        return type;
    }

    @JsonProperty("type")
    public void setType(String type) {
        this.type = type;
    }

    @JsonProperty("amount")
    public String getAmount() {
        return amount;
    }

    @JsonProperty("amount")
    public void setAmount(String amount) {
        this.amount = amount;
    }

    @JsonProperty("currency")
    public String getCurrency() {
        return currency;
    }

    @JsonProperty("currency")
    public void setCurrency(String currency) {
        this.currency = currency;
    }

    @JsonProperty("reason")
    public String getReason() {
        return reason;
    }

    @JsonProperty("reason")
    public void setReason(String reason) {
        this.reason = reason;
    }

    @JsonProperty("network_reason_code")
    public String getNetworkReasonCode() {
        return networkReasonCode;
    }

    @JsonProperty("network_reason_code")
    public void setNetworkReasonCode(String networkReasonCode) {
        this.networkReasonCode = networkReasonCode;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("evidence_due_by")
    public String getEvidenceDueBy() {
        return evidenceDueBy;
    }

    @JsonProperty("evidence_due_by")
    public void setEvidenceDueBy(String evidenceDueBy) {
        this.evidenceDueBy = evidenceDueBy;
    }

    @JsonProperty("evidence_sent_on")
    public String getEvidenceSentOn() {
        return evidenceSentOn;
    }

    @JsonProperty("evidence_sent_on")
    public void setEvidenceSentOn(String evidenceSentOn) {
        this.evidenceSentOn = evidenceSentOn;
    }

    @JsonProperty("finalized_on")
    public String getFinalizedOn() {
        return finalizedOn;
    }

    @JsonProperty("finalized_on")
    public void setFinalizedOn(String finalizedOn) {
        this.finalizedOn = finalizedOn;
    }

    @JsonProperty("initiated_at")
    public String getInitiatedAt() {
        return initiatedAt;
    }

    @JsonProperty("initiated_at")
    public void setInitiatedAt(String initiatedAt) {
        this.initiatedAt = initiatedAt;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
