package com.mobikasa.siftintegration.service;

import org.springframework.stereotype.Service;

@Service
public interface DecisionService {

    void processDecision(String decisionId,Long storeId,Long orderId);

    void saveWebhookData(Long shopId, Long orderId, String decisionData, String event);
}

