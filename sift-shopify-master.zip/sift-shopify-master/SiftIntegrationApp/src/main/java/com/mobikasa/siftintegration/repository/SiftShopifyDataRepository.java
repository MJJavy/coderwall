package com.mobikasa.siftintegration.repository;

import com.mobikasa.siftintegration.entity.SiftDataEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface SiftShopifyDataRepository extends JpaRepository<SiftDataEntity, Long> {

    Optional<SiftDataEntity> findByOrderIdAndEvent(String orderId, String event);
}
