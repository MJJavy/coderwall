package com.mobikasa.siftintegration.service.impl;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.consumer.TransactionConsumer;
import com.mobikasa.siftintegration.entity.ShopEntity;
import com.mobikasa.siftintegration.entity.SiftDataEntity;
import com.mobikasa.siftintegration.exception.BaseException;
import com.mobikasa.siftintegration.exception.BusinessException;
import com.mobikasa.siftintegration.repository.ShopRepository;
import com.mobikasa.siftintegration.repository.ShopifyDataRepository;
import com.mobikasa.siftintegration.service.TransactionService;
import com.mobikasa.siftintegration.service.ValidationService;
import com.mobikasa.siftintegration.util.Hmac;

@Service
public class TransactionServiceImpl implements TransactionService {

	@Autowired
	private ShopifyDataRepository shopifyDataRepository;

	@Autowired
	private ObjectMapper mapper;

	@Autowired
	private ShopRepository shopRepository;

	@Autowired
	private TransactionConsumer transactionConsumer;

	@Autowired
	private ValidationService validationService;

	@Value("${app.install.secretkey}")
	private String secretKey;

	@Override
	public ResponseEntity<?> createTransaction(Map<String, String> headers, String transactionData) throws Exception {
		try {

			ShopEntity shopEntity = shopRepository.findByDomain(headers.get("x-shopify-shop-domain"));
			boolean flag = validationService.validateHmac(headers, transactionData, shopEntity);

			if (!flag) {
				throw new BusinessException("Invalid Hmac", BaseException.BUSSINESS_TYP);
			}

			
			SiftDataEntity shopDataEntity = mapCustomerObjectToEntity(transactionData, "Transaction Creation");
			shopDataEntity.setStoreId(shopEntity.getId());
			shopifyDataRepository.save(shopDataEntity);
			
			if(validationService.validateShopifyWebhook(headers, transactionData, shopEntity)) {
				transactionConsumer.createTransaction(shopDataEntity.getId());
			}	
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(null, HttpStatus.CREATED);

	}

	private SiftDataEntity mapCustomerObjectToEntity(String customerData, String event) throws IOException {
		SiftDataEntity shopifyDataEntity = new SiftDataEntity();
		Map<String, Object> map = mapper.readValue(customerData, Map.class);
		try {
			shopifyDataEntity.setOrderId((map.get("id").toString()));
			shopifyDataEntity.setEvent(event);
			shopifyDataEntity.setData(customerData);
			shopifyDataEntity.setCreatedAt(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return shopifyDataEntity;
	}

}