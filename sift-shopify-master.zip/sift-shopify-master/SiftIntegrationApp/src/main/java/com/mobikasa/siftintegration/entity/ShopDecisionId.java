package com.mobikasa.siftintegration.entity;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import java.io.Serializable;

@Embeddable
public class ShopDecisionId implements Serializable {

    private static final long serialVersionUID = 1L;

    public ShopDecisionId() {}
    
    public ShopDecisionId(String decisionId, Long shopId) {
        this.decisionId = decisionId;
        this.shopId = shopId;
    }

    @Column(name = "decision_id")
    private String decisionId;
    @Column(name = "shop_id")
    private Long shopId;

    public String getDecisionId() {
        return decisionId;
    }

    public void setDecisionId(String decisionId) {
        this.decisionId = decisionId;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }
}
