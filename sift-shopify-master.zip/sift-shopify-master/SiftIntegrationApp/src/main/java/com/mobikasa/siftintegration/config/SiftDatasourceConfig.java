package com.mobikasa.siftintegration.config;

import java.util.Properties;

import javax.persistence.EntityManagerFactory;
import javax.sql.DataSource;

import com.mobikasa.siftintegration.constant.SiftDatasourceConfigConstants;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Profile;
import org.springframework.dao.annotation.PersistenceExceptionTranslationPostProcessor;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.jdbc.datasource.DriverManagerDataSource;
import org.springframework.orm.jpa.JpaTransactionManager;
import org.springframework.orm.jpa.JpaVendorAdapter;
import org.springframework.orm.jpa.LocalContainerEntityManagerFactoryBean;
import org.springframework.orm.jpa.vendor.HibernateJpaVendorAdapter;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.annotation.EnableTransactionManagement;

@Configuration
@ConfigurationProperties(SiftDatasourceConfigConstants.SPRING_DATASOURCE)
@EnableTransactionManagement
@EnableJpaRepositories(basePackages = SiftDatasourceConfigConstants.REPOSITORY_BASEPACKAGE)
@EntityScan(SiftDatasourceConfigConstants.ENTITIES_PACKAGE)
public class SiftDatasourceConfig {

    private String driverClassName;
    private String url;
    private String username;
    private String password;

    public String getDriverClassName() {
        return driverClassName;
    }

    public void setDriverClassName(String driverClassName) {
        this.driverClassName = driverClassName;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Profile(SiftDatasourceConfigConstants.PROFILE_VALUE)
    public DataSource dataSource() {
        DriverManagerDataSource dataSource = new DriverManagerDataSource();
        dataSource.setDriverClassName(driverClassName);
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        return dataSource;
    }

    @Bean
    public LocalContainerEntityManagerFactoryBean entityManagerFactory() {
        LocalContainerEntityManagerFactoryBean entityManagerFactory = new LocalContainerEntityManagerFactoryBean();
        entityManagerFactory.setDataSource(dataSource());
        entityManagerFactory
                .setPackagesToScan(SiftDatasourceConfigConstants.ENTITIES_PACKAGE, SiftDatasourceConfigConstants.CONFIG_PACKAGE);
        JpaVendorAdapter jpaVendorAdapter = new HibernateJpaVendorAdapter();
        entityManagerFactory.setJpaVendorAdapter(jpaVendorAdapter);
        entityManagerFactory.setJpaProperties(additionalProperties());
        return entityManagerFactory;
    }

    @Bean
    public PlatformTransactionManager transactionManager(EntityManagerFactory entityManagerFactory) {
        JpaTransactionManager transactionManager = new JpaTransactionManager();
        transactionManager.setEntityManagerFactory(entityManagerFactory);
        return transactionManager;
    }

    @Bean
    public PersistenceExceptionTranslationPostProcessor exceptionTranslation() {
        return new PersistenceExceptionTranslationPostProcessor();
    }

    @Bean
    Properties additionalProperties() {
        Properties properties = new Properties();
        properties.setProperty(SiftDatasourceConfigConstants.HIBERNATE_DIALECT, SiftDatasourceConfigConstants.HIBERNATE_DIALECT_POSTGRESQL);
        properties.setProperty(SiftDatasourceConfigConstants.SHOW_SQL, SiftDatasourceConfigConstants.TRUE_VALUE);
        properties.setProperty(SiftDatasourceConfigConstants.HIBERNATE_FORMAT_SQL, SiftDatasourceConfigConstants.TRUE_VALUE);
        properties.setProperty(SiftDatasourceConfigConstants.HIBERNATE_CONTEXTUAL_CREATION, SiftDatasourceConfigConstants.TRUE_VALUE);
        properties.setProperty(SiftDatasourceConfigConstants.SPRING_JPA_PROPERTIES, SiftDatasourceConfigConstants.FALSE_VALUE);
        return properties;
    }

}
