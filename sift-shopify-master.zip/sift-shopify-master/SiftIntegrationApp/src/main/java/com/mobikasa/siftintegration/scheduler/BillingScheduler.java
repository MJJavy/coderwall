package com.mobikasa.siftintegration.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mobikasa.siftintegration.service.BillingService;

@Component
public class BillingScheduler {

	@Autowired
	private BillingService billingService;

	@Scheduled(cron = "${billing.scheduler.cron}")
	@Transactional(propagation = Propagation.REQUIRES_NEW)
	public void calculateAndSaveUsageCharges() {
		billingService.calculateAndSaveUsageCharges();
	}
}
