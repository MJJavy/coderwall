package com.mobikasa.siftintegration.util;

import com.mobikasa.siftintegration.dto.Mail;
import freemarker.template.Configuration;
import freemarker.template.Template;
import freemarker.template.TemplateException;
import org.apache.tomcat.util.http.fileupload.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.ClassPathResource;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.JavaMailSenderImpl;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Service;
import org.springframework.ui.freemarker.FreeMarkerTemplateUtils;

import javax.activation.DataHandler;
import javax.activation.DataSource;
import javax.mail.BodyPart;
import javax.mail.MessagingException;
import javax.mail.Multipart;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeBodyPart;
import javax.mail.internet.MimeMessage;
import javax.mail.internet.MimeMultipart;
import javax.mail.util.ByteArrayDataSource;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.Map;

@Service
public class MailSender {
    
	@Value("${email.header.image}")
    private String imagePath;

	@Autowired
	private JavaMailSender emailSender;
	
	@Autowired
	@Qualifier("emailConfigBean")
	private Configuration emailConfig;
	
	@Value("${mail.fromMail}")
    private String fromMail;


	@SuppressWarnings({ "rawtypes", "unchecked" })
	public void sendEmail(Mail mailModel) throws MessagingException, IOException, TemplateException {

        Map model = new HashMap();
        model.put("name", mailModel.getName());
        model.put("location", "US");
        model.put("signature", "Sift Team");
        if(mailModel.getContent().containsKey("url"))
        model.put("url", mailModel.getContent().get("url"));
        if(mailModel.getContent().containsKey("orderNo"))
        model.put("orderNo", mailModel.getContent().get("orderNo"));
        if(mailModel.getContent().containsKey("amount"))
        model.put("amount", mailModel.getContent().get("amount"));
        if(mailModel.getContent().containsKey("score"))
        model.put("score", mailModel.getContent().get("score"));
        MimeMessage message = emailSender.createMimeMessage();
        MimeMessageHelper mimeMessageHelper = new MimeMessageHelper(message, MimeMessageHelper.MULTIPART_MODE_RELATED, "UTF-8");
        Template template = emailConfig.getTemplate(mailModel.getContent().get("templateName"));
        String html = FreeMarkerTemplateUtils.processTemplateIntoString(template, model);
        mimeMessageHelper.setFrom(fromMail);
        mimeMessageHelper.setTo(mailModel.getTo());
        mimeMessageHelper.setText(html, true);
        mimeMessageHelper.setSubject("Sift Notification");
        MimeBodyPart messageBodyPart = new MimeBodyPart();
        messageBodyPart.setContent(html, "text/html");
        Multipart multipart = new MimeMultipart();
        multipart.addBodyPart(messageBodyPart);
        MimeBodyPart imagePart = new MimeBodyPart();
        imagePart.setHeader("Content-ID", "<image>");
        imagePart.setDisposition(MimeBodyPart.INLINE);
        try {
            File f = new File(imagePath);
            imagePart.attachFile(f);
            multipart.addBodyPart(imagePart);
        } catch (Exception e) {
            e.printStackTrace();
        }
        message.setContent(multipart);
        emailSender.send(message);
    }

}
