package com.mobikasa.siftintegration.service;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.mobikasa.siftintegration.entity.ShopEntity;

@Service
public interface OrderService {
	
    public ResponseEntity<?> createOrder(Map<String, String> headers, String orderData) throws Exception;

    public ResponseEntity<?> updateOrder(Map<String, String> headers, String orderData) throws Exception;

    public void saveSeesionData(String shop, String token, String session) throws Exception;

    Long getShopIdfromOrderId(Long orderId);

    String getEnvironment(Long shopId);

    public ResponseEntity<?> createRefundTransaction(Map<String, String> headers, String orderData, String status, String webhookType) throws Exception;

}
