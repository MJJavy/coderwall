package com.mobikasa.siftintegration.controller;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.service.OrderService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("orders")
@RestController
public class OrderController {

	@Autowired
	private OrderService OrderService;

	@PostMapping(value = "/create")
	public ResponseEntity<Object> createOrder(@RequestHeader Map<String, String> headers, @RequestBody String orderData) {
		try {
			OrderService.createOrder(headers, orderData);
		} catch (Exception exp) {

		}
		return new ResponseEntity<Object>(null, HttpStatus.OK);
	}

	@PostMapping(value = "/update")
	public ResponseEntity<Object> updateOrder(@RequestHeader Map<String, String> headers, @RequestBody String orderData) {
		try {
			OrderService.updateOrder(headers, orderData);
		} catch (Exception exp) {

		}
		return new ResponseEntity<Object>(null, HttpStatus.OK);
	}

	/*
	 * @PostMapping(value = "/cancelled") public ResponseEntity<Object>
	 * cancelOrder(@RequestHeader Map<String, String> headers, @RequestBody String
	 * orderData) { try { OrderService.updateOrderStatus(headers, orderData,
	 * "$canceled", "orders/canceled"); } catch (Exception exp) {
	 * 
	 * } return new ResponseEntity<>(null, HttpStatus.OK); }
	 * 
	 * @PostMapping(value = "/fulfilled") public ResponseEntity<Object>
	 * fulfilledOrder(@RequestHeader Map<String, String> headers, @RequestBody
	 * String orderData) { try { OrderService.updateOrderStatus(headers, orderData,
	 * "$fulfilled", "orders/fulfilled"); } catch (Exception exp) {
	 * 
	 * } return new ResponseEntity<Object>(null, HttpStatus.OK); }
	 */

	@RequestMapping("sendSessionDetail")
	public ResponseEntity<Object> getSessionDetail(@RequestBody String sessionData) {
		String beaconTag = "";
		try {
			ObjectMapper mapper = new ObjectMapper();
			Map<String, String> obj = mapper.readValue(sessionData, Map.class);
			
			OrderService.saveSeesionData(obj.get("shop"), obj.get("token"), obj.get("_session_id"));
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<Object>(beaconTag, HttpStatus.OK);
	}
}
