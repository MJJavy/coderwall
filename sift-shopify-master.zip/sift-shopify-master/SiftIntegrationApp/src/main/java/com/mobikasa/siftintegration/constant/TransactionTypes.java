package com.mobikasa.siftintegration.constant;

public enum TransactionTypes {

    authorization("$authorize");

    TransactionTypes(String transactionType) {
        this.transactionType = transactionType;
    }

    private String transactionType;

    public String getTransactionType() {
        return transactionType;
    }

    public TransactionTypes setTransactionType(String transactionType) {
        this.transactionType = transactionType;
        return this;
    }
}