package com.mobikasa.siftintegration.entity;

import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;

@Entity
@Table(name = "shop_sift_config")
public class SiftConfigEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id", unique = true, nullable = false)
    private Long id;

    @Column(name = "shop_id")
    private Long shopId;

    @Column(name = "sift_enable")
    private String siftEnable;

    private String environment;

    @Column(name = "production_account_id")
    private String productionAccountId;

    @Column(name = "production_api_key")
    private String productionApiKey;

    @Column(name = "production_api_beacon_key")
    private String productionApiBeaconKey;

    @Column(name = "staging_account_id")
    private String stagingAccountId;

    @Column(name = "staging_api_key")
    private String stagingApiKey;

    @Column(name = "staging_api_beacon_key")
    private String stagingApiBeaconKey;

    @Column(name = "bad_order_key")
    private String badOrderKey;

    @Column(name = "watch_order_key")
    private String watchOrderKey;
    
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getShopId() {
        return shopId;
    }

    public void setShopId(Long shopId) {
        this.shopId = shopId;
    }

    public String getSiftEnable() {
        return siftEnable;
    }

    public void setSiftEnable(String siftEnable) {
        this.siftEnable = siftEnable;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getProductionApiBeaconKey() {
        return productionApiBeaconKey;
    }

    public void setProductionApiBeaconKey(String productionApiBeaconKey) {
        this.productionApiBeaconKey = productionApiBeaconKey;
    }

    public String getStagingAccountId() {
        return stagingAccountId;
    }

    public void setStagingAccountId(String stagingAccountId) {
        this.stagingAccountId = stagingAccountId;
    }

    public String getStagingApiKey() {
        return stagingApiKey;
    }

    public void setStagingApiKey(String stagingApiKey) {
        this.stagingApiKey = stagingApiKey;
    }

    public String getStagingApiBeaconKey() {
        return stagingApiBeaconKey;
    }

    public void setStagingApiBeaconKey(String stagingApiBeaconKey) {
        this.stagingApiBeaconKey = stagingApiBeaconKey;
    }

    public String getBadOrderKey() {
        return badOrderKey;
    }

    public void setBadOrderKey(String badOrderKey) {
        this.badOrderKey = badOrderKey;
    }

    public String getWatchOrderKey() {
        return watchOrderKey;
    }

    public void setWatchOrderKey(String watchOrderKey) {
        this.watchOrderKey = watchOrderKey;
    }


    public String getProductionAccountId() {
        return productionAccountId;
    }

    public void setProductionAccountId(String productionAccountId) {
        this.productionAccountId = productionAccountId;
    }

    public String getProductionApiKey() {
        return productionApiKey;
    }

    public void setProductionApiKey(String productionApiKey) {
        this.productionApiKey = productionApiKey;
    }
	
	public String getSiftEnvironmentName() {
		return this.getEnvironment().equals("1") ? "Production" : "Staging";
	}

}