package com.mobikasa.siftintegration.consumer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.*;

import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.CREATE;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.UPDATE;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.REFUNDED;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.VOIDED;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.CANCELLED;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.REVIEW_QUEUE;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.ENVIRONMENT;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.THIRTY_SECOND;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.PAYMENT_ABUSE;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.INT_ZERO;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.INT_ONE;
import static com.mobikasa.siftintegration.constant.SiftApplicationConstant.MICRO_CONVERTER;

import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.dto.Mail;
import com.mobikasa.siftintegration.entity.*;
import com.mobikasa.siftintegration.repository.*;
import com.mobikasa.siftintegration.service.BillingService;
import com.mobikasa.siftintegration.service.ShopService;
import com.mobikasa.siftintegration.util.MailSender;
import com.mobikasa.siftintegration.util.RabbitMQPublisher;
import com.siftscience.*;
import com.siftscience.model.*;
import org.apache.http.HttpStatus;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.gson.Gson;
import com.mobikasa.siftintegration.ShopifyUpdateOrder;
import com.mobikasa.siftintegration.dto.LineItem;
import com.mobikasa.siftintegration.dto.Order;
import com.mobikasa.siftintegration.util.CommonUtil;

@Component
public class OrderConsumer {

    @Autowired
    private SiftShopifyDataRepository shopifyDataRepository;
    @Autowired
    private ObjectMapper mapper;
    @Autowired
    private SiftConfigRepository siftConfigRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private ShopifyUpdateOrder shopifyUpdateOrder;
    @Autowired
    private DecisionRepository decisionRepository;
    @Autowired
    private DecisionConsumer decisionConsumer;
    @Autowired
    private TransactionConsumer transactionConsumer;
    @Autowired
    private TokenSessionRepository tokenSessionRepository;
    @Autowired
    private RabbitMQPublisher rabbitMQPublisher;
    @Autowired
    private ShopRepository shopRepository;
    @Autowired
    private MailSender mailSender;
    @Autowired
    private BillingService billingService;

    private String apiKey = null;
    private String accountId = null;
    private String sessionId = "789234";

    @Async("fixedThreadPool")
    public void processTransactionAndOrder(Long id) {
        Gson g = new Gson();
        OrderEntity orderEntity = null;
        Order order = null;
        try {
            Optional<SiftDataEntity> shopifyDataEntity = shopifyDataRepository.findById(id);
            order = g.fromJson(shopifyDataEntity.get().getData(), Order.class);
            if (order != null) {
                saveOrder(order, shopifyDataEntity.get().getStoreId());
                Thread.sleep(5000);
                order = updateSessionId(order);
                transactionConsumer.sendTransactions(order);
                createUpdateOrder(shopifyDataEntity.get().getId(), CREATE);
            }
        } catch (Exception e) {
            System.out.println("Error occured in " + id);
            e.printStackTrace();
        }
    }

    public void createUpdateOrder(Long id, String orderType) {
        EventResponse response = null;
        Order order = null;
        Date date = new Date();
        Optional<SiftDataEntity> shopifyDataEntity = shopifyDataRepository.findById(id);
        Gson g = new Gson();
        Map<String, Object> map = null;
        try {
            order = g.fromJson(shopifyDataEntity.get().getData(), Order.class);
        } catch (Exception e) {
            System.out.println("Error occured in " + id);
            e.printStackTrace();
        }
        if (order != null) {
            Optional<List<OrderEntity>> orderEntity = orderRepository.findByOrderId(order.getId());
            SiftClient siftClient = CommonUtil.createSiftClient(orderEntity.get().get(0).getShopId());
            if (orderType.equals(CREATE) && billingService.isCreditAvailable(orderEntity.get().get(0).getShopId())) {
                System.out.println("Create Order Request Received");
                order = updateSessionId(order);
                response = createOrderInSift(order, orderEntity.get().get(0).getShopId(), orderEntity.get().get(0).getEnvironment());
                System.out.println("Create Order in SIft DOne");
            } else {
                System.out.println("Update Order Request Received");
                if (order.getUpdated_at().getTime() - order.getCreated_at().getTime() > THIRTY_SECOND) {
                    System.out.println("Update Order Request in SIft");
                    response = updateOrderInSift(order, orderEntity.get().get(0).getShopId());
                    if (order.getFinancial_status().equals(REFUNDED) || order.getFinancial_status().equals(VOIDED)) {
                        String userId = order.getCustomer().getId().toString();
                        String orderId = order.getId();
                        System.out.println("Update Order Status Start");
                        this.updateOrderStatus(orderEntity.get().get(0).getShopId(), userId, orderId, CANCELLED);
                        System.out.println("Update Order Status DOne");
                        if (!orderEntity.get().get(0).getActionTaken().equals("BLOCK")) {
                            decisionConsumer.applyDecisionForOrder(siftClient, orderEntity.get().get(0), "cancel_order_payment_abuse");
                            orderEntity.get().get(0).setActionTaken("BLOCK");
                            orderRepository.save(orderEntity.get().get(0));
                        }
                    }
                }
                System.out.println("Update Order Request Done");
            }
            if (response != null && response.getHttpStatusCode() == HttpStatus.SC_OK && orderType.equals(CREATE)) {
                orderEntity = orderRepository.findByOrderId(order.getId());
                if (orderType.equals(CREATE)) {
                    DecisionEntity decisionEntity = checkAndUpdateDecisions(response.getWorkflowStatus(0).getHistory().get(0).getConfig().getDecisionId(), shopifyDataEntity.get().getStoreId());
                    if (decisionEntity != null) {
                        shopifyUpdateOrder.updateShopifyOrder(shopifyDataEntity.get().getStoreId(), Long.parseLong(orderEntity.get().get(0).getOrderId()), BigDecimal.valueOf(response.getScore(PAYMENT_ABUSE) * 100).setScale(0, RoundingMode.UP), decisionEntity.getCategory());
                        orderEntity.get().get(0).setActionTaken(decisionEntity.getCategory());
                    }
                    orderEntity.get().get(0).setStatus(INT_ONE);
                    orderEntity.get().get(0).setSiftScore(BigDecimal.valueOf(response.getScore(PAYMENT_ABUSE) * 100).setScale(0, RoundingMode.UP));
                    orderEntity.get().get(0).setUpdDate(new Date());
                    orderEntity.get().get(0).setDecision(response.getWorkflowStatus(0).getHistory().get(0).getConfig().getDecisionId() == null ? "" : response.getWorkflowStatus(0).getHistory().get(0).getConfig().getDecisionId());
                    orderRepository.save(orderEntity.get().get(0));
                    System.out.println("==========Update Order Request Done");
                    if (response.getWorkflowStatus(0).getHistory().get(0).getApp().equals(REVIEW_QUEUE)) {
                        sendMailForOrderReview(orderEntity.get().get(0));
                        shopifyUpdateOrder.updateShopifyOrder(shopifyDataEntity.get().getStoreId(), Long.parseLong(orderEntity.get().get(0).getOrderId()), BigDecimal.valueOf(response.getScore(PAYMENT_ABUSE) * 100).setScale(0, RoundingMode.UP), "WATCH");
                    }
                }
                if (orderEntity.get().get(0).getEnvironment() != INT_ONE) {
                    rabbitMQPublisher.sendOrderForBilling(order.getId(), orderEntity.get().get(0).getShopId());
                }
            }
        }
    }

    public void sendMail(String orderId, String shopId) {
        sendMailForOrderReview(orderRepository.findOneByOrderId(orderId).get());
    }

    private void sendMailForOrderReview(OrderEntity orderEntity) {
        Mail mailData = new Mail();
        Optional<ShopEntity> shopEntity = shopRepository.findById(orderEntity.getShopId());
        createMailContent(mailData, shopEntity, orderEntity);
        try {
            mailSender.sendEmail(mailData);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void createMailContent(Mail mailData, Optional<ShopEntity> shopEntity, OrderEntity orderEntity) {
        Map<String, String> cont = new HashMap<>();
        cont.put("orderNo", orderEntity.getOrderNo());
        cont.put("amount", "$" + orderEntity.getAmount().toString());
        cont.put("score", orderEntity.getSiftScore().toString());
        cont.put("templateName", "review.html");
        cont.put("url", "");
        mailData.setContent(cont);
        mailData.setTo(shopEntity.get().getEmail());
        mailData.setName(shopEntity.get().getOwner());
    }

    private Order updateSessionId(Order order) {
        Order updtedOrder = order;
        try {
            if (StringUtils.hasText(order.getCart_token())) {
                List<TokenSessionEntity> tokenSessionEntity = tokenSessionRepository.findByToken(order.getCart_token());
                updtedOrder.setSessionId(tokenSessionEntity.get(0).getSessionId());
            } else {
                updtedOrder.setSessionId(sessionId);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return updtedOrder;
    }

    private EventResponse createOrderInSift(Order order, Long storeId, int environment) {
        List<Item> lineItems = prepareLineItems(order);
        SiftClient siftClient = CommonUtil.createSiftClient(storeId);
        List<PaymentMethod> paymentMethods = createPaymentMethod(order);
        ObjectMapper Obj = new ObjectMapper();
        EventRequest request = null;
        EventResponse response = null;
        Browser browser = createBrowserData(order);
        List<Promotion> promotions = createPromotionsList(order);
        try {
            request = siftClient.buildRequest(new CreateOrderFieldSet()
                    .setUserId(order.getCustomer().getId().toString())
                    .setSessionId(order.getSessionId())
                    .setOrderId(order.getId())
                    .setUserEmail(order.getEmail())
                    .setAmount(CommonUtil.parseLong(order.getTotal_price()) * MICRO_CONVERTER)
                    .setCurrencyCode(order.getCurrency())
                    .setPaymentMethods(paymentMethods)
                    .setBrowser(browser)
                    .setPromotions(promotions)
                    .setBillingAddress(new Address()
                            .setName(order.getBilling_address().getFirst_name() + " " + order.getBilling_address().getLast_name())
                            .setPhone(order.getBilling_address().getPhone())
                            .setAddress1(order.getBilling_address().getAddress1())
                            .setAddress2(order.getBilling_address().getAddress2() == null ? "" : order.getBilling_address().getAddress2())
                            .setCity(order.getBilling_address().getCity())
                            .setRegion(order.getBilling_address().getProvince_code())
                            .setCountry("US")
                            .setZipCode(order.getBilling_address().getZip()))
                    .setShippingAddress(new Address()
                            .setName(order.getShipping_address().getFirst_name() + " " + order.getShipping_address().getLast_name())
                            .setPhone(order.getShipping_address().getPhone())
                            .setAddress1(order.getShipping_address().getAddress1())
                            .setAddress2(order.getShipping_address().getAddress2() == null ? "" : order.getShipping_address().getAddress2())
                            .setCity(order.getShipping_address().getCity())
                            .setRegion(order.getShipping_address().getProvince_code())
                            .setCountry("US")
                            .setZipCode(order.getShipping_address().getZip()))
                    .setItems(lineItems).setCustomField("platform_name", "shopify")).withWorkflowStatus().withScores("payment_abuse");
            ApiLogEntity apiLog = CommonUtil.createApiLog("create_order", Obj.writeValueAsString(request.getFieldSet()), storeId, "");
            response = request.send();
            CommonUtil.updateApiLog(apiLog, Obj.writeValueAsString(response.getBody()));
        } catch (Exception e) {
            e.printStackTrace();
            return response;
        }
        return response;
    }

    private List<Promotion> createPromotionsList(Order order) {
        List<Promotion> promotions = new ArrayList<>();
        order.getDiscount_applications().forEach(discountApplication -> {
            Promotion promotion = new Promotion();
            promotion.setPromotionId(discountApplication.getCode());
            promotion.setStatus("$success");
            promotion.setDiscount(new Discount()
                    .setAmount(Long.parseLong(String.valueOf((new Double(order.getTotal_discounts()).intValue() * MICRO_CONVERTER))))

                    .setCurrencyCode("USD"));
            promotions.add(promotion);
        });
        return promotions;
    }

    private Browser createBrowserData(Order order) {
        Browser browser = null;
        try {
            browser = new Browser().setAcceptLanguage(order.getClient_details().getAccept_language()
            ).setContentLanguage(order.getClient_details().getAccept_language())
                    .setUserAgent(order.getClient_details().getUser_agent());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return browser;
    }

    private List<PaymentMethod> createPaymentMethod(Order order) {
        List<PaymentMethod> paymentMethods = new ArrayList<>();
        PaymentMethod paymentMethod = new PaymentMethod();
        paymentMethod.setCardBin(order.getPayment_details().getCredit_card_bin());
        paymentMethod.setCardLast4(order.getPayment_details().getCredit_card_number().substring(order.getPayment_details().getCredit_card_number().length() - 4));
        paymentMethod.setPaymentGateway("$" + order.getGateway());
        paymentMethod.setPaymentType("$credit_card");
        paymentMethod.setAvsResultCode(order.getPayment_details().getAvs_result_code());
        paymentMethod.setCvvResultCode(order.getPayment_details().getCvv_result_code());
        paymentMethods.add(paymentMethod);
        return paymentMethods;
    }

    private DecisionEntity checkAndUpdateDecisions(String decisionId, Long shopId) {
        Optional<DecisionEntity> decisionEntity = null;
        if (decisionId != null) {
            decisionEntity = decisionRepository.findById(new ShopDecisionId(decisionId, shopId));
            if (!decisionEntity.isPresent()) {
                decisionConsumer.updateDecision(shopId);
                decisionEntity = decisionRepository.findById(new ShopDecisionId(decisionId, shopId));
                return decisionEntity.get();
            } else {
                decisionConsumer.updateDecision(shopId);
                decisionEntity = decisionRepository.findById(new ShopDecisionId(decisionId, shopId));
                return decisionEntity.get();
            }
        }
        return null;
    }

    private EventResponse updateOrderInSift(Order order, Long storeId) {
        List<Item> lineItems = prepareLineItems(order);
        SiftClient siftClient = CommonUtil.createSiftClient(storeId);
        EventRequest request = null;
        EventResponse response = null;
        ObjectMapper Obj = new ObjectMapper();
        try {
            request = siftClient.buildRequest(new UpdateOrderFieldSet()
                    .setUserId(order.getCustomer().getId().toString())
                    .setSessionId(sessionId)
                    .setOrderId(order.getId())
                    .setUserEmail(order.getEmail())
                    .setAmount(CommonUtil.parseLong(order.getTotal_price()) * MICRO_CONVERTER)
                    .setCurrencyCode(order.getCurrency())
                    .setBillingAddress(new Address()
                            .setName(order.getBilling_address().getFirst_name() + " " + order.getBilling_address().getLast_name())
                            .setAddress1(order.getBilling_address().getAddress1())
                            .setAddress2(order.getBilling_address().getAddress2() == null ? "" : order.getBilling_address().getAddress2())
                            .setCity(order.getBilling_address().getCity())
                            .setRegion(order.getBilling_address().getProvince_code())
                            .setCountry("US")
                            .setZipCode(order.getBilling_address().getZip()))
                    .setShippingAddress(new Address()
                            .setName(order.getShipping_address().getFirst_name() + " " + order.getShipping_address().getLast_name())
                            .setAddress1(order.getShipping_address().getAddress1())
                            .setAddress2(order.getShipping_address().getAddress2() == null ? "" : order.getShipping_address().getAddress2())
                            .setCity(order.getShipping_address().getCity())
                            .setRegion(order.getShipping_address().getProvince_code())
                            .setCountry("US")
                            .setZipCode(order.getShipping_address().getZip()))
                    .setItems(lineItems)).withWorkflowStatus().withForceWorkflowRun().withScores("payment_abuse");
            ApiLogEntity apiLog = CommonUtil.createApiLog("update_order", Obj.writeValueAsString(request.getFieldSet()), storeId, "");
            response = request.send();
            CommonUtil.updateApiLog(apiLog, Obj.writeValueAsString(response.getBody()));
        } catch (Exception e) {
            e.printStackTrace();
            return response;
        }
        return response;
    }

    private List<Item> prepareLineItems(Order order) {
        List<Item> lineItems = new ArrayList<Item>();
        order.getLine_items().forEach(lineItem -> {
            lineItems.add(getOrderLines(lineItem, order));
        });
        return lineItems;
    }

    private Item getOrderLines(LineItem lineItem, Order order) {
        return new Item()
                .setItemId(lineItem.getProduct_id())
                .setProductTitle(lineItem.getTitle())
                .setPrice(CommonUtil.parseLong(lineItem.getPrice()) * MICRO_CONVERTER)
                .setSku(lineItem.getSku())
                .setCategory(lineItem.getVariant_title())
                .setQuantity(CommonUtil.parseLong(lineItem.getQuantity()))
                .setCurrencyCode(order.getCurrency());
    }

    @Autowired
    private ShopService shopService;

    private OrderEntity saveOrder(Order order, Long storeId) {
        Map<String, String> shopConfigMap = shopService.fetchShopConfig(storeId);
        OrderEntity orderEntity = new OrderEntity();
        try {
            Optional<OrderEntity> existingOrder = orderRepository.findOneByOrderId(order.getId());
            if (existingOrder.isPresent()) {
                existingOrder.get().setAmount(CommonUtil.parseBigDecimal(order.getTotal_price()));
                existingOrder.get().setOrderUpdDate(order.getUpdated_at());
                existingOrder.get().setUpdDate(new Date());
                orderRepository.save(existingOrder.get());
            } else {
                orderEntity.setOrderNo(order.getOrder_number());
                orderEntity.setOrderId(order.getId());
                orderEntity.setShopId(storeId);
                orderEntity.setAmount(CommonUtil.parseBigDecimal(order.getTotal_price()));
                orderEntity.setOrderCrtDate(order.getCreated_at());
                orderEntity.setOrderUpdDate(order.getUpdated_at());
                orderEntity.setCustomerId(order.getCustomer().getId().toString());
                orderEntity.setCustomerName(order.getBilling_address().getName());
                orderEntity.setEmail(order.getEmail());
                orderEntity.setStatus(INT_ZERO);
                orderEntity.setCrtDate(new Date());
                orderEntity.setUpdDate(new Date());
                orderEntity.setEnvironment(CommonUtil.parseInt(shopConfigMap.get(ENVIRONMENT)));
                orderEntity.setGateway(order.getGateway());
                orderRepository.save(orderEntity);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderEntity;
    }

    public void updateOrderStatus(Long shopId, String userId, String orderId, String orderStatus) {
        SiftClient siftClient = CommonUtil.createSiftClient(shopId);
        EventRequest request = siftClient.buildRequest(new OrderStatusFieldSet()
                .setUserId(userId)
                .setOrderId(orderId)
                .setOrderStatus(orderStatus));
        EventResponse response;
        try {
            response = request.send();
        } catch (Exception e) {
            e.printStackTrace();
            return;
        }
        response.isOk();
    }


    public void processUpdateOrder(Long id) {
        Gson g = new Gson();
        OrderEntity orderEntity = null;
        Order order = null;
        try {
            Optional<SiftDataEntity> shopifyDataEntity = shopifyDataRepository.findById(id);
            order = g.fromJson(shopifyDataEntity.get().getData(), Order.class);
            Optional<OrderEntity> existingOrder = orderRepository.findOneByOrderId(order.getId());
            if (order != null && existingOrder.isPresent()) {
                saveOrder(order, shopifyDataEntity.get().getStoreId());
                createUpdateOrder(shopifyDataEntity.get().getId(), UPDATE);
            }
        } catch (Exception e) {
            System.out.println("Error occured in " + id);
            e.printStackTrace();
        }
    }
}