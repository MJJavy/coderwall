package com.mobikasa.siftintegration.repository;

import com.mobikasa.siftintegration.entity.DecisionEntity;
import com.mobikasa.siftintegration.entity.ShopDecisionId;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface DecisionRepository extends JpaRepository<DecisionEntity, ShopDecisionId> {
}
