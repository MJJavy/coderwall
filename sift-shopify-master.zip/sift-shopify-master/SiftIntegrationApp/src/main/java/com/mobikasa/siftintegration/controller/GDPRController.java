package com.mobikasa.siftintegration.controller;

import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RequestMapping("")
@RestController
public class GDPRController {


        @PostMapping(value = "/customers/redact")
        public ResponseEntity customerRedact() {
            try {
            	
            } catch(Exception exp) {
            	exp.printStackTrace();
            }
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        
        @PostMapping(value = "/shop/redact")
        public ResponseEntity shopRedact() {
            try {
            	
            } catch(Exception exp) {
            	exp.printStackTrace();
            }
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
        
        @PostMapping(value = "/customers/data_request")
        public ResponseEntity customerDataRequest() {
            try {
            	
            } catch(Exception exp) {
            	exp.printStackTrace();
            }
            return new ResponseEntity<>(null, HttpStatus.OK);
        }
}
