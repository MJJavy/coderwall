package com.mobikasa.siftintegration.service;

import java.util.Map;

import com.mobikasa.siftintegration.entity.ShopEntity;


public interface ValidationService {
	
	public boolean validateHmac(Map<String, String> headers, String data, ShopEntity shopEntity) throws Exception;
	
    public boolean validateShopifyWebhook(Map<String, String> headers, String data, ShopEntity shopEntity) throws Exception;
    
}
