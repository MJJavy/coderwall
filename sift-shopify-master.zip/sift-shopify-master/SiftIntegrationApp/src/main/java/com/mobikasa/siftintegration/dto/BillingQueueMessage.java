package com.mobikasa.siftintegration.dto;

public class BillingQueueMessage {

    private String orderId;
    private String shopId;

    public String getOrderId() {
        return orderId;
    }

    public void setOrderId(String orderId) {
        this.orderId = orderId;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }
}
