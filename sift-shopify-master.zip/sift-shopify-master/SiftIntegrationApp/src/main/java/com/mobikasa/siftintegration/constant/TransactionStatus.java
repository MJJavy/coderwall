package com.mobikasa.siftintegration.constant;

import java.util.ArrayList;

public enum TransactionStatus {

    success("$success");

    TransactionStatus(String transactionState) {
        this.transactionState = transactionState;
    }

    private String transactionState;

    public String getTransactionState() {
        return transactionState;
    }

    public TransactionStatus setTransactionState(String transactionState) {
        this.transactionState = transactionState;
    return this;
    }
}



