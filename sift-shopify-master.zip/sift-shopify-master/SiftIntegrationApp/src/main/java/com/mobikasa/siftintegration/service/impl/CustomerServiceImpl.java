package com.mobikasa.siftintegration.service.impl;

import java.io.IOException;
import java.util.Date;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.consumer.AccountConsumer;
import com.mobikasa.siftintegration.entity.ShopEntity;
import com.mobikasa.siftintegration.entity.SiftCustomerAccountEntity;
import com.mobikasa.siftintegration.entity.SiftDataEntity;
import com.mobikasa.siftintegration.exception.BaseException;
import com.mobikasa.siftintegration.exception.BusinessException;
import com.mobikasa.siftintegration.repository.CustomerAccountRepository;
import com.mobikasa.siftintegration.repository.ShopRepository;
import com.mobikasa.siftintegration.repository.ShopifyDataRepository;
import com.mobikasa.siftintegration.service.CustomerService;
import com.mobikasa.siftintegration.service.ValidationService;
import com.mobikasa.siftintegration.util.CommonUtil;

@Service
public class CustomerServiceImpl implements CustomerService {

	@Autowired
	private ShopifyDataRepository shopifyDataRepository;
	@Autowired
	private ObjectMapper mapper;
	@Autowired
	private ShopRepository shopRepository;
	@Autowired
	private AccountConsumer accountConsumer;
	@Value("${app.install.secretkey}")
	private String secretKey;
	@Autowired
	private CustomerAccountRepository siftCustomerAccountRepoSitory;
	
	@Autowired
	private ValidationService validationService;

	@Override
	public ResponseEntity<?> createCustomerAccount(Map<String, String> headers, String customerData) {
		try {

			ShopEntity shopEntity = shopRepository.findByDomain(headers.get("x-shopify-shop-domain"));
			boolean flag = validationService.validateHmac(headers, customerData, shopEntity);

			if (!flag) {
				throw new BusinessException("Invalid Hmac", BaseException.BUSSINESS_TYP);
			}

			SiftDataEntity shopDataEntity = mapCustomerObjectToEntity(customerData, "customers/create");
			shopDataEntity.setStoreId(shopEntity.getId());
			shopifyDataRepository.save(shopDataEntity);

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(null, HttpStatus.CREATED);
	}

	@Override
	public ResponseEntity<?> updateCustomerAccount(Map<String, String> headers, String customerData) {
		try {


			ShopEntity shopEntity = shopRepository.findByDomain(headers.get("x-shopify-shop-domain"));
			boolean flag = validationService.validateHmac(headers, customerData, shopEntity);

			if (!flag) {
				throw new BusinessException("Invalid Hmac", BaseException.BUSSINESS_TYP);
			}

			SiftDataEntity shopDataEntity = mapCustomerObjectToEntity(customerData, "customers/update");
			shopDataEntity.setStoreId(shopEntity.getId());
			shopifyDataRepository.save(shopDataEntity);

			if(validationService.validateShopifyWebhook(headers, customerData, shopEntity)) {
				SiftCustomerAccountEntity order = siftCustomerAccountRepoSitory.findBySpId(Long.parseLong(shopDataEntity.getOrderId()));
				if (order == null) {
					accountConsumer.createSiftCustomerAccount(shopDataEntity.getId());
				} else {
					accountConsumer.updateSiftCustomerAccount(shopDataEntity.getId());
				}
			}		
		} catch (Exception e) {
			e.printStackTrace();
		}
		return new ResponseEntity<>(null, HttpStatus.CREATED);
	}

	private SiftDataEntity mapCustomerObjectToEntity(String customerData, String event) throws IOException {
		SiftDataEntity shopDataEntity = new SiftDataEntity();
		Map<String, Object> map = mapper.readValue(customerData, Map.class);
		try {
			shopDataEntity.setOrderId((map.get("id").toString()));
			shopDataEntity.setEvent(event);
			shopDataEntity.setData(customerData);
			shopDataEntity.setCreatedAt(new Date());
		} catch (Exception e) {
			e.printStackTrace();
		}
		return shopDataEntity;
	}

	private SiftCustomerAccountEntity mapRawDataToActualData(SiftDataEntity shopifyDataEntity) {
		SiftCustomerAccountEntity siftCustomerAccountEntity = new SiftCustomerAccountEntity();
		try {
			Map<String, Object> map = mapper.readValue(shopifyDataEntity.getData(), Map.class);
			siftCustomerAccountEntity.setSpId(Long.parseLong(map.get("id").toString()));
			siftCustomerAccountEntity.setEmail(map.get("email").toString());
			siftCustomerAccountEntity
					.setAcceptsMarketing(map.get("accepts_marketing").toString().equals("false") ? 0 : 1);
			siftCustomerAccountEntity.setCreatedAt(map.get("created_at").toString());
			siftCustomerAccountEntity.setUpdatedAt(map.get("updated_at").toString());
			siftCustomerAccountEntity.setFirstName(map.get("first_name").toString());
			siftCustomerAccountEntity.setLastName(map.get("last_name").toString());
			siftCustomerAccountEntity.setOrdersCount(CommonUtil.parseInt(map.get("orders_count")));
			siftCustomerAccountEntity.setState(map.get("state") == null ? "" : map.get("state").toString());
			siftCustomerAccountEntity.setTotalSpent(CommonUtil.parseBigDecimal(map.get("total_spent")));
			siftCustomerAccountEntity.setLastOrderId(CommonUtil.parseInt(map.get("last_order_id")));
			siftCustomerAccountEntity.setNote(map.get("note") == null ? "" : map.get("note").toString());
			siftCustomerAccountEntity.setVerifiedEmail(map.get("verified_email").toString().equals("false") ? 0 : 1);
			siftCustomerAccountEntity.setMultipassIdentifier(
					map.get("multipass_identifier") == null ? "" : map.get("multipass_identifier").toString());
			siftCustomerAccountEntity.setTaxExempt(map.get("tax_exempt").toString().equals("false") ? 0 : 1);
			siftCustomerAccountEntity.setPhone(map.get("phone") == null ? "0000000000" : map.get("phone").toString());
			siftCustomerAccountEntity.setTags(map.get("tags").toString());
			siftCustomerAccountEntity
					.setLastOrderName(map.get("last_order_name") == null ? "" : map.get("last_order_name").toString());
			siftCustomerAccountEntity.setName("");
			siftCustomerAccountEntity.setStatus("0");
			siftCustomerAccountEntity.setStoreId(shopifyDataEntity.getStoreId());

		} catch (Exception e) {
			e.printStackTrace();
		}
		return siftCustomerAccountEntity;
	}

}
