package com.mobikasa.siftintegration.util;

import com.mobikasa.siftintegration.dto.BillingQueueMessage;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.amqp.core.Queue;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

@Service
public class RabbitMQPublisher {

    @Autowired
    private AmqpTemplate rabbitTemplate;
    @Autowired
    @Qualifier("billingQueue")
    private Queue billingQueue;

    @Value("${javainuse.rabbitmq.exchange}")
    private String exchange;

    public void sendOrderForBilling(String orderId, Long storeId) {
        BillingQueueMessage billingQueueMessage=new BillingQueueMessage();
        billingQueueMessage.setOrderId(orderId);
        billingQueueMessage.setShopId(storeId.toString());
        rabbitTemplate.convertAndSend(billingQueue.getName(), billingQueueMessage);
    }
}
