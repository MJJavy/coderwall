package com.mobikasa.siftintegration.service;

import java.util.Map;

public interface ShopService {

    public void appUninstalled(Map<String, String> headers, String customerData) throws Exception;

    Map<String, String> fetchShopConfig(Long shopId);
}
