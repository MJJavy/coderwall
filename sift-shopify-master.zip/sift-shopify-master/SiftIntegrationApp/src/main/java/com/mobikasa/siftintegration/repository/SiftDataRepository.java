package com.mobikasa.siftintegration.repository;

import java.util.List;
import java.util.Optional;

import com.mobikasa.siftintegration.entity.ShopifyDataEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.siftintegration.entity.SiftDataEntity;

@Repository
public interface SiftDataRepository extends JpaRepository<ShopifyDataEntity, Long> {

}
