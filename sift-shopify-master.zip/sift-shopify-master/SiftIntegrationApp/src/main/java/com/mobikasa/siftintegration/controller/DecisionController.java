package com.mobikasa.siftintegration.controller;

import java.io.IOException;
import java.util.Map;

import com.mobikasa.siftintegration.dto.Mail;
import com.mobikasa.siftintegration.util.CommonUtil;
import com.mobikasa.siftintegration.util.MailSender;
import freemarker.template.TemplateException;
import org.apache.commons.codec.digest.HmacUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.service.DecisionService;
import com.mobikasa.siftintegration.service.OrderService;

import javax.mail.MessagingException;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RequestMapping("decision")
@RestController
public class DecisionController {

    @Autowired
    private DecisionService decisionService;
    @Autowired
    private ObjectMapper mapper;
    @Autowired
    private OrderService orderService;



    @RequestMapping(value = "/order-decision")
    @SuppressWarnings("unchecked")
    public ResponseEntity updateOrder(@RequestHeader Map<String, String> headers, @RequestBody String decisionData) {
        try {
            
			Map<String, Object> map = mapper.readValue(decisionData, Map.class);
            Map<String, String> entity = (Map<String, String>) map.get("entity");
            Map<String, String> decision = (Map<String, String>) map.get("decision");
            Long orderId = Long.valueOf(entity.get("id"));
            String decisionId = decision.get("id");
            Long shopId = orderService.getShopIdfromOrderId(orderId);
            decisionService.saveWebhookData(shopId,orderId,decisionData,"order_webhook");
            if (shopId != 0) {
                System.out.println("Received webhook for shop, order and decision"+shopId+","+orderId+","+decisionId);
                if (CommonUtil.validateSiftToken(shopId, headers.get("X-Sift-Science-Signature"), decisionData)) {
                    decisionService.processDecision(decisionId, shopId, orderId);
                } else {
                    return new ResponseEntity<>(null, HttpStatus.FORBIDDEN);
                }
            } else {
                return new ResponseEntity<>(null, HttpStatus.BAD_REQUEST);
            }
        } catch (Exception exp) {
            exp.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.CREATED);
    }



}
