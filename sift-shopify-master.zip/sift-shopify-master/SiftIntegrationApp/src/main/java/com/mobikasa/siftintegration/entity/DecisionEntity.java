package com.mobikasa.siftintegration.entity;

import java.util.Date;

import javax.persistence.*;

/**
 * The persistent class for the decisions database table.
 */
@Entity
@Table(name = "decisions")
public class DecisionEntity {

    private static final long serialVersionUID = 1L;
    @EmbeddedId
    private ShopDecisionId shopDecisionId;
    private String name;
    private String description;
    private String category;
    @Column(name = "entity_type")
    private String entityType;
    @Column(name = "abuse_type")
    private String abuseType;
    @Column(name = "created_at")
    private Date createdAt;
    @Column(name = "created_by")
    private String createdBy;
    @Column(name = "updated_at")
    private Date updatedAt;
    @Column(name = "updated_by")
    private String updatedBy;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getEntityType() {
        return entityType;
    }

    public void setEntityType(String entityType) {
        this.entityType = entityType;
    }

    public String getAbuseType() {
        return abuseType;
    }

    public void setAbuseType(String abuseType) {
        this.abuseType = abuseType;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public ShopDecisionId getShopDecisionId() {
        return shopDecisionId;
    }

    public void setShopDecisionId(ShopDecisionId shopDecisionId) {
        this.shopDecisionId = shopDecisionId;
    }
}