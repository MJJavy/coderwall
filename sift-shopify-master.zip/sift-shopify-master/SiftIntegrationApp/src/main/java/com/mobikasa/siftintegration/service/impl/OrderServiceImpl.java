package com.mobikasa.siftintegration.service.impl;

import java.io.IOException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import javax.mail.MessagingException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.client.APIClient;
import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.consumer.OrderConsumer;
import com.mobikasa.siftintegration.dto.Mail;
import com.mobikasa.siftintegration.dto.Order;
import com.mobikasa.siftintegration.entity.BillingDetailEntity;
import com.mobikasa.siftintegration.entity.OrderEntity;
import com.mobikasa.siftintegration.entity.ShopEntity;
import com.mobikasa.siftintegration.entity.SiftConfigEntity;
import com.mobikasa.siftintegration.entity.SiftDataEntity;
import com.mobikasa.siftintegration.entity.TokenSessionEntity;
import com.mobikasa.siftintegration.exception.BaseException;
import com.mobikasa.siftintegration.exception.BusinessException;
import com.mobikasa.siftintegration.repository.BillingDetailRepository;
import com.mobikasa.siftintegration.repository.OrderRepository;
import com.mobikasa.siftintegration.repository.ShopRepository;
import com.mobikasa.siftintegration.repository.ShopifyDataRepository;
import com.mobikasa.siftintegration.repository.SiftConfigRepository;
import com.mobikasa.siftintegration.repository.TokenSessionRepository;
import com.mobikasa.siftintegration.service.OrderService;
import com.mobikasa.siftintegration.service.ValidationService;
import com.mobikasa.siftintegration.util.CommonUtil;
import com.mobikasa.siftintegration.util.MailSender;
import com.mobikasa.siftintegration.util.RequestUrlUtility;

import freemarker.template.TemplateException;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private ShopifyDataRepository shopifyDataRepository;
    @Autowired
    private ObjectMapper mapper;
    @Autowired
    private ShopRepository shopRepository;
    @Autowired
    private OrderRepository orderRepository;
    @Autowired
    private TokenSessionRepository tokenSessionRepository;
    @Autowired
    private OrderConsumer orderConsumer;
    @Autowired
    private SiftConfigRepository siftConfigRepository;
    @Value("${app.install.secretkey}")
    private String secretKey;
    @Autowired
    private ValidationService validationService;

    @Override
    public ResponseEntity<?> createOrder(Map<String, String> headers, String orderData) throws Exception {
        try {
            ShopEntity shopEntity = shopRepository.findByDomain(headers.get("x-shopify-shop-domain"));
            boolean flag = validationService.validateHmac(headers, orderData, shopEntity);

            if (!flag) {
                throw new BusinessException("Invalid Hmac", BaseException.BUSSINESS_TYP);
            }
            
            SiftDataEntity shopDataEntity = mapCustomerObjectToEntity(orderData, "Order Create");
            shopDataEntity.setStoreId(shopEntity.getId());
            shopifyDataRepository.save(shopDataEntity);

            if (validationService.validateShopifyWebhook(headers, orderData, shopEntity)) {
                orderConsumer.processTransactionAndOrder(shopDataEntity.getId());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.CREATED);
    }

    @Override
    public ResponseEntity<?> updateOrder(Map<String, String> headers, String orderData) throws Exception {
        try {
            ShopEntity shopEntity = shopRepository.findByDomain(headers.get("x-shopify-shop-domain"));
            boolean flag = validationService.validateHmac(headers, orderData, shopEntity);
            if (!flag) {
                throw new BusinessException("Invalid Hmac", BaseException.BUSSINESS_TYP);
            }
            SiftDataEntity shopDataEntity = mapCustomerObjectToEntity(orderData, "Order Update");
            shopDataEntity.setStoreId(shopEntity.getId());
            Optional<List<SiftDataEntity>> orderEntity = shopifyDataRepository.findByOrderIdAndEvent(shopDataEntity.getOrderId(), "Order Update");
            shopifyDataRepository.save(shopDataEntity);
            if (orderEntity.isPresent() && validationService.validateShopifyWebhook(headers, orderData, shopEntity)) {
            	orderConsumer.processUpdateOrder(shopDataEntity.getId());
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.CREATED);

    }

    private SiftDataEntity mapCustomerObjectToEntity(String orderData, String event) throws IOException {
        SiftDataEntity shopifyDataEntity = new SiftDataEntity();
        Map<String, Object> map = mapper.readValue(orderData, Map.class);
        try {
            shopifyDataEntity.setOrderId((map.get("id").toString()));
            shopifyDataEntity.setEvent(event);
            shopifyDataEntity.setData(orderData);
            shopifyDataEntity.setCreatedAt(new Date());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return shopifyDataEntity;
    }

    private OrderEntity saveOrder(Order order, Long storeId) {
        OrderEntity orderEntity = new OrderEntity();
        Date date = new Date();
        try {
            orderEntity.setOrderNo(order.getOrder_number());
            orderEntity.setOrderId(order.getId());
            orderEntity.setShopId(storeId);
            orderEntity.setAmount(CommonUtil.parseBigDecimal(order.getTotal_price()));
            orderEntity.setOrderCrtDate(order.getCreated_at());
            orderEntity.setOrderUpdDate(order.getUpdated_at());
            orderEntity.setCustomerId(order.getCustomer().getId().toString());
            orderEntity.setCustomerName(order.getCustomer().getName());
            orderEntity.setEmail(order.getEmail());
            orderEntity.setStatus(0);
            orderEntity.setCrtDate(date);
            orderEntity.setUpdDate(date);
            orderRepository.save(orderEntity);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return orderEntity;
    }

    @Override
    public void saveSeesionData(String shop, String token, String session) throws Exception {
        try {
            ShopEntity shopEntity = shopRepository.findByDomain(shop);

            TokenSessionEntity entity = new TokenSessionEntity();
            entity.setShopId(shopEntity.getId());
            entity.setSessionId(session);
            entity.setToken(token);

            tokenSessionRepository.save(entity);
        } catch (Exception exp) {
            exp.printStackTrace();
        }
    }

    @Override
    public Long getShopIdfromOrderId(Long orderId) {
        Long shopId = 0L;
        try {
            Optional<OrderEntity> orderEntity = orderRepository.findOneByOrderId(orderId.toString());
            if (orderEntity.isPresent()) {
                return orderEntity.get().getShopId();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return shopId;
    }

    @Override
    public String getEnvironment(Long shopId) {
        SiftConfigEntity siftConfigEntity = null;
        try {
            siftConfigEntity = siftConfigRepository.findByshopId(shopId);
            if (siftConfigEntity != null) {
                return siftConfigEntity.getEnvironment();
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    @SuppressWarnings("rawtypes")
    @Override
    public ResponseEntity<?> createRefundTransaction(Map<String, String> headers, String orderData, String status,
                                                     String webhookType) throws Exception {
        try {

            ShopEntity shopEntity = shopRepository.findByDomain(headers.get("x-shopify-shop-domain"));
            boolean flag = validationService.validateShopifyWebhook(headers, orderData, shopEntity);

            if (!flag) {
                throw new BusinessException("Invalid Hmac", BaseException.BUSSINESS_TYP);
            }

            SiftDataEntity shopDataEntity = mapCustomerObjectToEntity(orderData, webhookType);
            shopDataEntity.setStoreId(shopEntity.getId());
            shopifyDataRepository.save(shopDataEntity);

        } catch (Exception e) {
            e.printStackTrace();
        }
        return new ResponseEntity<>(null, HttpStatus.CREATED);

    }

}
