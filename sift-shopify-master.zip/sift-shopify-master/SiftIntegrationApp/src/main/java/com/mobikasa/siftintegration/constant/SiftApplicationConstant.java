package com.mobikasa.siftintegration.constant;

import java.util.Arrays;
import java.util.List;

public interface SiftApplicationConstant {

    public static final String CHARACTER_BACKSLASH = "/";
    public static final String API_DATA_FORMAT_JSON = "json";
    public static final String ZERO = "0";
    public static final int INT_ZERO = 0;
    public static final String ONE = "1";
    public static final int INT_ONE = 1;
    public static final int MICRO_CONVERTER = 1000000;
    public static final String CREATE = "create";
    public static final String UPDATE = "update";
    public static final String STATUS_SUCCESS = "$success";
    public static final String CHARGEBACK_REASON_OTHER = "$other";
    public static final String CREATE_CALLBACK = "create_callback";
    List<String> sentToShopifyDecisionsList = Arrays.asList( "bad_order_payment_abuse",
            "cancel_order_payment_abuse");
    List<String> siftApplyDecisionsList = Arrays.asList("cancel_order_payment_abuse");

    public static final String REVIEW_QUEUE = "review queue";
    public static final String PAYMENT_ABUSE = "payment_abuse";

    public static final int THIRTY_SECOND = 30000;

    public static final String REFUNDED = "refunded";
    public static final String VOIDED = "voided";
    public static final String CANCELLED = "$canceled";
    public static final String REVIEW_ORDER = "Review Order";
    public static final String ENVIRONMENT = "environment";
    public static final String CONTENT = "CONTENT";

}
