package com.mobikasa.siftintegration.repository;

import java.util.List;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.siftintegration.entity.ShopEntity;

@Repository
public interface ShopRepository extends CrudRepository<ShopEntity, Long> {

	public ShopEntity findByDomain(String domain) throws Exception;

	public ShopEntity findByDomainAndStatus(String p_domain, String status) throws Exception;
	
	public List<ShopEntity> findByStatus(String status) throws Exception;
	
}
