package com.mobikasa.siftintegration.repository;

import com.mobikasa.siftintegration.entity.BillingDetailEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.Date;
import java.util.List;
import java.util.Optional;

public interface BillingDetailRepository extends JpaRepository<BillingDetailEntity, Long> {

    Optional<BillingDetailEntity> findByShopId(Long shopId);

    Optional<List<BillingDetailEntity>> findAllByNextBillingDate(Date date);

    @Query(value = "from BillingDetailEntity where date(next_billing_date)= date(now())")
    Optional<List<BillingDetailEntity>> findRecordsToSave();
}
