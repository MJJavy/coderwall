package com.mobikasa.siftintegration.service;

import java.util.Map;

import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

@Service
public interface CustomerService {

    ResponseEntity<?> updateCustomerAccount(Map<String, String> headers, String object);

    ResponseEntity<?> createCustomerAccount(Map<String, String> headers, String object);
}
