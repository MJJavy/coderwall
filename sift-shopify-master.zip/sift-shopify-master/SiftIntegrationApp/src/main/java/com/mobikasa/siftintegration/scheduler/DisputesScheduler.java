package com.mobikasa.siftintegration.scheduler;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.mobikasa.siftintegration.service.DisputesService;

@Component
public class DisputesScheduler {

	@Autowired
	private DisputesService disputesService;

	@Scheduled(cron = "${disputes.scheduler.cron}")
	@Transactional(propagation=Propagation.REQUIRES_NEW)	
	public void fetchDisputesByStore() {
		try {
			disputesService.fetchDisputesByShop();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}
