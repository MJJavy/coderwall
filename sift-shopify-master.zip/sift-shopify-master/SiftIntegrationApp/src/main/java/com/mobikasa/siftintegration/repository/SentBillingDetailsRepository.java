package com.mobikasa.siftintegration.repository;

import com.mobikasa.siftintegration.entity.SentBillingDetailsEntity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SentBillingDetailsRepository extends JpaRepository<SentBillingDetailsEntity, Long> {

}
