package com.mobikasa.siftintegration.consumer;

import java.math.BigDecimal;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.google.i18n.phonenumbers.NumberParseException;
import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import com.mobikasa.siftintegration.entity.*;
import com.mobikasa.siftintegration.service.ShopService;
import com.mobikasa.siftintegration.util.CommonUtil;
import org.apache.http.HttpStatus;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.siftintegration.dto.SiftCustomerAccount;
import com.mobikasa.siftintegration.dto.SiftCustomerAddress;
import com.mobikasa.siftintegration.repository.CustomerAccountRepository;
import com.mobikasa.siftintegration.repository.CustomerAddressRepository;
import com.mobikasa.siftintegration.repository.SiftConfigRepository;
import com.mobikasa.siftintegration.repository.SiftShopifyDataRepository;
import com.siftscience.EventRequest;
import com.siftscience.EventResponse;
import com.siftscience.SiftClient;
import com.siftscience.model.Address;
import com.siftscience.model.CreateAccountFieldSet;
import com.siftscience.model.UpdateAccountFieldSet;

@Component
public class AccountConsumer {

    @Autowired
    private SiftShopifyDataRepository shopifyDataRepository;
    @Autowired
    private CustomerAccountRepository siftCustomerAccountRepoSitory;
    @Autowired
    private CustomerAddressRepository siftCustomerAddressRepository;
    @Autowired
    private ModelMapper modelMapper;
    @Autowired
    private ObjectMapper mapper;
    @Autowired
    SiftConfigRepository siftConfigRepository;
    @Autowired
    ShopService shopService;


    private String apiKey;
    private String accountId;

   @Async("fixedThreadPool")
    public void createSiftCustomerAccount(Long id) {
        Optional<SiftDataEntity> shopifyDataEntity = shopifyDataRepository.findById(id);
        SiftCustomerAccount siftCustomerAccount = null;
        Optional<SiftCustomerAccountEntity> siftCustomerAccountEntity = null;
        if (shopifyDataEntity.isPresent()) {
            siftCustomerAccount = createCustomerData(shopifyDataEntity);
        }
        if (siftCustomerAccount != null) {
            SiftClient siftClient = CommonUtil.createSiftClient(siftCustomerAccount.getStoreId());
            EventResponse response = createAccountInSift(siftClient, siftCustomerAccount, true);
            try {
                siftCustomerAccountEntity = siftCustomerAccountRepoSitory.findById(siftCustomerAccount.getId());
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (response.getHttpStatusCode() == HttpStatus.SC_OK) {
                siftCustomerAccountEntity.get().setStatus(SiftApplicationConstant.ONE);
            } else {
                siftCustomerAccountEntity.get().setStatus(SiftApplicationConstant.ZERO);
            }
            siftCustomerAccountRepoSitory.save(siftCustomerAccountEntity.get());
        }
    }

    @Async("fixedThreadPool")
    public void updateSiftCustomerAccount(Long id) {
        Optional<SiftDataEntity> shopifyDataEntity = shopifyDataRepository.findById(id);
        SiftCustomerAccount siftCustomerAccount = null;
        SiftCustomerAccountEntity siftCustomerAccountEntity = null;
        if (shopifyDataEntity.isPresent()) {
            siftCustomerAccount = updteCustomerData(shopifyDataEntity);
        }
        if (siftCustomerAccount != null) {
            SiftClient siftClient = CommonUtil.createSiftClient(siftCustomerAccount.getStoreId());
            EventResponse response = createAccountInSift(siftClient, siftCustomerAccount, false);
            try {
                siftCustomerAccountEntity = siftCustomerAccountRepoSitory.findBySpId(Long.parseLong(shopifyDataEntity.get().getOrderId().toString()));
            } catch (Exception e) {
                e.printStackTrace();
            }
            if (response.getHttpStatusCode() == HttpStatus.SC_OK) {
                siftCustomerAccountEntity.setStatus(SiftApplicationConstant.ONE);
            } else {
                siftCustomerAccountEntity.setStatus(SiftApplicationConstant.ZERO);
            }
            siftCustomerAccountRepoSitory.save(siftCustomerAccountEntity);
        }
    }

    private SiftCustomerAccount updteCustomerData(Optional<SiftDataEntity> siftDataEntity) {
        SiftCustomerAccount SiftCustomerAccount = null;
        try {
            SiftCustomerAccountEntity SiftSiftCustomerAccountEntity = updateSiftCustomerAccount(siftDataEntity);
            //SiftCustomerAddressEntity SiftCustomerAddressEntity = updateSiftCustomerAddress(siftDataEntity);
            SiftCustomerAccount = fetchSiftCustomerAccount(SiftSiftCustomerAccountEntity, null);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return SiftCustomerAccount;
    }

    private SiftCustomerAddressEntity updateSiftCustomerAddress(Optional<SiftDataEntity> shopifyDataEntity) {
        SiftCustomerAddressEntity newSiftCustomerAddressEntity = mapRawDataToActualSiftCustomerAddress(shopifyDataEntity.get());
        if (newSiftCustomerAddressEntity != null) {
            SiftCustomerAddressEntity siftCustomerAddressEntity = siftCustomerAddressRepository.findByCustomerId(newSiftCustomerAddressEntity.getCustomerId());
            siftCustomerAddressEntity.setAddress1(newSiftCustomerAddressEntity.getAddress1());
            siftCustomerAddressEntity.setAddress2(newSiftCustomerAddressEntity.getAddress2());
            siftCustomerAddressEntity.setCity(newSiftCustomerAddressEntity.getCity());
            siftCustomerAddressEntity.setCountry(newSiftCustomerAddressEntity.getCountry());
            siftCustomerAddressEntity.setCountryCode(newSiftCustomerAddressEntity.getCountryCode());
            siftCustomerAddressEntity.setCountryName(newSiftCustomerAddressEntity.getCountryName());
            siftCustomerAddressEntity.setLastName(newSiftCustomerAddressEntity.getLastName());
            siftCustomerAddressEntity.setFirstName(newSiftCustomerAddressEntity.getFirstName());
            siftCustomerAddressEntity.setProvince(newSiftCustomerAddressEntity.getProvince());
            siftCustomerAddressEntity.setCompany(newSiftCustomerAddressEntity.getCompany());
            siftCustomerAddressEntity.setProvinceCode(newSiftCustomerAddressEntity.getProvinceCode());
            siftCustomerAddressEntity.setZip(newSiftCustomerAddressEntity.getZip());
            siftCustomerAddressEntity.setDefaultAddress(newSiftCustomerAddressEntity.getDefaultAddress());
            try {
                siftCustomerAddressEntity.setPhone(newSiftCustomerAddressEntity.getPhone());
            } catch (NumberParseException e) {
                e.printStackTrace();
            }
            siftCustomerAddressRepository.save(siftCustomerAddressEntity);
            return siftCustomerAddressEntity;
        }
        return null;
    }

    private SiftCustomerAccount createCustomerData(Optional<SiftDataEntity> shopifyDataEntity) {
        SiftCustomerAccount SiftCustomerAccount = null;
        try {
            SiftCustomerAccountEntity siftCustomerAccountEntity = saveSiftCustomerAccount(shopifyDataEntity);
            SiftCustomerAddressEntity siftCustomerAddressEntity = saveSiftCustomerAddress(shopifyDataEntity);
            SiftCustomerAccount = fetchSiftCustomerAccount(siftCustomerAccountEntity, siftCustomerAddressEntity);
        } catch (Exception e) {
            e.printStackTrace();
        }
        return SiftCustomerAccount;
    }

    private SiftCustomerAccount fetchSiftCustomerAccount(SiftCustomerAccountEntity siftCustomerAccountEntity, SiftCustomerAddressEntity siftCustomerAddressEntity) {
        SiftCustomerAccount siftCustomerAccount = modelMapper.map(siftCustomerAccountEntity, SiftCustomerAccount.class);
        if (siftCustomerAddressEntity != null) {
            SiftCustomerAddress siftCustomerAddress = modelMapper.map(siftCustomerAddressEntity, SiftCustomerAddress.class);
            siftCustomerAccount.setCustomerAddress(siftCustomerAddress);
        } else {
            siftCustomerAccount.setCustomerAddress(null);
        }
        return siftCustomerAccount;
    }

    private SiftCustomerAccountEntity saveSiftCustomerAccount(Optional<SiftDataEntity> siftDataEntity) {
        SiftCustomerAccountEntity siftCustomerAccountEntity = mapRawDataToActualData(siftDataEntity.get());
        if (siftCustomerAccountEntity != null) {
            siftCustomerAccountRepoSitory.save(siftCustomerAccountEntity);
        }
        return siftCustomerAccountEntity;
    }

    private SiftCustomerAccountEntity updateSiftCustomerAccount(Optional<SiftDataEntity> siftDataEntity) {
        SiftCustomerAccountEntity newSiftSiftCustomerAccountEntity = mapRawDataToActualData(siftDataEntity.get());
        SiftCustomerAccountEntity siftCustomerAccountEntity = siftCustomerAccountRepoSitory.findBySpId(newSiftSiftCustomerAccountEntity.getSpId());
        if (newSiftSiftCustomerAccountEntity != null) {
            siftCustomerAccountEntity.setStoreId(newSiftSiftCustomerAccountEntity.getStoreId());
            siftCustomerAccountEntity.setEmail(newSiftSiftCustomerAccountEntity.getEmail());
            siftCustomerAccountEntity.setAcceptsMarketing(newSiftSiftCustomerAccountEntity.getAcceptsMarketing());
            siftCustomerAccountEntity.setUpdatedAt(newSiftSiftCustomerAccountEntity.getUpdatedAt());
            siftCustomerAccountEntity.setFirstName(newSiftSiftCustomerAccountEntity.getFirstName());
            siftCustomerAccountEntity.setLastName(newSiftSiftCustomerAccountEntity.getLastName());
            siftCustomerAccountEntity.setOrdersCount(newSiftSiftCustomerAccountEntity.getOrdersCount());
            siftCustomerAccountEntity.setState(newSiftSiftCustomerAccountEntity.getState());
            siftCustomerAccountEntity.setTotalSpent(newSiftSiftCustomerAccountEntity.getTotalSpent());
            siftCustomerAccountEntity.setLastOrderId(newSiftSiftCustomerAccountEntity.getLastOrderId());
            siftCustomerAccountEntity.setNote(newSiftSiftCustomerAccountEntity.getNote());
            siftCustomerAccountEntity.setVerifiedEmail(newSiftSiftCustomerAccountEntity.getVerifiedEmail());
            siftCustomerAccountEntity.setMultipassIdentifier(newSiftSiftCustomerAccountEntity.getMultipassIdentifier());
            siftCustomerAccountEntity.setTaxExempt(newSiftSiftCustomerAccountEntity.getTaxExempt());
            siftCustomerAccountEntity.setTags(newSiftSiftCustomerAccountEntity.getTags());
            siftCustomerAccountEntity.setLastOrderName(newSiftSiftCustomerAccountEntity.getLastOrderName());
            siftCustomerAccountEntity.setName(newSiftSiftCustomerAccountEntity.getName());
            siftCustomerAccountEntity.setStatus(newSiftSiftCustomerAccountEntity.getStatus());
            siftCustomerAccountEntity.setStoreId(siftDataEntity.get().getStoreId());
            siftCustomerAccountRepoSitory.save(siftCustomerAccountEntity);
        }
        return siftCustomerAccountEntity;
    }


    private SiftCustomerAddressEntity saveSiftCustomerAddress(Optional<SiftDataEntity> siftDataEntity) {
        SiftCustomerAddressEntity siftCustomerAddressEntity = mapRawDataToActualSiftCustomerAddress(siftDataEntity.get());
        if (siftCustomerAddressEntity != null) {
            siftCustomerAddressRepository.save(siftCustomerAddressEntity);
        }
        return siftCustomerAddressEntity;
    }

    private SiftCustomerAddressEntity mapRawDataToActualSiftCustomerAddress(SiftDataEntity siftDataEntity) {
        SiftCustomerAddressEntity siftCustomerAddressEntity = new SiftCustomerAddressEntity();
        try {
            Map<String, Object> map = mapper.readValue(siftDataEntity.getData(), Map.class);
            if (map.get("addresses") != null && ((List<Map<String, Object>>) map.get("addresses")).size() > 0) {
                List<Map<String, Object>> addresses = (List<Map<String, Object>>) map.get("addresses");
                siftCustomerAddressEntity.setCustomerId(Long.parseLong(addresses.get(0).get("customer_id").toString()));
                siftCustomerAddressEntity.setAddress1(addresses.get(0).get("address1").toString());
                siftCustomerAddressEntity.setAddress2(addresses.get(0).get("address2").toString());
                siftCustomerAddressEntity.setCity(addresses.get(0).get("city").toString());
                siftCustomerAddressEntity.setCountry(addresses.get(0).get("country").toString());
                siftCustomerAddressEntity.setCountryCode(addresses.get(0).get("country_code").toString());
                siftCustomerAddressEntity.setCountryName(addresses.get(0).get("country_name").toString());
                siftCustomerAddressEntity.setCompany(addresses.get(0).get("company") == null ? "" : addresses.get(0).get("company").toString());
                siftCustomerAddressEntity.setFirstName(addresses.get(0).get("first_name").toString());
                siftCustomerAddressEntity.setLastName(addresses.get(0).get("last_name").toString());
                siftCustomerAddressEntity.setName(addresses.get(0).get("name") == null ? "" : addresses.get(0).get("name").toString());
                siftCustomerAddressEntity.setPhone(addresses.get(0).get("phone") == null ? "" : addresses.get(0).get("phone").toString());
                siftCustomerAddressEntity.setProvince(addresses.get(0).get("province") == null ? "" : addresses.get(0).get("province").toString());
                siftCustomerAddressEntity.setProvinceCode(addresses.get(0).get("province_code") == null ? "" : addresses.get(0).get("province_code").toString());
                siftCustomerAddressEntity.setZip(addresses.get(0).get("zip") == null ? "" : addresses.get(0).get("zip").toString());
                siftCustomerAddressEntity.setDefaultAddress(addresses.get(0).get("default").equals("true") ? true : false);
            } else {
                siftCustomerAddressEntity = null;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return siftCustomerAddressEntity;
    }

    private SiftCustomerAccountEntity mapRawDataToActualData(SiftDataEntity shopifyDataEntity) {
        SiftCustomerAccountEntity siftCustomerAccountEntity = new SiftCustomerAccountEntity();
        try {
            Map<String, Object> map = mapper.readValue(shopifyDataEntity.getData(), Map.class);
            siftCustomerAccountEntity.setSpId(Long.parseLong(map.get("id").toString()));
            siftCustomerAccountEntity.setEmail(map.get("email").toString());
            siftCustomerAccountEntity.setAcceptsMarketing(map.get("accepts_marketing").toString().equals("false") ? 0 : 1);
            siftCustomerAccountEntity.setCreatedAt(map.get("created_at").toString());
            siftCustomerAccountEntity.setUpdatedAt(map.get("updated_at").toString());
            siftCustomerAccountEntity.setFirstName(map.get("first_name").toString());
            siftCustomerAccountEntity.setLastName(map.get("last_name").toString());
            siftCustomerAccountEntity.setOrdersCount(parseInt(map.get("orders_count")));
            siftCustomerAccountEntity.setState(map.get("state") == null ? "" : map.get("state").toString());
            siftCustomerAccountEntity.setTotalSpent(parseBigDecimal(map.get("total_spent")));
            siftCustomerAccountEntity.setLastOrderId(parseInt(map.get("last_order_id")));
            siftCustomerAccountEntity.setNote(map.get("note") == null ? "" : map.get("note").toString());
            siftCustomerAccountEntity.setVerifiedEmail(map.get("verified_email").toString().equals("false") ? 0 : 1);
            siftCustomerAccountEntity.setMultipassIdentifier(map.get("multipass_identifier") == null ? "" : map.get("multipass_identifier").toString());
            siftCustomerAccountEntity.setTaxExempt(map.get("tax_exempt").toString().equals("false") ? 0 : 1);
            siftCustomerAccountEntity.setPhone(map.get("phone") == null ? "" : map.get("phone").toString());
            siftCustomerAccountEntity.setTags(map.get("tags").toString());
            siftCustomerAccountEntity.setLastOrderName(map.get("last_order_name") == null ? "" : map.get("last_order_name").toString());
            siftCustomerAccountEntity.setName("");
            siftCustomerAccountEntity.setStatus(SiftApplicationConstant.ZERO);
            siftCustomerAccountEntity.setStoreId(shopifyDataEntity.getStoreId());
        } catch (Exception e) {
            e.printStackTrace();
        }
        return siftCustomerAccountEntity;
    }

    private EventResponse createAccountInSift(SiftClient siftClient, SiftCustomerAccount siftCustomerAccount, boolean create) {
        ApiLogEntity apiLog = new ApiLogEntity();
        ObjectMapper Obj = new ObjectMapper();
        EventRequest request;
        if (create) {
            if (siftCustomerAccount.getCustomerAddress() != null) {
                request = siftClient.buildRequest(new CreateAccountFieldSet()
                        .setUserId(siftCustomerAccount.getSpId().toString())
                        .setUserEmail(siftCustomerAccount.getEmail())
                        .setName(siftCustomerAccount.getFirstName() + " " + siftCustomerAccount.getLastName())
                        .setPhone(siftCustomerAccount.getPhone())
                        .setBillingAddress(new Address()
                                .setName(siftCustomerAccount.getFirstName() + " " + siftCustomerAccount.getLastName())
                                .setPhone(siftCustomerAccount.getCustomerAddress().getPhone())
                                .setAddress1(siftCustomerAccount.getCustomerAddress().getAddress1())
                                .setAddress2(siftCustomerAccount.getCustomerAddress().getAddress2())
                                .setCity(siftCustomerAccount.getCustomerAddress().getCity())
                                .setRegion(siftCustomerAccount.getCustomerAddress().getProvince())
                                .setCountry(siftCustomerAccount.getCustomerAddress().getCountry_code())
                                .setZipCode(siftCustomerAccount.getCustomerAddress().getZip()))
                        .setShippingAddress(new Address()
                                .setName(siftCustomerAccount.getFirstName() + " " + siftCustomerAccount.getLastName())
                                .setPhone(siftCustomerAccount.getCustomerAddress().getPhone())
                                .setAddress1(siftCustomerAccount.getCustomerAddress().getAddress1())
                                .setAddress2(siftCustomerAccount.getCustomerAddress().getAddress2())
                                .setCity(siftCustomerAccount.getCustomerAddress().getCity())
                                .setRegion(siftCustomerAccount.getCustomerAddress().getProvince())
                                .setCountry(siftCustomerAccount.getCustomerAddress().getCountry_code())
                                .setZipCode(siftCustomerAccount.getCustomerAddress().getZip()))
                );
            } else {
                request = siftClient.buildRequest(new CreateAccountFieldSet()
                        .setUserId(siftCustomerAccount.getSpId().toString())
                        .setUserEmail(siftCustomerAccount.getEmail())
                        .setName(siftCustomerAccount.getFirstName() + " " + siftCustomerAccount.getLastName())
                        .setPhone(siftCustomerAccount.getPhone()));
            }
        } else {
            if (siftCustomerAccount.getCustomerAddress() != null) {
                request = siftClient.buildRequest(new UpdateAccountFieldSet()
                        .setUserId(siftCustomerAccount.getSpId().toString())
                        .setUserEmail(siftCustomerAccount.getEmail())
                        .setName(siftCustomerAccount.getFirstName() + " " + siftCustomerAccount.getLastName())
                        .setPhone(siftCustomerAccount.getPhone())
                        .setBillingAddress(new Address()
                                .setName(siftCustomerAccount.getFirstName() + " " + siftCustomerAccount.getLastName())
                                .setPhone(siftCustomerAccount.getCustomerAddress().getPhone())
                                .setAddress1(siftCustomerAccount.getCustomerAddress().getAddress1())
                                .setAddress2(siftCustomerAccount.getCustomerAddress().getAddress2())
                                .setCity(siftCustomerAccount.getCustomerAddress().getCity())
                                .setRegion(siftCustomerAccount.getCustomerAddress().getProvince())
                                .setCountry(siftCustomerAccount.getCustomerAddress().getCountry_code())
                                .setZipCode(siftCustomerAccount.getCustomerAddress().getZip()))
                        .setShippingAddress(new Address()
                                .setName(siftCustomerAccount.getFirstName() + " " + siftCustomerAccount.getLastName())
                                .setPhone(siftCustomerAccount.getCustomerAddress().getPhone())
                                .setAddress1(siftCustomerAccount.getCustomerAddress().getAddress1())
                                .setAddress2(siftCustomerAccount.getCustomerAddress().getAddress2())
                                .setCity(siftCustomerAccount.getCustomerAddress().getCity())
                                .setRegion(siftCustomerAccount.getCustomerAddress().getProvince())
                                .setCountry(siftCustomerAccount.getCustomerAddress().getCountry_code())
                                .setZipCode(siftCustomerAccount.getCustomerAddress().getZip()))
                );
            } else {
                request = siftClient.buildRequest(new UpdateAccountFieldSet()
                        .setUserId(siftCustomerAccount.getSpId().toString())
                        .setUserEmail(siftCustomerAccount.getEmail())
                        .setName(siftCustomerAccount.getFirstName() + " " + siftCustomerAccount.getLastName())
                        .setPhone(siftCustomerAccount.getPhone()));
            }
        }
        EventResponse response = null;
        try {
            if (create) {
                apiLog = CommonUtil.createApiLog("create_account", Obj.writeValueAsString(request.getFieldSet()), siftCustomerAccount.getStoreId(),"");
            } else {
                apiLog = CommonUtil.createApiLog("update_account", Obj.writeValueAsString(request.getFieldSet()), siftCustomerAccount.getStoreId(),"");
            }
            response = request.send();
            CommonUtil.updateApiLog(apiLog, Obj.writeValueAsString(response.getBody()));
        } catch (Exception e) {

            System.out.println(e.getMessage());
            return response;
        }
        return response; // true
    }

    private BigDecimal parseBigDecimal(Object object) {
        if (object == null) {
            return BigDecimal.ZERO;
        } else {
            return new BigDecimal(object.toString());
        }
    }

    private Integer parseInt(Object object) {
        if (object == null) {
            return SiftApplicationConstant.INT_ZERO;
        } else {
            return Integer.parseInt(object.toString());
        }
    }
}