package com.mobikasa.siftintegration.service.impl;

import java.math.BigDecimal;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import com.mobikasa.siftintegration.constant.SiftApplicationConstant;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.mobikasa.siftintegration.client.APIClient;
import com.mobikasa.siftintegration.consumer.ChargebackConsumer;
import com.mobikasa.siftintegration.entity.DisputeEntity;
import com.mobikasa.siftintegration.entity.DisputeEntityPK;
import com.mobikasa.siftintegration.entity.ShopEntity;
import com.mobikasa.siftintegration.repository.DisputeRepository;
import com.mobikasa.siftintegration.repository.ShopRepository;
import com.mobikasa.siftintegration.service.DisputesService;
import com.mobikasa.siftintegration.shopify.response.Dispute;
import com.mobikasa.siftintegration.shopify.response.DisputeResponse;
import com.mobikasa.siftintegration.util.RequestUrlUtility;

@Component
public class DisputesServiceImpl implements DisputesService {
	
	@Autowired
	private ShopRepository shopRepository;
	
	@Value("${app.shopify.disputes.url}")
	private String disputesUrl;
	
	@Autowired
	private DisputeRepository disputeRepository;
	
	@Autowired
	private ChargebackConsumer consumer;
	
	DateFormat dateFormtter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:SSSZ");

	@Override
	public void fetchDisputesByShop() throws Exception {
		try {
			List<ShopEntity> shopList =  shopRepository.findByStatus("1");
			shopList.forEach(shop -> this.fetchDisputesForStores(shop));
		} catch(Exception exp) {
			exp.printStackTrace();
		}
	}
	
	private void fetchDisputesForStores(ShopEntity shop) {
		try {
			Map<String, String> headerMap = new HashMap<>();
			headerMap.put("X-Shopify-Access-Token", shop.getAccessToken());
			String updatedUrl = RequestUrlUtility.updateRequestUrl(disputesUrl, "", "", "", "", shop.getDomain(), "");
			String response = APIClient.callAPI("", updatedUrl, headerMap, "GET");
			DisputeResponse disputeResponse = (DisputeResponse) APIClient.parseJsonObject(response, DisputeResponse.class);
			if(disputeResponse != null && !disputeResponse.getDisputes().isEmpty()) {
				List<Dispute> disputesList = disputeResponse.getDisputes();
				disputesList.forEach(dispute -> this.saveDisputes(dispute, shop));
			}
			consumer.createChargeBack();
		} catch(Exception ep) {
			ep.printStackTrace();
		}
	}
	
	private void saveDisputes(Dispute p_dispute, ShopEntity shop) {
		try {
			
			DisputeEntityPK pk = new DisputeEntityPK(p_dispute.getId(), p_dispute.getOrderId(), shop.getId());
			
			Optional<DisputeEntity> entity = disputeRepository.findById(pk);
			
			if(!entity.isPresent()) {
				DisputeEntity dispute = new DisputeEntity(pk);
				dispute.setAmount( StringUtils.hasText(p_dispute.getAmount()) ? new BigDecimal(p_dispute.getAmount()) : null);
				
				dispute.setCurrency(p_dispute.getCurrency());
				dispute.setNetworkReason(p_dispute.getNetworkReasonCode());
				dispute.setReason(p_dispute.getReason());
				dispute.setStatus(p_dispute.getStatus());
				dispute.setType(p_dispute.getType());
				dispute.setSiftStatus(SiftApplicationConstant.ZERO);
				disputeRepository.save(dispute);
			} else if(!entity.get().getStatus().replace("$", "").equals(p_dispute.getStatus())) {
				entity.get().setSiftStatus(SiftApplicationConstant.ZERO);
				entity.get().setStatus(p_dispute.getStatus());
				disputeRepository.save(entity.get());
			}
			
		} catch(Exception ep) {
			ep.printStackTrace();
		}
	}
	

}
