package com.mobikasa.siftintegration.dto;

public class SiftConfig {

    private Long id;
    private String shopId;
    private String siftEnable;
    private String environment;
    private String production_account_id;
    private String production_api_key;
    private String productionApiBeaconKey;
    private String productionApiSignatureKey;
    private String stagingAccountId;
    private String stagingApiKey;
    private String stagingApiBeaconKey;
    private String badOrderKey;
    private String watchOrderKey;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getShopId() {
        return shopId;
    }

    public void setShopId(String shopId) {
        this.shopId = shopId;
    }

    public String getSiftEnable() {
        return siftEnable;
    }

    public void setSiftEnable(String siftEnable) {
        this.siftEnable = siftEnable;
    }

    public String getEnvironment() {
        return environment;
    }

    public void setEnvironment(String environment) {
        this.environment = environment;
    }

    public String getProduction_account_id() {
        return production_account_id;
    }

    public void setProduction_account_id(String production_account_id) {
        this.production_account_id = production_account_id;
    }

    public String getProduction_api_key() {
        return production_api_key;
    }

    public void setProduction_api_key(String production_api_key) {
        this.production_api_key = production_api_key;
    }

    public String getProductionApiBeaconKey() {
        return productionApiBeaconKey;
    }

    public void setProductionApiBeaconKey(String productionApiBeaconKey) {
        this.productionApiBeaconKey = productionApiBeaconKey;
    }

    public String getProductionApiSignatureKey() {
        return productionApiSignatureKey;
    }

    public void setProductionApiSignatureKey(String productionApiSignatureKey) {
        this.productionApiSignatureKey = productionApiSignatureKey;
    }

    public String getStagingAccountId() {
        return stagingAccountId;
    }

    public void setStagingAccountId(String stagingAccountId) {
        this.stagingAccountId = stagingAccountId;
    }

    public String getStagingApiKey() {
        return stagingApiKey;
    }

    public void setStagingApiKey(String stagingApiKey) {
        this.stagingApiKey = stagingApiKey;
    }

    public String getStagingApiBeaconKey() {
        return stagingApiBeaconKey;
    }

    public void setStagingApiBeaconKey(String stagingApiBeaconKey) {
        this.stagingApiBeaconKey = stagingApiBeaconKey;
    }

    public String getBadOrderKey() {
        return badOrderKey;
    }

    public void setBadOrderKey(String badOrderKey) {
        this.badOrderKey = badOrderKey;
    }

    public String getWatchOrderKey() {
        return watchOrderKey;
    }

    public void setWatchOrderKey(String watchOrderKey) {
        this.watchOrderKey = watchOrderKey;
    }
}