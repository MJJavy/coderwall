/**
 * 
 */
package com.mobikasa.shopify.appinstaller.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import com.mobikasa.shopify.appinstaller.ShopifyRegisterScriptTag;
import com.mobikasa.shopify.appinstaller.constant.CodeLkupConstant;
import com.mobikasa.shopify.appinstaller.dao.impl.DashboardRepository;
import com.mobikasa.shopify.appinstaller.dao.impl.OrderRepository;
import com.mobikasa.shopify.appinstaller.dao.impl.ShopNotificationRepository;
import com.mobikasa.shopify.appinstaller.dao.impl.ShopRepository;
import com.mobikasa.shopify.appinstaller.dao.impl.ShopSiftConfigurationRepository;
import com.mobikasa.shopify.appinstaller.dto.ConfigurationDto;
import com.mobikasa.shopify.appinstaller.dto.SiftConfigurationDto;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;
import com.mobikasa.shopify.appinstaller.model.Order;
import com.mobikasa.shopify.appinstaller.model.Shop;
import com.mobikasa.shopify.appinstaller.model.ShopNotification;
import com.mobikasa.shopify.appinstaller.model.ShopSiftConfiguration;

/**
 * @author Sahil Gupta
 *
 */
@Service("dashboardService")
public class DashboardServiceImpl implements DashboardService {

	@Autowired
	private DashboardRepository dashboardRepository;
	
	@Autowired
	private OrderRepository orderRepository;

	@Autowired
	private ShopNotificationRepository shopNotificationRepository;
	
	@Autowired
	private ShopSiftConfigurationRepository shopSiftConfigurationRepository;
	
	@Autowired
	private ShopifyRegisterScriptTag registerScriptTag;
	
	@Autowired
	private ShopRepository shopRepository;	

	@Override
	@Transactional
	public SiftConfigurationDto fetchSiftConfigurationByShop(String p_shopId) throws BusinessException {
		SiftConfigurationDto result = new SiftConfigurationDto();
		try {
			ShopSiftConfiguration model = shopSiftConfigurationRepository.findByShopId(p_shopId);
			
			if(model != null) {
				result.setId(model.getId());
				result.setShopId(model.getShopId());
				
				result.setSiftEnabled(model.getSiftEnabled());
				result.setEnvironment(model.getEnvironment());
				
				result.setProductionAccountId(model.getProductionAccountId());
				result.setProductionApiKey(model.getProductionApiKey());
				result.setProductionApiBeaconKey(model.getProductionApiBeaconKey());
				result.setApiSignatureKey(model.getApiSignatureKey());
				
				result.setStagingAccountId(model.getStagingAccountId());
				result.setStagingApiKey(model.getStagingApiKey());
				result.setStagingApiBeaconKey(model.getStagingApiBeaconKey());
				
				result.setBadOrderKey(model.getBadOrderKey());
				result.setWatchOrderKey(model.getWatchOrderKey());
			} else {
				result.setSiftEnabled("0");
				result.setEnvironment("0");
			}
			

		} catch (Exception exp) {
			System.out.println();
		}
		return result;
	}
	
	@Override
	@Transactional
	public SiftConfigurationDto fetchSiftConfigurationByShopDomain(String p_shopDomain) throws BusinessException {
		SiftConfigurationDto result = new SiftConfigurationDto();
		try {
			
			Shop shop = shopRepository.findByDomain(p_shopDomain);
			
			ShopSiftConfiguration model = shopSiftConfigurationRepository.findByShopId(shop.getId());
			
			if(model != null) {
				result.setId(model.getId());
				result.setShopId(model.getShopId());
				
				result.setSiftEnabled(model.getSiftEnabled());
				result.setEnvironment(model.getEnvironment());
				
				result.setProductionAccountId(model.getProductionAccountId());
				result.setProductionApiKey(model.getProductionApiKey());
				result.setProductionApiBeaconKey(model.getProductionApiBeaconKey());
				result.setApiSignatureKey(model.getApiSignatureKey());
				
				result.setStagingAccountId(model.getStagingAccountId());
				result.setStagingApiKey(model.getStagingApiKey());
				result.setStagingApiBeaconKey(model.getStagingApiBeaconKey());
				
				result.setBadOrderKey(model.getBadOrderKey());
				result.setWatchOrderKey(model.getWatchOrderKey());
			}
			

		} catch (Exception exp) {
			System.out.println();
		}
		return result;
	}
	
	@Override
	@Transactional
	public List<ConfigurationDto> fetchSiftNotificationByShop(String p_shopId) throws BusinessException {
		List<ConfigurationDto> resultList = new ArrayList<ConfigurationDto>();
		try {
			List<Object[]> result = dashboardRepository.fetchSiftNotificationByShop(p_shopId, CodeLkupConstant.SIFT_NOTIFICATION_LIST);

			for (Object[] obj : result) {
				ConfigurationDto dto = new ConfigurationDto(obj[6] == null ? null : obj[6].toString(),
						obj[1] == null ? null : obj[1].toString(), 
						obj[5] == null ? "0" : obj[5].toString(),
						obj[2] == null ? null : obj[2].toString(), 
						obj[3] == null ? null : obj[3].toString(),
						obj[4] == null ? null : obj[4].toString(), obj[0] == null ? null : obj[0].toString());
				resultList.add(dto);
			}

		} catch (Exception exp) {
			System.out.println();
		}
		return resultList;
	}

	

	@Override
	public void saveSiftConfiguration(SiftConfigurationDto p_dto, String p_shopId) throws BusinessException {
		try {
			
			ShopSiftConfiguration model = new ShopSiftConfiguration();
			model.setId(p_dto.getId());
			model.setShopId(p_shopId);
			
			model.setSiftEnabled(p_dto.getSiftEnabled());
			model.setEnvironment(p_dto.getEnvironment());
			
			model.setProductionAccountId(p_dto.getProductionAccountId());
			model.setProductionApiKey(p_dto.getProductionApiKey());
			model.setProductionApiBeaconKey(p_dto.getProductionApiBeaconKey());
			
			model.setApiSignatureKey(p_dto.getApiSignatureKey());
			
			model.setStagingAccountId(p_dto.getStagingAccountId());
			model.setStagingApiKey(p_dto.getStagingApiKey());
			model.setStagingApiBeaconKey(p_dto.getStagingApiBeaconKey());
			
			model.setBadOrderKey(p_dto.getBadOrderKey());
			model.setWatchOrderKey(p_dto.getWatchOrderKey());
				
			shopSiftConfigurationRepository.save(model);
			
			if(p_dto.getEnvironment().equals("0")) {
				
				if(StringUtils.hasText(p_dto.getStagingApiBeaconKey())) {
					registerScriptTag.registerScriptTag(p_shopId);
				}
				
			} else {
				if(StringUtils.hasText(p_dto.getProductionApiBeaconKey())) {
					registerScriptTag.registerScriptTag(p_shopId);
				}
			}

		} catch (Exception exp) {

		}
		
	}

	@Override
	public void saveSiftNotification(Map<String, String> data, String p_shopId) throws BusinessException {
		try {
			for(Map.Entry<String, String> obj : data.entrySet()) {
				String[] array =  obj.getKey().split("~~~");
				
				ShopNotification notification = new ShopNotification();
				notification.setId(array.length > 1 ? array[1] : null);
				notification.setKeyCode(array[0]);
				notification.setShopId(p_shopId);
				notification.setValue(obj.getValue());
				
				shopNotificationRepository.save(notification);
			}
			
		} catch (Exception exp) {
			System.out.println();
		}
		
	}

}