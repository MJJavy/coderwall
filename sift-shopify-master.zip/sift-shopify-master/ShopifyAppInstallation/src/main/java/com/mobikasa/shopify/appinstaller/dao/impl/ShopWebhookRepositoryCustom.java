/**
 * 
 */
package com.mobikasa.shopify.appinstaller.dao.impl;

/**
 * @author Sahil Gupta
 *
 */

public interface ShopWebhookRepositoryCustom {
	
}
