package com.mobikasa.shopify.appinstaller.constant;

public interface SystemParamConstant {
	
	public static final String SHOPIFY_API_VERSION_NO = "api-version";

}
