package com.mobikasa.shopify.appinstaller.constant;

public interface ShopifyUrlConstant {

}
