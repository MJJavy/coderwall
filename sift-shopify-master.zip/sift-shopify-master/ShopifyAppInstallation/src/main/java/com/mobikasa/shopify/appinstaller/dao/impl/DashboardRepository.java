package com.mobikasa.shopify.appinstaller.dao.impl;

import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.shopify.appinstaller.model.CodeLkup;

@Repository
public interface DashboardRepository extends PagingAndSortingRepository<CodeLkup, String>, DashboardCustom{
	
	
}	
