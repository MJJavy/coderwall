package com.mobikasa.shopify.appinstaller.dao.impl;

public class SystemParamRepositoryImpl implements SystemParamCustom {
	

}
