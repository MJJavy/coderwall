package com.mobikasa.shopify.appinstaller.client;

public class CommonAPIManager {

	private com.fasterxml.jackson.databind.ObjectMapper mapper = new com.fasterxml.jackson.databind.ObjectMapper();
	
	/*
	 * private String connectHTTPClientAPI(String apiURL) throws IOException {
	 * StringBuffer response = new StringBuffer(); DefaultHttpClient httpClient =
	 * new DefaultHttpClient(); try { HttpGet getRequest = new HttpGet(apiURL);
	 * HttpResponse res = httpClient.execute(getRequest); System.out.println(new
	 * Date()+" Response Code : " + res.getStatusLine().getStatusCode()); if
	 * (res.getStatusLine().getStatusCode() != 200) { throw new
	 * RuntimeException("Failed : HTTP error code : " +
	 * res.getStatusLine().getStatusCode()); } BufferedReader in = new
	 * BufferedReader(new InputStreamReader((res.getEntity().getContent()))); String
	 * inputLine; while ((inputLine = in.readLine()) != null)
	 * response.append(inputLine); in.close(); System.out.println(response); } catch
	 * (ClientProtocolException e) { e.printStackTrace(); } catch (IOException e) {
	 * e.printStackTrace(); }finally { httpClient.getConnectionManager().shutdown();
	 * } return response.toString(); }
	 * 
	 * private Object parseJsonObject(String jsonString, Class<?> varClass) throws
	 * IOException { if (jsonString != null && !jsonString.isEmpty()) { try {
	 * ObjectMapper objectMapper = new ObjectMapper();
	 * objectMapper.disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES);
	 * return objectMapper.readValue(jsonString, varClass); } catch
	 * (JsonParseException jEx) { jEx.printStackTrace(); throw jEx; } catch
	 * (JsonMappingException jMEx) { jMEx.printStackTrace(); throw jMEx; } catch
	 * (IOException iEx) { iEx.printStackTrace(); throw iEx; } }
	 * System.out.println("JSON Response is not coming.Try Agian With your Json");
	 * return null; }
	 */

}

