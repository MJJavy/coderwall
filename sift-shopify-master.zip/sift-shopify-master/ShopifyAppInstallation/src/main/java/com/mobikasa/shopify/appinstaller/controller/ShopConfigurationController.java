package com.mobikasa.shopify.appinstaller.controller;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import com.mobikasa.shopify.appinstaller.dto.OrderDto;
import com.mobikasa.shopify.appinstaller.dto.ShopDto;
import com.mobikasa.shopify.appinstaller.dto.ShopSearchCriteria;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;
import com.mobikasa.shopify.appinstaller.model.BillingDetail;
import com.mobikasa.shopify.appinstaller.service.impl.BillingService;
import com.mobikasa.shopify.appinstaller.service.impl.OrderService;
import com.mobikasa.shopify.appinstaller.service.impl.PaymentChargeService;
import com.mobikasa.shopify.appinstaller.service.impl.ShopService;

@Controller
@RequestMapping("shop")
public class ShopConfigurationController {

	@Autowired
	private ShopService shopService;
	
	@Autowired
	private ShopSearchCriteria searchCriteria;
	
	@Autowired
	private PaymentChargeService paymentChargeService;
	
	@Autowired
	private OrderService orderService;
	
	@Autowired
	private BillingService billingService;
	
	private Map<String, Object> initializeData(Pageable pageable) throws BusinessException {
		Map<String, Object> model = new HashMap<String, Object>();
		try {
			List<ShopDto> shopList = shopService.findShopBillingDetail(pageable, searchCriteria);
			
			model.put("shopList", shopList);
		} catch(Exception exp){
		}
		return model;
	}
	
	@SuppressWarnings("unused")
	@RequestMapping(value = { "shopConfiguration" })
	public ModelAndView viewDashboard(@PageableDefault(size = 10) Pageable pageable, @RequestParam(required = false) String storeName, @RequestParam(required = false) String storeStatus) {
		try {
			
			Authentication auth = SecurityContextHolder.getContext().getAuthentication();
			
			String viewName = "superadmin-dashboard";
			
			searchCriteria.setName(storeName);
			searchCriteria.setStatus( storeStatus == null || storeStatus.isEmpty() ? null : storeStatus);
			
			return new ModelAndView(viewName , initializeData(pageable));
		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@PostMapping(value = { "activateSubscription" })
	public RedirectView activateSubscription(@RequestParam Long shopId, @RequestParam String subscriptionCharge, @RequestParam String apiRate) {
		try {
			
			paymentChargeService.createPaymentCharges(shopId, subscriptionCharge, apiRate);
			
			String viewName = "shopConfiguration";
			return new RedirectView(viewName);
		} catch (BusinessException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}

	@PostMapping(value = { "updateBillingRate" })
	public RedirectView updateBillingRate(@RequestParam Long shopId, @RequestParam BigDecimal apiRate) {
		try {
			
			paymentChargeService.updateBillingRate(shopId, apiRate);
			
			String viewName = "shopConfiguration";
			return new RedirectView(viewName);
		} catch (BusinessException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping(value = { "ShowReportDetail" })
	public ModelAndView ShowReportDetail(@PageableDefault(size = 20) Pageable pageable, @RequestParam String shopId, @RequestParam (required = false ) String sortDirection) {
		Map<String, Object> model = new HashMap<String, Object>();
		Page<OrderDto> orderList = null;
		Sort.Direction sort = null;
		try {
			
			BillingDetail billingDetail = billingService.findByShopId(new Long(shopId));
			if(billingDetail != null) {
				model.put("subscription", billingDetail.getSubscriptionAmount());
				model.put("apiRate", billingDetail.getPerOrderCharge());
			}
			
			ShopDto dto = shopService.findById(new Long(shopId));
			if(dto != null) {
				model.put("shopName", dto.getShopName());
				model.put("shopStatus", dto.getStatus().equals("0") ? "InActive" : "Active");
			}
			
			if(StringUtils.isEmpty(sortDirection)) {
				orderList = orderService.findPaginatedOrderList(pageable, shopId, Sort.unsorted());
			} else {
				sort = Sort.Direction.ASC.toString().equals(sortDirection) ? Sort.Direction.ASC : Sort.Direction.DESC;
				orderList = orderService.findPaginatedOrderList(pageable, shopId, Sort.by(sort, "actionTaken"));
			}
			
	        model.put("page", orderList.getNumber()+1);
	        model.put("maxPages", orderList.getTotalPages());
			model.put("orderList", orderList);
			model.put("shopId", shopId);
			model.put("orderList", orderList);
			model.put("sortDirection", sort);
			
			String viewName = "superadmin-report";
			return new ModelAndView(viewName, model);
		} catch (BusinessException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping(value = { "sortedReport" })
	public ModelAndView viewSortedReport(@PageableDefault(size = 20)Pageable pageable, @RequestParam String shopId, @RequestParam (required = false ) String sortDirection) {
		Page<OrderDto> orderList = null;
		Map<String, Object> model = new HashMap<String, Object>();
		Sort.Direction sort = null;
		try {
			
			BillingDetail billingDetail = billingService.findByShopId(new Long(shopId));
			if(billingDetail != null) {
				model.put("subscription", billingDetail.getSubscriptionAmount());
				model.put("apiRate", billingDetail.getPerOrderCharge());
			}
			
			ShopDto dto = shopService.findById(new Long(shopId));
			if(dto != null) {
				model.put("shopName", dto.getShopName());
				model.put("shopStatus", dto.getStatus().equals("0") ? "InActive" : "Active");
			}
			
			sort = StringUtils.isEmpty(sortDirection) ? Sort.Direction.ASC : (Sort.Direction.ASC.toString().equals(sortDirection) ? Sort.Direction.DESC : Sort.Direction.ASC);
			
				
			orderList = orderService.findPaginatedOrderList(pageable, shopId, Sort.by(sort, "actionTaken"));
			
	        model.put("page", orderList.getNumber()+1);
	        
	        model.put("maxPages", orderList.getTotalPages());
			model.put("orderList", orderList);
			model.put("shopId", shopId);
			model.put("sortDirection", sort);
			
			String viewName = "superadmin-report";
			return new ModelAndView(viewName , model);
		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return null;
	}

	
	public ShopSearchCriteria getSearchCriteria() {
		return searchCriteria;
	}

	public void setSearchCriteria(ShopSearchCriteria searchCriteria) {
		this.searchCriteria = searchCriteria;
	}
	
}