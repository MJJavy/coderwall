package com.mobikasa.shopify.appinstaller.model;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * 
 * 
 */
@Entity
@Table(name = "shop_sift_config")
public class ShopSiftConfiguration {

	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	@Column(name = "id", unique = true, nullable = false)
	private String id;
	
	@Column(name = "shop_id")
	private String shopId;

	@Column(name = "sift_enable")
	private String siftEnabled;
	
	@Column(name = "environment")
	private String environment;
	
	@Column(name = "production_account_id")
	private String productionAccountId;
	
	@Column(name = "production_api_key")
	private String productionApiKey;
	
	@Column(name = "production_api_beacon_key")
	private String productionApiBeaconKey;
	
	@Column(name = "api_signature_key")
	private String apiSignatureKey;
	
	@Column(name = "staging_account_id")
	private String stagingAccountId;
	
	@Column(name = "staging_api_key")
	private String stagingApiKey;
	
	@Column(name = "staging_api_beacon_key")
	private String stagingApiBeaconKey;
	
	@Column(name = "bad_order_key")
	private String badOrderKey;
	
	@Column(name = "watch_order_key")
	private String watchOrderKey;

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getShopId() {
		return shopId;
	}

	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	public String getSiftEnabled() {
		return siftEnabled;
	}

	public void setSiftEnabled(String siftEnabled) {
		this.siftEnabled = siftEnabled;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}

	public String getProductionAccountId() {
		return productionAccountId;
	}

	public void setProductionAccountId(String productionAccountId) {
		this.productionAccountId = productionAccountId;
	}

	public String getProductionApiKey() {
		return productionApiKey;
	}

	public void setProductionApiKey(String productionApiKey) {
		this.productionApiKey = productionApiKey;
	}

	public String getProductionApiBeaconKey() {
		return productionApiBeaconKey;
	}

	public void setProductionApiBeaconKey(String productionApiBeaconKey) {
		this.productionApiBeaconKey = productionApiBeaconKey;
	}

	public String getApiSignatureKey() {
		return apiSignatureKey;
	}

	public void setApiSignatureKey(String apiSignatureKey) {
		this.apiSignatureKey = apiSignatureKey;
	}

	public String getStagingAccountId() {
		return stagingAccountId;
	}

	public void setStagingAccountId(String stagingAccountId) {
		this.stagingAccountId = stagingAccountId;
	}

	public String getStagingApiKey() {
		return stagingApiKey;
	}

	public void setStagingApiKey(String stagingApiKey) {
		this.stagingApiKey = stagingApiKey;
	}

	public String getStagingApiBeaconKey() {
		return stagingApiBeaconKey;
	}

	public void setStagingApiBeaconKey(String stagingApiBeaconKey) {
		this.stagingApiBeaconKey = stagingApiBeaconKey;
	}

	public String getBadOrderKey() {
		return badOrderKey;
	}

	public void setBadOrderKey(String badOrderKey) {
		this.badOrderKey = badOrderKey;
	}

	public String getWatchOrderKey() {
		return watchOrderKey;
	}

	public void setWatchOrderKey(String watchOrderKey) {
		this.watchOrderKey = watchOrderKey;
	}

}