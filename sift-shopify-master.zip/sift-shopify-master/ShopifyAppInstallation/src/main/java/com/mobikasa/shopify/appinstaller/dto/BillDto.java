package com.mobikasa.shopify.appinstaller.dto;

import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;

public class BillDto {
	
	private String id;
	private Date billDate;
	private String description;
	private BigDecimal amount;
	
	private SimpleDateFormat format = new SimpleDateFormat("dd/MM/yyyy");
	
	public BillDto(String p_id, Date p_billDate, String p_description, BigDecimal p_amount) {
		this.id = p_id;
		this.billDate = p_billDate;
		this.description = p_description;
		this.amount = p_amount;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getBillDate() {
		
		if(billDate != null)
			return format.format(billDate);
		
		return "";
	}
	public void setBillDate(Date billDate) {
		this.billDate = billDate;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	
}