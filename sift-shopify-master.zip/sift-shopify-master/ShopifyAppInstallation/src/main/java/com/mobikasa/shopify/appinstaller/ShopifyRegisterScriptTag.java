package com.mobikasa.shopify.appinstaller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;
import org.springframework.util.StringUtils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.mobikasa.shopify.appinstaller.client.APIClient;
import com.mobikasa.shopify.appinstaller.dao.impl.ShopRepository;
import com.mobikasa.shopify.appinstaller.exception.BaseException;
import com.mobikasa.shopify.appinstaller.model.Shop;
import com.mobikasa.shopify.appinstaller.request.ScriptTag;
import com.mobikasa.shopify.appinstaller.request.ScriptTagRequest;
import com.mobikasa.shopify.appinstaller.util.RequestUrlUtility;

@Component
public class ShopifyRegisterScriptTag {
	
	@Value("${app.shopify.version}")
	private String apiVersion;
	
	@Value("${app.shopify.scriptTag.url}")
	private String scriptTagUrl;
	
	@Value("${app.shopify.scriptTag.path}")
	private String scriptTagPath;
	
	@Value("${app.shopify.scriptTag.delete.url}")
	private String deleteScriptTagUrl;

	@Value("${app.shopify.scriptTag.get.url}")
	private String getScriptTagUrl;
	
	@Autowired
	private ShopRepository shopRepository;
	
	@SuppressWarnings("unchecked")
	public void registerScriptTag(String p_shopId) {
		ObjectMapper objMapper = new ObjectMapper();
		try {
			Optional<Shop> result = shopRepository.findById(p_shopId);
			
			Map<String, String> headerMap = new HashMap<String, String>();
			headerMap.put("X-Shopify-Access-Token", result.get().getAccessToken());
			headerMap.put("Accept", "application/json");
			
			deleteScriptTag(result.get().getDomain(), headerMap);
			
			ScriptTagRequest request = new ScriptTagRequest();
			request.setScriptTag(new ScriptTag("onload", scriptTagPath));
			
			String scriptAddTagUrl = RequestUrlUtility.updateRequestUrl(scriptTagUrl, "", "", "", "", result.get().getDomain(), apiVersion);
			
			APIClient.callAPI(objMapper.writeValueAsString(request), scriptAddTagUrl, headerMap, "POST");
			
			shopRepository.save(result.get());
		} catch(Exception exp) {
			System.out.println();
		}	
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public void deleteScriptTag(String shopDomain, Map<String, String> headerMap) throws BaseException, IOException {
		ObjectMapper objMapper = new ObjectMapper();
		
		getScriptTagUrl = RequestUrlUtility.updateRequestUrlScriptId(getScriptTagUrl, shopDomain, "");
		String response = APIClient.callAPI(objMapper.writeValueAsString(""), getScriptTagUrl, headerMap, "GET");
		Map data = (Map) APIClient.parseJsonObject(response, Map.class);
		
		if( data.get("script_tags") != null &&   ((List)data.get("script_tags")).size() > 0 ) {
			
			List<Map> tags = ((List)data.get("script_tags"));
			
			for(Map tag : tags ) {
				deleteScriptTagUrl = RequestUrlUtility.updateRequestUrlScriptId(deleteScriptTagUrl, shopDomain, tag.get("id").toString());
				APIClient.callAPI(objMapper.writeValueAsString(""), deleteScriptTagUrl, headerMap, "DELETE");
			}
			
		}
		
	}	
	
}
