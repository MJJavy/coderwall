package com.mobikasa.shopify.appinstaller.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.view.RedirectView;

import com.mobikasa.shopify.appinstaller.ShopifyRegisterWebhook;
import com.mobikasa.shopify.appinstaller.service.impl.ShopService;

@RestController
public class PaymentApproveCallbackController {

	@Autowired
	private ShopifyRegisterWebhook shopifyRegisterWebhook;

	@Autowired
	private ShopService shopService;
	

	@RequestMapping(value = { "${app.payment.approve.callback.context}" })
	public RedirectView paymentApproveCallback(@RequestParam(name = "charge_id") String processId, @RequestParam String shopId) {
		try {
			
			boolean recordUpdated = shopService.updateShopProcessId(shopId, processId);

			if(recordUpdated)
				shopifyRegisterWebhook.registerShopifyWebhook(shopId);
		} catch (Exception exp) {

		}
		return new RedirectView("dashboard/configuration?shopId=" + shopId);
	}

}