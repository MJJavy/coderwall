package com.mobikasa.shopify.appinstaller.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.mobikasa.shopify.appinstaller.dto.SiftConfigurationDto;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;
import com.mobikasa.shopify.appinstaller.service.impl.DashboardService;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@Controller
public class BeactonTagController {
	
	@Autowired
	private DashboardService dashboardService;
	
	@GetMapping({ "${app.install.beaconTag.context}" })
	public ResponseEntity fetchBeaconTag(@RequestParam String shop) {
		String beaconTag = "";
		try {
			
			SiftConfigurationDto dto = dashboardService.fetchSiftConfigurationByShopDomain(shop);
			
			if(dto != null) {
				if( dto.getEnvironment().equals("0")) {
					beaconTag = dto.getStagingApiBeaconKey();
				} else {
					beaconTag = dto.getProductionApiBeaconKey();
				}
			}
		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return new ResponseEntity(beaconTag, HttpStatus.OK);
	}
	
	
}