package com.mobikasa.shopify.appinstaller.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobikasa.shopify.appinstaller.dao.impl.BillingDetailRepository;
import com.mobikasa.shopify.appinstaller.exception.BaseException;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;
import com.mobikasa.shopify.appinstaller.model.BillingDetail;

@Service
public class BillingServiceImpl implements BillingService {

	@Autowired
	private BillingDetailRepository billingRepository;
	
	@Override
	public String fetchConfirmationUrl(Long shopId) throws BaseException {
		try {
			
			Optional<BillingDetail> billingDetail = billingRepository.findByShopId(shopId);
			
			if(billingDetail.isPresent())
				return billingDetail.get().getConfirmationUrl() == null ? "" : billingDetail.get().getConfirmationUrl(); 
			
		} catch(Exception exp) {
			exp.printStackTrace();
		}
		
		return "";
	}

	@Override
	public BillingDetail findByShopId(Long id) throws BusinessException {
		try {
			
			Optional<BillingDetail> billingDetail = billingRepository.findByShopId(id); 
			
			if(billingDetail.isPresent())
				return billingDetail.get();
			
		} catch(Exception exp) {
			exp.printStackTrace();
		}
		
		return null;
	}

	
}