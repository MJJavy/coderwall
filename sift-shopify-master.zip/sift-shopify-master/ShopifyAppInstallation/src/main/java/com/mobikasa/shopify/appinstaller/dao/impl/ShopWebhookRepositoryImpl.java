package com.mobikasa.shopify.appinstaller.dao.impl;

public class ShopWebhookRepositoryImpl implements ShopWebhookRepositoryCustom {
		

}
