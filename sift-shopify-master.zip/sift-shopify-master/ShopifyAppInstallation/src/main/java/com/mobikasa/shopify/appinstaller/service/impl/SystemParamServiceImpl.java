/**
 * 
 */
package com.mobikasa.shopify.appinstaller.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobikasa.shopify.appinstaller.dao.impl.SystemParamRepository;
import com.mobikasa.shopify.appinstaller.dto.SystemParamDto;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;
import com.mobikasa.shopify.appinstaller.model.CodeLkup;

/**
 * @author Sahil Gupta
 *
 */
@Service("sysParamService")
public class SystemParamServiceImpl implements SystemParamService {
	
	@Autowired
	private SystemParamRepository sysParamRepository;

	@Override
	public SystemParamDto findSystemParamById(String p_id) throws BusinessException {
		SystemParamDto l_systemParamDto = null;
		try {
			Optional<CodeLkup> result = sysParamRepository.findById(p_id);
		} catch(Exception exp) {
			
		}
		return l_systemParamDto;
	}

	
}
