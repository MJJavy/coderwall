package com.mobikasa.shopify.appinstaller.service.impl;

import java.util.ArrayList;
import java.util.List;
import java.util.function.LongSupplier;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.repository.support.PageableExecutionUtils;
import org.springframework.stereotype.Service;

import com.mobikasa.shopify.appinstaller.dao.impl.OrderRepository;
import com.mobikasa.shopify.appinstaller.dto.OrderDto;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;
import com.mobikasa.shopify.appinstaller.model.Order;

@Service
public class OrderServiceImpl implements OrderService {

    @Autowired
    private OrderRepository orderRepository;

    public Page<OrderDto> findPaginatedOrderList(Pageable pageable, String shopId, Sort sort) throws BusinessException {
    	List<OrderDto> orderList = new ArrayList<OrderDto>();
		try {

			Page<Order> resultList = orderRepository.findByShopIdAndEnvironment(PageRequest.of(pageable.getPageNumber(), pageable.getPageSize(), sort), shopId, 0);
			for (Order result : resultList) {
				OrderDto order = new OrderDto();
				order.setOrderNo(result.getOrderNo());
				order.setCustomerName(result.getCustomerName());
				order.setSiftScore(result.getSiftScore());
				order.setAmount(result.getAmount());
				order.setActionTaken(result.getActionTaken());
				
				orderList.add(order);
			}
			
			return extractPage(resultList.getPageable(), orderList, resultList.getTotalElements());
		} catch (Exception exp) {
			System.out.println();
		}
		return null;
	}
    
    public static <T> Page<T> extractPage(Pageable page, List<T> contents, long totalElements) {

        LongSupplier totalSupplier = () -> {
            return totalElements;
        };

        return PageableExecutionUtils.getPage(contents, page, totalSupplier);
    }

    private static PageRequest gotoPage(int number, int size) {
        return PageRequest.of(number, size);
    }
}