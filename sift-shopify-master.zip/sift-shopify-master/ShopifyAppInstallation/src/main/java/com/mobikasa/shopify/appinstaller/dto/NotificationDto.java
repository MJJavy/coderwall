package com.mobikasa.shopify.appinstaller.dto;

public class NotificationDto {

	private String id;
	private String name;
	private int status;
	
	public NotificationDto(String p_id, String p_name, int p_status) {
		this.name = p_name;
		this.id = p_id;
		this.status = p_status;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}
	
	
}
