package com.mobikasa.shopify.appinstaller.dto;

public class ConfigurationDto {
	
	private String id;
	private String name;
	private String value;
	private String description;
	private String type;
	private String defaultValue;
	private String keyCode;
	
	public ConfigurationDto() {
		
	}
	public ConfigurationDto(String p_id, String p_name, String p_value, String p_description, String p_type, String p_defaultValue, String p_keyCode) {
		
		this.id = p_id;
		this.name = p_name;
		this.value = p_value;
		this.description = p_description;
		this.type = p_type;
		this.defaultValue = p_defaultValue;
		this.keyCode = p_keyCode;
	}
	
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getValue() {
		return value;
	}
	public void setValue(String value) {
		this.value = value;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getDefaultValue() {
		return defaultValue;
	}
	public void setDefaultValue(String defaultValue) {
		this.defaultValue = defaultValue;
	}

	public String getKeyCode() {
		return keyCode;
	}

	public void setKeyCode(String keyCode) {
		this.keyCode = keyCode;
	}
	
}