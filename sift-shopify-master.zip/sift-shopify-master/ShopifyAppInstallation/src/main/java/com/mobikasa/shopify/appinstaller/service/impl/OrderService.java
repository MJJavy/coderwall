package com.mobikasa.shopify.appinstaller.service.impl;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import com.mobikasa.shopify.appinstaller.dto.OrderDto;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;

@Service
public interface OrderService {
    
	public Page<OrderDto> findPaginatedOrderList(Pageable pageable, String shopId, Sort sort) throws BusinessException;

}