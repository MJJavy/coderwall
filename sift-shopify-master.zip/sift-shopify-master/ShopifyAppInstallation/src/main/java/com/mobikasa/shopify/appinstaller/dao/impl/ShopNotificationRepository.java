package com.mobikasa.shopify.appinstaller.dao.impl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.shopify.appinstaller.model.ShopNotification;

@Repository
public interface ShopNotificationRepository extends JpaRepository<ShopNotification, String>{
	
	
}	
