package com.mobikasa.shopify.appinstaller.controller;

import javax.persistence.EntityManager;
import javax.persistence.StoredProcedureQuery;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SystemMaintainanceController {

	@Autowired
	private EntityManager entityManger;

	@GetMapping(value = { "${app.install.clearSystem.context}"})
	public String clearSystem() {
		try {
			
			StoredProcedureQuery query = entityManger.createStoredProcedureQuery("truncate_tables");
			
			return "Tables truncated successfully.";
		
		} catch(Exception exp) {
			System.out.println(exp.getStackTrace());
		}	
		return "Some error has occured.";
	}

}