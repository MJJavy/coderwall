/**
 *
 */
package com.mobikasa.shopify.appinstaller.service.impl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mobikasa.shopify.appinstaller.dao.impl.UserRepository;
import com.mobikasa.shopify.appinstaller.model.UserMaster;

/**
 * @author Sahil Gupta
 *
 */
@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	public UserMaster findUserByUserName(String userName) {
		return userRepository.findByUserName(userName);
	}

}