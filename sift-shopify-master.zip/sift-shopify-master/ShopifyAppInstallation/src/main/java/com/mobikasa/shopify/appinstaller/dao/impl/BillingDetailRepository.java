package com.mobikasa.shopify.appinstaller.dao.impl;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.mobikasa.shopify.appinstaller.model.BillingDetail;

public interface BillingDetailRepository extends JpaRepository<BillingDetail, Long> {

	Optional<BillingDetail> findByShopId(Long shopId);
}
