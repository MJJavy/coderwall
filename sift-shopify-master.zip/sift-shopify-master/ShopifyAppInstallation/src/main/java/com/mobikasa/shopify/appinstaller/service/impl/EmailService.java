package com.mobikasa.shopify.appinstaller.service.impl;

public interface EmailService {
	
	public void sendSimpleMessage(String shopId, String event);

}
