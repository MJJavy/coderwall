package com.mobikasa.shopify.appinstaller.util;

import java.math.BigInteger;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.Mac;
import javax.crypto.spec.SecretKeySpec;

public class EncryptionUtil {

	private EncryptionUtil() {
	}

	public static String getEncryptedData(String input, String sharedSeceret) throws NoSuchAlgorithmException, InvalidKeyException {
		return toHexString(getSHA(input, sharedSeceret));
	}

	private static byte[] getSHA(String input, String sharedSeceret) throws NoSuchAlgorithmException, InvalidKeyException {
		Mac mac = Mac.getInstance("sha256");
	    SecretKeySpec secret = new SecretKeySpec(sharedSeceret.getBytes(),"sha256");
	    mac.init(secret);
	    byte[] digest = mac.doFinal(input.getBytes());
	    return digest; 
	}

	private static String toHexString(byte[] hash) {
		// Convert byte array into signum representation
		BigInteger number = new BigInteger(1, hash);

		// Convert message digest into hex value
		StringBuilder hexString = new StringBuilder(number.toString(16));

		// Pad with leading zeros
		while (hexString.length() < 32) {
			hexString.insert(0, '0');
		}

		return hexString.toString();
	}
}
