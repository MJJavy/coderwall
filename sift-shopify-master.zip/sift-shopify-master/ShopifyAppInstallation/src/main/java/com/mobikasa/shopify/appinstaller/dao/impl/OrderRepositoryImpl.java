package com.mobikasa.shopify.appinstaller.dao.impl;

public class OrderRepositoryImpl implements OrderCustom {
	

}
