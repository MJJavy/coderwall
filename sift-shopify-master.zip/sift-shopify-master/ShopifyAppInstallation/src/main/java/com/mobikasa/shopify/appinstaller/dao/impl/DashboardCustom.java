/**
 * 
 */
package com.mobikasa.shopify.appinstaller.dao.impl;

import java.util.List;

import com.mobikasa.shopify.appinstaller.exception.BusinessException;

/**
 * @author Sahil Gupta
 *
 */

public interface DashboardCustom {
	
	public List<Object[]> fetchSiftConfigurationByShop(String p_shopid, String p_config) throws BusinessException;
	
	public List<Object[]> fetchSiftNotificationByShop(String p_shopid, String p_config) throws BusinessException;
}
