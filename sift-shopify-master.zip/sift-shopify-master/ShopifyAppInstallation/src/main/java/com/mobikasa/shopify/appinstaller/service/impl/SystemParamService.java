package com.mobikasa.shopify.appinstaller.service.impl;

import com.mobikasa.shopify.appinstaller.dto.SystemParamDto;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;

public interface SystemParamService {
	
	public SystemParamDto findSystemParamById(String p_id) throws BusinessException;
	
}
