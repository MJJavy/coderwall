package com.mobikasa.shopify.appinstaller.controller;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.mobikasa.shopify.appinstaller.dto.BillDto;
import com.mobikasa.shopify.appinstaller.dto.ConfigurationDto;
import com.mobikasa.shopify.appinstaller.dto.OrderDto;
import com.mobikasa.shopify.appinstaller.dto.SiftConfigurationDto;
import com.mobikasa.shopify.appinstaller.exception.BaseException;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;
import com.mobikasa.shopify.appinstaller.service.impl.BillingService;
import com.mobikasa.shopify.appinstaller.service.impl.DashboardService;
import com.mobikasa.shopify.appinstaller.service.impl.OrderService;
import com.mobikasa.shopify.appinstaller.service.impl.ShopService;

@Controller
@RequestMapping("/dashboard")
public class DashboardController {
	
	@Autowired
	private DashboardService dashboardService;
	
	@Autowired
	private BillingService billingService;
	
	@Autowired
	private ShopService shopService;
	
	@Autowired
	private OrderService orderService;
	
	@GetMapping(value = { "configuration" })
	public ModelAndView viewDashboard(@PageableDefault(size = 10) Pageable pageable, @RequestParam String shopId, @RequestParam (required = false )  String activeTab
			, @RequestParam (required = false )  String saveFlag) throws NumberFormatException, BaseException {
		Map<String, Object> model = new HashMap<String, Object>();
		try {
			SiftConfigurationDto siftConfiguration = dashboardService.fetchSiftConfigurationByShop(shopId);
			
			model.put("configuration", siftConfiguration);
			model.put("confirmationUrl", billingService.fetchConfirmationUrl(new Long(shopId)));
			model.put("billingApproveStatus", shopService.findById(new Long(shopId)).getBillingApproveStatus());
			model.put("shopId", shopId);
			String viewName = "dashboard";
			
			return new ModelAndView(viewName , model);
		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping(value = { "billing" })
	public ModelAndView viewBilling(@PageableDefault(size = 10) Pageable pageable, @RequestParam String shopId, @RequestParam (required = false )  String activeTab
			, @RequestParam (required = false )  String saveFlag) {
		Map<String, Object> model = new HashMap<String, Object>();
		try {
			List<BillDto> billList = new ArrayList<BillDto>();
			for(int i=0; i<=20; i++) {
				billList.add(new BillDto("#"+i, Calendar.getInstance().getTime(), "Description "+i, BigDecimal.ZERO));
			}
			model.put("billList", billList);
			model.put("shopId", shopId);
			
			String viewName = "billing";
			return new ModelAndView(viewName , model);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping(value = { "report" })
	public ModelAndView viewReport(@PageableDefault(size = 20)Pageable pageable, @RequestParam String shopId, @RequestParam (required = false )  String activeTab
			, @RequestParam (required = false )  String saveFlag, @RequestParam (required = false ) String sortDirection) {
		Page<OrderDto> orderList = null;
		Map<String, Object> model = new HashMap<String, Object>();
		Sort.Direction sort = null;
		try {
			
			if(StringUtils.isEmpty(sortDirection)) {
				orderList = orderService.findPaginatedOrderList(pageable, shopId, Sort.unsorted());
			} else {
				sort = Sort.Direction.ASC.toString().equals(sortDirection) ? Sort.Direction.ASC : Sort.Direction.DESC;
				orderList = orderService.findPaginatedOrderList(pageable, shopId, Sort.by(sort, "actionTaken"));
			}
			
	        model.put("page", orderList.getNumber()+1);
	        model.put("maxPages", orderList.getTotalPages());
			model.put("orderList", orderList);
			model.put("shopId", shopId);
			model.put("sortDirection", sort);
			
			String viewName = "report";
			return new ModelAndView(viewName , model);
		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping(value = { "sortedReport" })
	public ModelAndView viewSortedReport(@PageableDefault(size = 20)Pageable pageable, @RequestParam String shopId, @RequestParam (required = false ) String sortDirection) {
		Page<OrderDto> orderList = null;
		Map<String, Object> model = new HashMap<String, Object>();
		Sort.Direction sort = null;
		try {
			
			
			sort = StringUtils.isEmpty(sortDirection) ? Sort.Direction.ASC : (Sort.Direction.ASC.toString().equals(sortDirection) ? Sort.Direction.DESC : Sort.Direction.ASC);
			
				
			orderList = orderService.findPaginatedOrderList(pageable, shopId, Sort.by(sort, "actionTaken"));
			
	        model.put("page", orderList.getNumber()+1);
	        
	        model.put("maxPages", orderList.getTotalPages());
			model.put("orderList", orderList);
			model.put("shopId", shopId);
			model.put("sortDirection", sort);
			
			String viewName = "report";
			return new ModelAndView(viewName , model);
		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping(value = { "notification" })
	public ModelAndView viewNotification(@PageableDefault(size = 10) Pageable pageable, @RequestParam String shopId, @RequestParam (required = false )  String activeTab
			, @RequestParam (required = false )  String saveFlag) {
		Map<String, Object> model = new HashMap<String, Object>();
		List<ConfigurationDto> notificationList = new ArrayList<ConfigurationDto>();
		try {
			
			notificationList = dashboardService.fetchSiftNotificationByShop(shopId);
			model.put("notificationList", notificationList);
			model.put("shopId", shopId);
			
			String viewName = "notification";
			return new ModelAndView(viewName , model);
		} catch (BusinessException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@GetMapping(value = { "faq" })
	public ModelAndView viewFAQ(@PageableDefault(size = 10) Pageable pageable, @RequestParam String shopId, @RequestParam (required = false )  String activeTab
			, @RequestParam (required = false )  String saveFlag) {
		Map<String, Object> model = new HashMap<String, Object>();
		try {
			String viewName = "faq";
			
			model.put("shopId", shopId);
			return new ModelAndView(viewName , model);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@PostMapping("/saveNotification")
	public ModelAndView saveNotification(@PageableDefault(size = 10) Pageable pageable, @RequestParam Map<String,String> allParams) {
		String shopId = "", activeTab = "";
		Map<String, Object> model = new HashMap<String, Object>();
		List<ConfigurationDto> notificationList = new ArrayList<ConfigurationDto>();
		try {
			activeTab = allParams.get("activeTab");
			shopId = allParams.get("shopId");
			allParams.remove("shopId");
			allParams.remove("activeTab");
			dashboardService.saveSiftNotification(allParams, shopId);
			
			
			notificationList = dashboardService.fetchSiftNotificationByShop(shopId);
			model.put("notificationList", notificationList);
			model.put("shopId", shopId);
			model.put("saveFlag", true);
			model.put("activeTab", activeTab);
			
			String viewName = "notification";
			return new ModelAndView(viewName , model);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@PostMapping("/saveConfiguration")
	public ModelAndView saveSiftConfiguration(@PageableDefault(size = 10) Pageable pageable, @RequestParam Map<String,String> allParams) {
		String shopId = "", activeTab = "";
		Map<String, Object> model = new HashMap<String, Object>();
		try {
			shopId = allParams.get("shopId");
			activeTab = allParams.get("activeTab");
			
			SiftConfigurationDto dto = new SiftConfigurationDto();
			dto.setId(allParams.get("id"));
			dto.setSiftEnabled(allParams.get("siftEnabled"));
			dto.setEnvironment(allParams.get("environment"));
			
			dto.setProductionAccountId(allParams.get("productionAccountId"));
			dto.setProductionApiKey(allParams.get("productionApiKey"));
			dto.setProductionApiBeaconKey(allParams.get("productionApiBeaconKey"));
			
			dto.setApiSignatureKey(allParams.get("apiSignatureKey"));
			
			dto.setStagingAccountId(allParams.get("stagingAccountId"));
			dto.setStagingApiKey(allParams.get("stagingApiKey"));
			dto.setStagingApiBeaconKey(allParams.get("stagingApiBeaconKey"));
			
			allParams.remove("shopId");
			dashboardService.saveSiftConfiguration(dto, shopId);
			
			SiftConfigurationDto siftConfiguration = dashboardService.fetchSiftConfigurationByShop(shopId);
			model.put("configuration", siftConfiguration);
			model.put("shopId", shopId);
			model.put("activeTab", activeTab);
			model.put("saveFlag", true);
			model.put("billingApproveStatus", shopService.findById(new Long(shopId)).getBillingApproveStatus());
			String viewName = "dashboard";
			return new ModelAndView(viewName , model);
		} catch (Exception e) {
			e.printStackTrace();
		}
		return null;
		
		
	}
}