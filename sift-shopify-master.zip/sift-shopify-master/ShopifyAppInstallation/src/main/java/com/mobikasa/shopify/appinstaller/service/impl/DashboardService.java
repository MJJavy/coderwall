package com.mobikasa.shopify.appinstaller.service.impl;

import java.util.List;
import java.util.Map;

import com.mobikasa.shopify.appinstaller.dto.ConfigurationDto;
import com.mobikasa.shopify.appinstaller.dto.SiftConfigurationDto;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;

public interface DashboardService {
	
	public SiftConfigurationDto fetchSiftConfigurationByShop(String p_shopId) throws BusinessException;
	
	public SiftConfigurationDto fetchSiftConfigurationByShopDomain(String p_shopDomain) throws BusinessException;
	
	public List<ConfigurationDto> fetchSiftNotificationByShop(String p_shopId) throws BusinessException;
	
	public void saveSiftConfiguration(SiftConfigurationDto p_dto, String p_shopId) throws BusinessException;
	
	public void saveSiftNotification(Map<String, String> data, String p_shopId) throws BusinessException;
}
