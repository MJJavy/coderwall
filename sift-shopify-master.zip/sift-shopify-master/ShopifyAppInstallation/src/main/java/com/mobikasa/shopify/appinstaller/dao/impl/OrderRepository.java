package com.mobikasa.shopify.appinstaller.dao.impl;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.shopify.appinstaller.model.Order;

@Repository
public interface OrderRepository extends PagingAndSortingRepository<Order, String>, OrderCustom{
	
	public Page<Order> findByShopIdAndEnvironment(Pageable pageable, String shopId, int environment);
}	
