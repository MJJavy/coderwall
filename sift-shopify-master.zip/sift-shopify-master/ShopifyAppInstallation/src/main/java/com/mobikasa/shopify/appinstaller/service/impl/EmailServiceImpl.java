package com.mobikasa.shopify.appinstaller.service.impl;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import com.mobikasa.shopify.appinstaller.dao.impl.ShopRepository;
import com.mobikasa.shopify.appinstaller.model.Shop;

@Component
public class EmailServiceImpl implements EmailService {
  
    @Autowired
    public JavaMailSender emailSender;
    
    @Autowired
    public ShopRepository shopRepository;
 
	@Value("${mail.fromMail}")
	private String fromMail;
	
    @Async
	@Override
	public void sendSimpleMessage(String shopId, String event) {
		try {
			Shop shop = this.fetchShopDetail(shopId);
			
	        SimpleMailMessage message = new SimpleMailMessage();
	        message.setFrom(fromMail);
	        message.setTo(shop.getEmail()); 
	        message.setSubject("App Installation"); 
	        message.setText("App has been installed successfully.");
	        emailSender.send(message);
    	} catch(Exception exp) {
    		
    	}
	}
    
    private Shop fetchShopDetail(String shopId) {
		try {
			Optional<Shop> shop = shopRepository.findById(shopId);
			return shop.get();		
    	} catch(Exception exp) {
    		
    	}
		return null;
	}
}