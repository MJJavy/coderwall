package com.mobikasa.shopify.appinstaller.request;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "recurring_application_charge"
})
public class ActivateApplicationChargeRequest {

	public ActivateApplicationChargeRequest(ActivateApplicationCharge activateApplicationCharge) {
		this.activateApplicationCharge = activateApplicationCharge;
	}
	
	
    @JsonProperty("recurring_application_charge")
    private ActivateApplicationCharge activateApplicationCharge;
    
    @JsonProperty("recurring_application_charge")
    public ActivateApplicationCharge getActivateApplicationCharge() {
        return activateApplicationCharge;
    }

    @JsonProperty("recurring_application_charge")
    public void setActivateApplicationCharge(ActivateApplicationCharge activateApplicationCharge) {
        this.activateApplicationCharge = activateApplicationCharge;
    }

}
