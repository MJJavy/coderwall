package com.mobikasa.shopify.appinstaller.dao.impl;

import java.util.List;

import javax.persistence.EntityManager;

import org.hibernate.Session;
import org.hibernate.query.Query;
import org.springframework.beans.factory.annotation.Autowired;

import com.mobikasa.shopify.appinstaller.exception.BusinessException;

public class DashboardRepositoryImpl implements DashboardCustom {
	
	@Autowired
	private EntityManager entityManger;

	@Override
	public List<Object[]> fetchSiftConfigurationByShop(String p_shopid, String p_config) throws BusinessException {
		Session session = entityManger.unwrap(Session.class);
		List<Object[]> result = null;
		try {
			
			String l_query = "select codelkup.KeyCode, codelkup.Key1 as configName, codelkup.Key2 as Descr, " + 
					"codelkup.Key3 as configType, codelkup.key4 as defaultValue, config.value as value, config.id as configId " + 
					"from codelkup " + 
					"left join shop_sift_config config on config.keycode = codelkup.keycode and config.shop_id = " + p_shopid+ " "+ 
					"where codelkup.lkupcode = '" + p_config + "'" ;
			
			Query query = session.createNativeQuery(l_query);
			
			result = query.getResultList();
				
		} catch(Exception exp) {
			
		}	
		return result;
	}

	@Override
	public List<Object[]> fetchSiftNotificationByShop(String p_shopid, String p_config) throws BusinessException {
		Session session = entityManger.unwrap(Session.class);
		List<Object[]> result = null;
		try {
			
			String l_query = "select codelkup.KeyCode, codelkup.Key1 as configName, codelkup.Key2 as Descr, " + 
					"codelkup.Key3 as configType, codelkup.key4 as defaultValue, config.value as value, config.id as configId " + 
					"from codelkup " + 
					"left join shop_sift_notification config on config.keycode = codelkup.keycode and config.shop_id = " + p_shopid+ " "+ 
					"where codelkup.lkupcode = '" + p_config + "'" ;
			
			Query query = session.createNativeQuery(l_query);
			
			result = query.getResultList();
				
		} catch(Exception exp) {
			
		}	
		return result;
	}

}
