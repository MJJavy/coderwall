/**
 * 
 */
package com.mobikasa.shopify.appinstaller.dao.impl;

import java.util.List;

import org.springframework.data.domain.Pageable;

import com.mobikasa.shopify.appinstaller.model.Shop;

/**
 * @author Sahil Gupta
 *
 */

public interface ShopRepositoryCustom {
	
	public List<Object> findShopBillingDetail(Pageable pageable, String storeName, String storeStatus);
}
