package com.mobikasa.shopify.appinstaller.request;

import java.util.HashMap;
import java.util.Map;
import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "id",
    "name",
    "api_client_id",
    "price",
    "status",
    "return_url",
    "billing_on",
    "created_at",
    "updated_at",
    "test",
    "activated_on",
    "cancelled_on",
    "trial_days",
    "trial_ends_on",
    "decorated_return_url"
})
public class ActivateApplicationCharge {

    @JsonProperty("id")
    private Long id;
    
    @JsonProperty("name")
    private String name;
    
    @JsonProperty("api_client_id")
    private Long apiClientId;
    
    @JsonProperty("price")
    private String price;
    
    @JsonProperty("status")
    private String status;
    
    @JsonProperty("return_url")
    private String returnUrl;
    
    @JsonProperty("billing_on")
    private String billingOn;
    
    @JsonProperty("created_at")
    private String createdAt;
    
    @JsonProperty("updated_at")
    private String updatedAt;
    
    @JsonProperty("test")
    private Object test;
    
    @JsonProperty("activated_on")
    private Object activatedOn;
    
    @JsonProperty("cancelled_on")
    private Object cancelledOn;
    
    @JsonProperty("trial_days")
    private Integer trialDays;
    
    @JsonProperty("trial_ends_on")
    private Object trialEndsOn;
    
    @JsonProperty("decorated_return_url")
    private String decoratedReturnUrl;
    
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("id")
    public Long getId() {
        return id;
    }

    @JsonProperty("id")
    public void setId(Long id) {
        this.id = id;
    }

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("api_client_id")
    public Long getApiClientId() {
        return apiClientId;
    }

    @JsonProperty("api_client_id")
    public void setApiClientId(Long apiClientId) {
        this.apiClientId = apiClientId;
    }

    @JsonProperty("price")
    public String getPrice() {
        return price;
    }

    @JsonProperty("price")
    public void setPrice(String price) {
        this.price = price;
    }

    @JsonProperty("status")
    public String getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(String status) {
        this.status = status;
    }

    @JsonProperty("return_url")
    public String getReturnUrl() {
        return returnUrl;
    }

    @JsonProperty("return_url")
    public void setReturnUrl(String returnUrl) {
        this.returnUrl = returnUrl;
    }

    @JsonProperty("billing_on")
    public String getBillingOn() {
        return billingOn;
    }

    @JsonProperty("billing_on")
    public void setBillingOn(String billingOn) {
        this.billingOn = billingOn;
    }

    @JsonProperty("created_at")
    public String getCreatedAt() {
        return createdAt;
    }

    @JsonProperty("created_at")
    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @JsonProperty("updated_at")
    public String getUpdatedAt() {
        return updatedAt;
    }

    @JsonProperty("updated_at")
    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @JsonProperty("test")
    public Object getTest() {
        return test;
    }

    @JsonProperty("test")
    public void setTest(Object test) {
        this.test = test;
    }

    @JsonProperty("activated_on")
    public Object getActivatedOn() {
        return activatedOn;
    }

    @JsonProperty("activated_on")
    public void setActivatedOn(Object activatedOn) {
        this.activatedOn = activatedOn;
    }

    @JsonProperty("cancelled_on")
    public Object getCancelledOn() {
        return cancelledOn;
    }

    @JsonProperty("cancelled_on")
    public void setCancelledOn(Object cancelledOn) {
        this.cancelledOn = cancelledOn;
    }

    @JsonProperty("trial_days")
    public Integer getTrialDays() {
        return trialDays;
    }

    @JsonProperty("trial_days")
    public void setTrialDays(Integer trialDays) {
        this.trialDays = trialDays;
    }

    @JsonProperty("trial_ends_on")
    public Object getTrialEndsOn() {
        return trialEndsOn;
    }

    @JsonProperty("trial_ends_on")
    public void setTrialEndsOn(Object trialEndsOn) {
        this.trialEndsOn = trialEndsOn;
    }

    @JsonProperty("decorated_return_url")
    public String getDecoratedReturnUrl() {
        return decoratedReturnUrl;
    }

    @JsonProperty("decorated_return_url")
    public void setDecoratedReturnUrl(String decoratedReturnUrl) {
        this.decoratedReturnUrl = decoratedReturnUrl;
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

}
