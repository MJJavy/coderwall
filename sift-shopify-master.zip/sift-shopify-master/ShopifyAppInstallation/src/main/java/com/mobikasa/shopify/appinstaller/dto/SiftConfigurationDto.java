package com.mobikasa.shopify.appinstaller.dto;

public class SiftConfigurationDto {
	
	private String id;
	private String siftEnabled;
	private String environment;
	
	private String productionAccountId;
	private String productionApiKey;
	private String productionApiBeaconKey;
	private String apiSignatureKey;
	
	private String stagingAccountId;
	private String stagingApiKey;
	private String stagingApiBeaconKey;
	
	private String badOrderKey;
	private String watchOrderKey;
	
	private String shopId;
	
	
	public String getSiftEnabled() {
		return siftEnabled;
	}
	public void setSiftEnabled(String siftEnabled) {
		this.siftEnabled = siftEnabled;
	}
	public String getEnvironment() {
		return environment;
	}
	public void setEnvironment(String environment) {
		this.environment = environment;
	}
	public String getProductionAccountId() {
		return productionAccountId;
	}
	public void setProductionAccountId(String productionAccountId) {
		this.productionAccountId = productionAccountId;
	}
	public String getProductionApiKey() {
		return productionApiKey;
	}
	public void setProductionApiKey(String productionApiKey) {
		this.productionApiKey = productionApiKey;
	}
	public String getProductionApiBeaconKey() {
		return productionApiBeaconKey;
	}
	public void setProductionApiBeaconKey(String productionApiBeaconKey) {
		this.productionApiBeaconKey = productionApiBeaconKey;
	}
	public String getApiSignatureKey() {
		return apiSignatureKey;
	}
	public void setApiSignatureKey(String apiSignatureKey) {
		this.apiSignatureKey = apiSignatureKey;
	}
	public String getStagingAccountId() {
		return stagingAccountId;
	}
	public void setStagingAccountId(String stagingAccountId) {
		this.stagingAccountId = stagingAccountId;
	}
	public String getStagingApiKey() {
		return stagingApiKey;
	}
	public void setStagingApiKey(String stagingApiKey) {
		this.stagingApiKey = stagingApiKey;
	}
	public String getStagingApiBeaconKey() {
		return stagingApiBeaconKey;
	}
	public void setStagingApiBeaconKey(String stagingApiBeaconKey) {
		this.stagingApiBeaconKey = stagingApiBeaconKey;
	}
	public String getBadOrderKey() {
		return badOrderKey;
	}
	public void setBadOrderKey(String badOrderKey) {
		this.badOrderKey = badOrderKey;
	}
	public String getWatchOrderKey() {
		return watchOrderKey;
	}
	public void setWatchOrderKey(String watchOrderKey) {
		this.watchOrderKey = watchOrderKey;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getShopId() {
		return shopId;
	}
	public void setShopId(String shopId) {
		this.shopId = shopId;
	}

	
}