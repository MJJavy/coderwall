package com.mobikasa.shopify.appinstaller.dto;

import java.math.BigDecimal;

public class OrderDto {
	
	private String orderNo;
	private String customerName;
	private BigDecimal amount;
	private BigDecimal siftScore;
	private String actionTaken;
	
	public OrderDto() {}
	
	public OrderDto(String p_orderNo, String p_customerName, BigDecimal p_amount, BigDecimal p_siftScore, String p_actionTaken) {
		this.orderNo      = p_orderNo;
		this.customerName = p_customerName;
		this.amount       = p_amount;
		this.siftScore    = p_siftScore;
		this.actionTaken  = p_actionTaken;
	}
	
	public String getOrderNo() {
		return orderNo;
	}
	public void setOrderNo(String orderNo) {
		this.orderNo = orderNo;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public BigDecimal getAmount() {
		return amount;
	}
	public void setAmount(BigDecimal amount) {
		this.amount = amount;
	}
	public BigDecimal getSiftScore() {
		return siftScore;
	}
	public void setSiftScore(BigDecimal siftScore) {
		this.siftScore = siftScore;
	}
	public String getActionTaken() {
		return actionTaken;
	}
	public void setActionTaken(String actionTaken) {
		this.actionTaken = actionTaken;
	}
	
}