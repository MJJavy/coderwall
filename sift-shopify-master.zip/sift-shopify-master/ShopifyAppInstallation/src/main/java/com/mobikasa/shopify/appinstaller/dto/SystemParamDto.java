package com.mobikasa.shopify.appinstaller.dto;

/**
 * The persistent class for the sysparams database table.
 * 
 */
public class SystemParamDto {

	private String paramCode;
	private String descr;
	private String key1;
	private String key2;
	private String key3;
	private String key4;
	private String key5;
	private String key6;
	private String key7;
	private String key8;
	private String key9;
	private String key10;

	/**
	 * @return the descr
	 */
	public String getDescr() {
		return descr;
	}

	/**
	 * @param descr the descr to set
	 */
	public void setDescr(String descr) {
		this.descr = descr;
	}

	/**
	 * @return the key1
	 */
	public String getKey1() {
		return key1;
	}

	/**
	 * @param key1 the key1 to set
	 */
	public void setKey1(String key1) {
		this.key1 = key1;
	}

	/**
	 * @return the key2
	 */
	public String getKey2() {
		return key2;
	}

	/**
	 * @param key2 the key2 to set
	 */
	public void setKey2(String key2) {
		this.key2 = key2;
	}

	/**
	 * @return the key3
	 */
	public String getKey3() {
		return key3;
	}

	/**
	 * @param key3 the key3 to set
	 */
	public void setKey3(String key3) {
		this.key3 = key3;
	}

	/**
	 * @return the key4
	 */
	public String getKey4() {
		return key4;
	}

	/**
	 * @param key4 the key4 to set
	 */
	public void setKey4(String key4) {
		this.key4 = key4;
	}

	/**
	 * @return the key5
	 */
	public String getKey5() {
		return key5;
	}

	/**
	 * @param key5 the key5 to set
	 */
	public void setKey5(String key5) {
		this.key5 = key5;
	}

	/**
	 * @return the key9
	 */
	public String getKey9() {
		return key9;
	}

	/**
	 * @param key9 the key9 to set
	 */
	public void setKey9(String key9) {
		this.key9 = key9;
	}

	/**
	 * @return the key6
	 */
	public String getKey6() {
		return key6;
	}

	/**
	 * @param key6 the key6 to set
	 */
	public void setKey6(String key6) {
		this.key6 = key6;
	}

	/**
	 * @return the key7
	 */
	public String getKey7() {
		return key7;
	}

	/**
	 * @param key7 the key7 to set
	 */
	public void setKey7(String key7) {
		this.key7 = key7;
	}

	/**
	 * @return the key8
	 */
	public String getKey8() {
		return key8;
	}

	/**
	 * @param key8 the key8 to set
	 */
	public void setKey8(String key8) {
		this.key8 = key8;
	}

	public String getKey10() {
		return key10;
	}

	public void setKey10(String key10) {
		this.key10 = key10;
	}

	public String getParamCode() {
		return paramCode;
	}

	public void setParamCode(String paramCode) {
		this.paramCode = paramCode;
	}
}