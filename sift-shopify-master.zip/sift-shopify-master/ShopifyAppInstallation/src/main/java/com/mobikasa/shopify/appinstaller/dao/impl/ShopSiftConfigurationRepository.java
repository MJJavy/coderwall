package com.mobikasa.shopify.appinstaller.dao.impl;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.mobikasa.shopify.appinstaller.model.ShopSiftConfiguration;

@Repository
public interface ShopSiftConfigurationRepository extends JpaRepository<ShopSiftConfiguration, String>{
	
	 public ShopSiftConfiguration findByShopId(String shopId);
}	
