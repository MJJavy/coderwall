package com.mobikasa.shopify.appinstaller.service.impl;

import java.util.List;

import com.mobikasa.shopify.appinstaller.dto.CodeLkupDto;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;

public interface CodeLkupService {
	
	public List<CodeLkupDto> fetchCodeLkupList() throws BusinessException;
	
	public String fetchAccessList() throws BusinessException;
}
