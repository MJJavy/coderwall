package com.mobikasa.shopify.appinstaller.service.impl;

import java.io.IOException;
import java.math.BigDecimal;

import com.mobikasa.shopify.appinstaller.exception.BaseException;


public interface PaymentChargeService {
	
	public String createPaymentCharges(Long p_shopId, String p_subscriptionPrice, String p_usageCharge) throws BaseException, IOException;

	public String updateBillingRate(Long p_shopId, BigDecimal p_usageCharge) throws BaseException, IOException;
}
