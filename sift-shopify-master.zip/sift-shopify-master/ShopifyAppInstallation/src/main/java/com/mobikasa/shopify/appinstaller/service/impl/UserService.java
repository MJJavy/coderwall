package com.mobikasa.shopify.appinstaller.service.impl;

import com.mobikasa.shopify.appinstaller.model.UserMaster;

public interface UserService {
	
	public UserMaster findUserByUserName(String userName);
	
}
