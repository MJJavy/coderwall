package com.mobikasa.shopify.appinstaller.service.impl;

import com.mobikasa.shopify.appinstaller.exception.BaseException;
import com.mobikasa.shopify.appinstaller.exception.BusinessException;
import com.mobikasa.shopify.appinstaller.model.BillingDetail;

public interface BillingService {
	
	public String fetchConfirmationUrl(Long shopId) throws BaseException;
	
	public BillingDetail findByShopId(Long id)  throws BusinessException;

}
