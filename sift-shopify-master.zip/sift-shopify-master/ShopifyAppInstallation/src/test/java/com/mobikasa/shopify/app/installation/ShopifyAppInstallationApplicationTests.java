package com.mobikasa.shopify.app.installation;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ShopifyAppInstallationApplicationTests {

	@Test
	void contextLoads() {
	}

}
