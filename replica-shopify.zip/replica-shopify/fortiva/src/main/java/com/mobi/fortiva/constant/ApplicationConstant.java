package com.mobi.fortiva.constant;

public interface ApplicationConstant {
	
	public static final String CHARACTER_BACKSLASH = "/";

	
	public static final String API_DATA_FORMAT_JSON = "json";
}
