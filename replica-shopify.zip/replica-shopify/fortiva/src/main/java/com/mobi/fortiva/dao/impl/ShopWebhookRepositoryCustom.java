/**
 * 
 */
package com.mobi.fortiva.dao.impl;

/**
 * @author MJ
 *
 */

public interface ShopWebhookRepositoryCustom {
	
}
