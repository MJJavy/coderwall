//package com.mobi.fortiva.dao.impl;
//
//import java.util.Optional;
//
//import org.springframework.data.jpa.repository.JpaRepository;
//
//import com.mobi.fortiva.model.BillingDetail;
//
//
//public interface BillingDetailRepository extends JpaRepository<BillingDetail, Long> {
//
//	Optional<BillingDetail> findByShopId(Long shopId);
//}
