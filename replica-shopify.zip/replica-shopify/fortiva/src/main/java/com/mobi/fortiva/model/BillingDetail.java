//package com.mobi.fortiva.model;
//
//import java.math.BigDecimal;
//import java.util.Date;
//
//import javax.persistence.Column;
//import javax.persistence.Entity;
//import javax.persistence.GeneratedValue;
//import javax.persistence.GenerationType;
//import javax.persistence.Id;
//import javax.persistence.Table;
//
//@Entity
//@Table(name = "billing_details")
//public class BillingDetail {
//
//    @Id
//    @GeneratedValue(strategy = GenerationType.IDENTITY)
//    @Column(name = "id", unique = true, nullable = false)
//    private Long id;
//
//    @Column(name = "shop_id")
//    private Long shopId;
//    
//    @Column(name = "subscription_amount")
//    private BigDecimal subscriptionAmount;
//
//    @Column(name = "usage_amount")
//    private BigDecimal usageAmount;
//
//    @Column(name = "used_amount")
//    private BigDecimal usedAmount;
//
//    @Column(name = "per_order_charge")
//    private BigDecimal perOrderCharge;
//
//    @Column(name = "threshold_percentage")
//    private BigDecimal thresholdPercentage;
//    
//    @Column(name = "next_billing_date")
//    private Date nextBillingDate;
//
//    @Column(name = "topup_url")
//    private String topupUrl;
//
//    @Column(name = "mail_sent")
//    private int mailSent;
//    
//    @Column(name = "confirmation_url")
//    private String confirmationUrl;
//
//
//    public Long getId() {
//        return id;
//    }
//
//    public void setId(Long id) {
//        this.id = id;
//    }
//
//    public Long getShopId() {
//        return shopId;
//    }
//
//    public void setShopId(Long shopId) {
//        this.shopId = shopId;
//    }
//
//    public BigDecimal getSubscriptionAmount() {
//        return subscriptionAmount;
//    }
//
//    public void setSubscriptionAmount(BigDecimal subscriptionAmount) {
//        this.subscriptionAmount = subscriptionAmount;
//    }
//
//    public BigDecimal getUsageAmount() {
//        return usageAmount;
//    }
//
//    public void setUsageAmount(BigDecimal usageAmount) {
//        this.usageAmount = usageAmount;
//    }
//
//    public BigDecimal getUsedAmount() {
//        return usedAmount;
//    }
//
//    public void setUsedAmount(BigDecimal usedAmount) {
//        this.usedAmount = usedAmount;
//    }
//
//    public BigDecimal getThresholdPercentage() {
//        return thresholdPercentage;
//    }
//
//    public void setThresholdPercentage(BigDecimal thresholdPercentage) {
//        this.thresholdPercentage = thresholdPercentage;
//    }
//
//    public BigDecimal getPerOrderCharge() {
//        return perOrderCharge;
//    }
//
//    public void setPerOrderCharge(BigDecimal perOrderCharge) {
//        this.perOrderCharge = perOrderCharge;
//    }
//
//	public Date getNextBillingDate() {
//		return nextBillingDate;
//	}
//
//	public void setNextBillingDate(Date nextBillingDate) {
//		this.nextBillingDate = nextBillingDate;
//	}
//
//    public String getTopupUrl() {
//        return topupUrl;
//    }
//
//    public void setTopupUrl(String topupUrl) {
//        this.topupUrl = topupUrl;
//    }
//
//    public int getMailSent() {
//        return mailSent;
//    }
//
//    public void setMailSent(int mailSent) {
//        this.mailSent = mailSent;
//    }
//
//	public String getConfirmationUrl() {
//		return confirmationUrl;
//	}
//
//	public void setConfirmationUrl(String confirmationUrl) {
//		this.confirmationUrl = confirmationUrl;
//	}
//    
//}