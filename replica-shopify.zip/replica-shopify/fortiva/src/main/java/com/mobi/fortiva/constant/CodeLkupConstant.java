package com.mobi.fortiva.constant;

public interface CodeLkupConstant {
	
	public static final String SHOPIFY_ACCESS_LIST = "shopify-admin-access";
	
	public static final String SIFT_CONFIGURATION_LIST = "sift-configuration";
	
	public static final String SIFT_NOTIFICATION_LIST = "sift-notification";
}
