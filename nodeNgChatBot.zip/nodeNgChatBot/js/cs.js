var app = angular.module('empappChatApp', []);
app.controller('empappChatCtrl', function($scope, $http, $compile, $window) {
    var nodeServerUrl = "https://bot.maxlifeinsurance.com/postdata";
    var botAvatar = "img/bot-icon-white.png";
    var userAvatar = "img/user-icon.png";
    var botTypingLoader = "img/chat_dots.gif";
    $scope.scrollArr =[];

    //Generate here a random string
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
    for (var i = 0; i < 9; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    var randomString = text;

    var sendOnLoadText;

//On load display default msg**************************************************************************************Start
    (function() {
        sendOnLoadText ="hi";
        var sendData = {query: sendOnLoadText, randomString: randomString,  botName: "CS"};
        console.log(sendOnLoadText)
        $http({
            method: 'POST',
            url: nodeServerUrl,
            headers: {
                'Content-Type': 'application/json'
            },
            data: sendData,
        }).then(function successCallback(response) {
          console.log(response)
            if (response && response.data && response.data.result && response.data.result.fulfillment) {
                var botResponse = response.data.result.fulfillment.speech;

                var botElemeent =
                    '<li class="other">' +
                    '<div class="avatarbox">' +
                    '<div class="avatar">' +
                    '<img src="img/bot-icon-white.png" alt="bot-icon">' +
                    '</div>' +
                    '</div>' +
                    '<div class="msg cardbox">' +
                    '<p style="border-radius:3px 10px 10px 10px">' + botResponse + '</p>' +
                    '<div class="card-wrap clearfix">'+
                    '</div>'+
                    '</div>' +
                    '</li>'+
                    '<ul class="list-inline tags">' +
                    '</ul>';
                angular.element(document.getElementById('chatResponseBox')).append($compile(botElemeent)($scope));
                $scope.scrollArr.push(botResponse);
            }
            else {

            }
            if (response && response.data && response.data.result && response.data.result.fulfillment && response.data.result.fulfillment.data
                && response.data.result.fulfillment.data.facebook && response.data.result.fulfillment.data.facebook.buttons) {
                var botResBtn = response.data.result.fulfillment.data.facebook.buttons;
                for (var i = 0; i < botResBtn.length; i++) {
                    var buttonsElem =   '<li>' +
                        `<a ng-click="clickThisBtn($event)" data-value="${botResBtn[i].postback}">` +
                        botResBtn[i].text +
                        '</a>' +
                        '</li>';
                    angular.element(document.getElementsByClassName('tags')).append($compile(buttonsElem)($scope));
                }
            }
        }, function errorCallback(response) {

        });
    })();
//On load display default msg****************************************************************************************End

//Send text msg****************************************************************************************************Start
    $scope.sendChatData= function(buttonText, postBack){
        var chatText = $scope.inputText;
        var userText;
        if(!chatText){
            userText = buttonText;
        }
       else{
            userText = chatText;
       }
        if(userText) {
            var userElemeent =    '<li class="self">'+
                '<div class="msg">'+
                '<p>'+userText+
                '</p>'+
                '</div>'+
                '</li>';
                if(postBack){
                  userText = postBack;
                }

            angular.element(document.getElementById('chatResponseBox')).append($compile(userElemeent)($scope));
            $scope.inputText = "";
            $scope.scrollArr.push(userText);

            var botImage = document.getElementsByClassName('botTypingLoader');
            if(botImage.length >0) {
                var botImageLen = botImage.length - 1;
                botImage[botImageLen].style.display = "none";
            }
            var botElemeent =   '<li class="other botTypingLoader" style="display: inline-flex">'+
                                '<div class="avatar">'+
                                '<img src="img/bot-icon-white.png" alt="bot-icon">'+
                                '</div>'+
                                '<div class="msg bot botGif">'+
                                '<img class="botTyping" src="img/chat_dots.gif" alt="typing-loader">'+
                                '</div>'+
                                '</li>';
            angular.element(document.getElementById('chatResponseBox')).append($compile(botElemeent)($scope));
            $scope.scrollArr.push(botTypingLoader);
            var sendData = {query: userText, randomString: randomString,  botName: "CS"};
            $http({
                method: 'POST',
                url: nodeServerUrl,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: sendData,
              //  timeout:5000,
            }).then(function successCallback(response) {
                if (response && response.data && response.data.result && response.data.result.fulfillment && response.data.result.fulfillment.speech) {
                    var botResponse = response.data.result.fulfillment.speech;

                      var botText =
                                    '<li class="other">' +
                                    '<div class="avatarbox">' +
                                    '<div class="avatar">' +
                                    '<img src="img/bot-icon-white.png" alt="bot-icon">' +
                                    '</div>' +
                                    '</div>' +
                                    '<div class="msg cardbox">' +
                                    '<p>' + botResponse + '</p>' +
                                    '<div class="card-wrap clearfix">'+
                                    '</div>'+
                                    '</div>' +
                                    '</li>'+
                                    '<ul class="list-inline tags">' +
                                    '</ul>';

                    angular.element(document.getElementById('chatResponseBox')).append($compile(botText)($scope));
                    $scope.scrollArr.push(botResponse);
                    var imageClass = document.getElementsByClassName('botTypingLoader');
                    var imageClassLen = imageClass.length -1;
                    imageClass[imageClassLen].style.display = "none";
                }
                else{

                }

                if (response && response.data && response.data.result && response.data.result.fulfillment && response.data.result.fulfillment.data
                    && response.data.result.fulfillment.data.facebook && response.data.result.fulfillment.data.facebook.buttons) {
                    var botResBtn = response.data.result.fulfillment.data.facebook.buttons;
                    var buttonsElem;
                    for (var i = 0; i < botResBtn.length; i++) {
                             buttonsElem =   '<li>' +
                                              `<a ng-click="clickThisBtn($event)" data-value="${botResBtn[i].postback}">` +
                                              botResBtn[i].text +
                                              '</a>' +
                                              '</li>';
                          var btnClass = document.getElementsByClassName('tags');
                          var btnClassLen = btnClass.length -1;

                        angular.element(document.getElementsByClassName('tags')[btnClassLen]).append($compile(buttonsElem)($scope));
                    }
                }
            }, function errorCallback(response) {

            });
        }
    };
//Send text msg******************************************************************************************************End

//Click channel btn************************************************************************************************Start
    $scope.clickThisBtn = function (event) {
        var buttonData = event.currentTarget;
        var postBack =  buttonData.attributes['data-value'].value;
        var buttonText = angular.element(buttonData).text();
        return $scope.sendChatData(buttonText, postBack);
    };
//Click channel btn**************************************************************************************************End

});


//Directive to keep scroll bar at bottom***************************************************************************Start
app.directive('schrollBottom', function () {
    return {
        scope: {
            schrollBottom: "="
        },
        link: function (scope, element) {
            scope.$watchCollection('schrollBottom', function (newValue) {
                if (newValue)
                {
                    $(element).scrollTop($(element)[0].scrollHeight);
                }
            });
        }
    }
});
//Directive to keep scroll bar at bottom*****************************************************************************End
