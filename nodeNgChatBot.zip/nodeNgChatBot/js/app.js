var app = angular.module('empappChatApp', []);
app.controller('empappChatCtrl', function($scope, $http, $compile, $window) {
    var nodeServerUrl = "https://bot.maxlifeinsurance.com/postdata";
    var botAvatar = "img/bot-icon-white.png";
    var userAvatar = "img/user-icon.png";
    var botTypingLoader = "img/chat_dots.gif";
    $scope.scrollArr =[];

    //Generate here a random string
    var text = "";
    var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890";
    for (var i = 0; i < 9; i++)
        text += possible.charAt(Math.floor(Math.random() * possible.length));
    var randomString = text;


    var sendOnLoadText;
    var urlParams = window.location.search;
    if(urlParams) {
        var myArrayString = urlParams.split('?')[1];
        if (myArrayString) {
            myArrayString = myArrayString.split('&');
            var key1 = myArrayString[0];
            var key2 = myArrayString[1];
            var key3 = myArrayString[2];
            var key4 = myArrayString[3];
            if(key1 && key2 && key3 && key4) {
                key1 = key1.split('=')[1];
                key2 = key2.split('=')[1];
                key3 = key3.split('=')[1];
                key4 = key4.split('=')[1];
               sendOnLoadText = key2 + " "+"authorize_ecube_002_2017_BOT_certificate"+" " +"idiosyncratic_key"+" "+ key3 + " " + key4;
               $window.sessionStorage.setItem("ssoid", key2);
                onLoadData();
            }
        }
    }
    else if(key1 != "authorize_eapp_001" &&(key3 != "IOS" || key3 != "ANDROID" )) {
        top.postMessage("sendData", "*");
        $window.addEventListener('message', function (event) {
          var ecubeID = event.data.split(" ");
           sendOnLoadText = ecubeID[1] + " "+"authorize_ecube_002_2017_BOT_certificate"+" " +"idiosyncratic_key"+" "+ ecubeID[2] + " " + ecubeID[3];
           $window.sessionStorage.setItem("ssoid", ecubeID[1]);
            onLoadData();
        });
    }

//On load display default msg**************************************************************************************Start
    function onLoadData() {
        if(sendOnLoadText.split(" ")[0] == "undefined"){
             sendOnLoadText ="ayhom0777 authorize_ecube_002_2017_BOT_certificate idiosyncratic_key web ecube";
        }
        var sendData = {query: sendOnLoadText, randomString: randomString,  botName: "EAPPBOT"};
        console.log(sendOnLoadText)
        $http({
            method: 'POST',
            url: nodeServerUrl,
            headers: {
                'Content-Type': 'application/json'
            },
            data: sendData,
        }).then(function successCallback(response) {
            console.log(response);
            if (response && response.data && response.data.result && response.data.result.fulfillment && response.data.result.fulfillment.data
                && response.data.result.fulfillment.data.facebook && response.data.result.fulfillment.data.facebook.buttons) {

                  var botResBtn = response.data.result.fulfillment.data.facebook.buttons;
                  var btnLength = botResBtn.length;
                if (btnLength === 1) {
                  var welcomeStringBot1 = response.data.result.fulfillment.speech.split(',');
                  $window.sessionStorage.setItem("bot",botResBtn[0].text);
                  return  $scope.sendChatData(botResBtn[0].text, botResBtn[0].postback, welcomeStringBot1[0]);
                }
            }
            if (response && response.data && response.data.result && response.data.result.fulfillment) {
                var botResponse = response.data.result.fulfillment.speech;
                var welcomeString = botResponse.split(',');

                var botElemeent =
                    '<div class="msg cardbox welcomeMsg">' +
                    '<p>' + welcomeString[0] + '</p>' +
                    '</div>'+
                    '<li class="other">' +
                    '<div class="avatarbox">' +
                    '<div class="avatar">' +
                    '<img src="img/bot-icon-white.png" alt="bot-icon">' +
                    '</div>' +
                    '</div>' +
                    '<div class="msg cardbox">' +
                    '<p>' + welcomeString[1] + '</p>' +
                    '<div class="card-wrap clearfix">'+
                    '<ul class="list-inline tags">' +
                    '</ul>'+
                    '</div>'+
                    '</div>' +
                    '</li>';
                angular.element(document.getElementById('chatResponseBox')).append($compile(botElemeent)($scope));
                $scope.scrollArr.push(botResponse);
            }
            else {
            }
            if (response && response.data && response.data.result && response.data.result.fulfillment && response.data.result.fulfillment.data
                && response.data.result.fulfillment.data.facebook && response.data.result.fulfillment.data.facebook.buttons) {
                var botResBtn = response.data.result.fulfillment.data.facebook.buttons;
                for (var i = 0; i < botResBtn.length; i++) {

                    var buttonsElem =   '<li>' +
                        `<a ng-click="clickThisBtn($event)" data-value="${botResBtn[i].postback}">` +
                        botResBtn[i].text +
                        '</a>' +
                        '</li>';
                    angular.element(document.getElementsByClassName('tags')).append($compile(buttonsElem)($scope));
                }
            }
        }, function errorCallback(response) {
        });
    };
//On load display default msg****************************************************************************************End

//Send text msg****************************************************************************************************Start
    $scope.sendChatData= function(buttonText, postBack, welcomeMsgBot1){
        var bot = $window.sessionStorage.getItem("bot");
        var ssoid = $window.sessionStorage.getItem("ssoid");

        var chatText = $scope.inputText;
        var userText;
        if(!chatText){
            userText = buttonText;
        }
       else{
            userText = chatText;
       }
          if(userText && !welcomeMsgBot1) {
              var userElemeent =    '<li class="self">'+
                                    '<div class="msg">'+
                                    '<p>'+userText+
                                    '</p>'+
                                    '</div>'+
                                    '</li>';

              angular.element(document.getElementById('chatResponseBox')).append($compile(userElemeent)($scope));
              $scope.inputText = "";
              $scope.scrollArr.push(userText);

              var botImage = document.getElementsByClassName('botTypingLoader');
              if(botImage.length >0) {
                  var botImageLen = botImage.length - 1;
                  botImage[botImageLen].style.display = "none";
              }
              var botElemeent =   '<li class="other botTypingLoader" style="display: inline-flex">'+
                                  '<div class="avatar">'+
                                  '<img src="img/bot-icon-white.png" alt="bot-icon">'+
                                  '</div>'+
                                  '<div class="msg bot botGif">'+
                                  '<img class="botTyping" src="img/chat_dots.gif" alt="user-icon">'+
                                  '</div>'+
                                  '</li>';
              angular.element(document.getElementById('chatResponseBox')).append($compile(botElemeent)($scope));
              $scope.scrollArr.push(botTypingLoader);
          }
          var botBtn = ["Business Numbers","FLS", "HRPolicies"]
          if(botBtn.indexOf(userText) > -1){
            if(!ssoid || ssoid === "undefined"){
                userText = postBack + " "+ "ayhom0777";
            }
            else {
              userText = postBack + " " +ssoid;
            }
          }
            var sendData = {query: userText, randomString: randomString, botName: bot};
            $http({
                method: 'POST',
                url: nodeServerUrl,
                headers: {
                    'Content-Type': 'application/json'
                },
                data: sendData,
            }).then(function successCallback(response) {
              console.log(response);
                if (response && response.data && response.data.result && response.data.result.fulfillment && response.data.result.fulfillment.speech) {
                    var botResponse = response.data.result.fulfillment.speech;
                    if(welcomeMsgBot1){
                      var botText =
                                      '<div class="msg cardbox welcomeMsg">' +
                                      '<p>' + welcomeMsgBot1+ '</p>' +
                                      '</div>'+
                                      '<li class="other">'+
                                      '<div class="avatar">'+
                                      '<img src="img/bot-icon-white.png" alt="bot-icon">'+
                                      '</div>'+
                                      '<div class="msg bot" style="border-radius:1px 15px 15px 15px">'+
                                      '<p class="botResponse">' + botResponse + '</p>'+
                                      '</div>'+
                                      '</li>';
                    }
                    else{
                      var botText =   '<li class="other">'+
                                      '<div class="avatar">'+
                                      '<img src="img/bot-icon-white.png" alt="bot-icon">'+
                                      '</div>'+
                                      '<div class="msg bot">'+
                                      '<p class="botResponse">' + botResponse + '</p>'+
                                      '</div>'+
                                      '</li>';
                                      // '<ul class="list-inline tags">' +
                                      // '</ul>';
                    }

                    angular.element(document.getElementById('chatResponseBox')).append($compile(botText)($scope));
                    $scope.scrollArr.push(botResponse);
                    var imageClass = document.getElementsByClassName('botTypingLoader');
                    var imageClassLen = imageClass.length -1;
                    if(imageClassLen>=0){
                      imageClass[imageClassLen].style.display = "none";
                    }
                }
                else{
                  //  errorMsgDisplay();

                }
            }, function errorCallback(response) {

            });
    };
//Send text msg******************************************************************************************************End

//Click channel btn************************************************************************************************Start
    $scope.clickThisBtn = function (event) {
        var buttonData = event.currentTarget;
        var postBack =  buttonData.attributes['data-value'].value;
        var buttonText = angular.element(buttonData).text();
        $window.sessionStorage.setItem("bot",buttonText);
        return $scope.sendChatData(buttonText, postBack);
    };
//Click channel btn**************************************************************************************************End
});


//Directive to keep scroll bar at bottom***************************************************************************Start
app.directive('schrollBottom', function () {
    return {
        scope: {
            schrollBottom: "="
        },
        link: function (scope, element) {
            scope.$watchCollection('schrollBottom', function (newValue) {
                if (newValue)
                {
                    $(element).scrollTop($(element)[0].scrollHeight);
                }
            });
        }
    }
});
//Directive to keep scroll bar at bottom*****************************************************************************End
