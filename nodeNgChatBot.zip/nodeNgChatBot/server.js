var express = require('express');
var app = express();
var http = require('http');
var httpServer =    http.Server(app);
var port = process.env.PORT || 3000;
var bodyParser = require('body-parser');
var request = require('request');
var apiAiUrl = "https://api.api.ai/v1/query?v=20150910";
// var accessToken = "6da3038a47f9467eb24f45514bfa43b3";          //DEV MIS
//   var accessToken = "0289c208053c4acc866b05f944b8496d";         //UAT MIS
//  var accessToken = "3c0d8b8d9cd3469ca3c8ceb2188ce944";         //Prod MIS
// var accessToken = "9d479f64f1214860ba916e9499eb4ec9";             //CS BOT Prod

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json())

allowCrossDomain = function(req, res, next) {
    res.header('Access-Control-Allow-Origin', '*');
    res.header('Access-Control-Allow-Methods', 'GET,POST,OPTIONS');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization, Content-Length, X-Requested-With');
    res.header('Content-Security-Policy', 'frame-ancestors https://*.maxlifeinsurance.com');
    if ('OPTIONS' === req.method) {
        res.send(200);
    } else {
        next();
    }
};

app.use(allowCrossDomain);

app.use(express.static('./'));
app.get('/', function(req, res) {
    res.sendFile(__dirname + '/index.html');
});

app.get('/empapp', function(req, res) {
    res.sendFile(__dirname + '/index.html');
});

app.get('/cs', function(req, res) {
    res.sendFile(__dirname + '/cs.html');
});

var botResponse;
var accessToken;
app.post('/postdata',  function (req, res) {
    var queryData  =  JSON.stringify({query: req.body.query, lang: "en", sessionId: req.body.randomString});
    console.log("Query=", queryData);
    var botName = req.body.botName;
    if(botName === "EAPPBOT"){
        accessToken = "8368461315e24504ab7d04a463259530";            //EApp BOT
    }
    else if(botName === "CS"){
      accessToken = "9192441321e9465b817f6e1bd923bb35";         //CS BOT Prod

           // accessToken = "9d479f64f1214860ba916e9499eb4ec9";         //CS BOT Prod
    }
    else if(botName === "Business Numbers"){
            accessToken = "0289c208053c4acc866b05f944b8496d";         //UAT MIS BOT
          // accessToken = "3c0d8b8d9cd3469ca3c8ceb2188ce944";         //Prod MIS BOT
    }
    else if(botName === "HRPolicies"){
           accessToken = "7a570ad72aec41899e01d881f6c2fa98";         //DEV HR BOT
    }
    else if(botName === "FLS"){
           accessToken = "7ac4c0cb29dd49a3ad1971c4aa3cb440";         //UAT FLS BOT
          // accessToken = "cc2268247c094f6a9d84242ed604c2b9";         //Prod FLS BOT
    }
    console.log(accessToken);
    request({
            url: apiAiUrl,
            method: "POST",
            headers: {
                "Content-Type": "application/json",
                "Authorization": "Bearer" +" "+accessToken,
            },
            body: queryData,
        }, function callback(error, response, body) {
            if (!error && response && response.statusCode == 200) {
                botResponse = JSON.parse(body);
                // console.log(botResponse);
                res.send(botResponse);
            }
            else{
                console.log("there is error")
                res.status(400);
            }
        });
});

httpServer.listen(port, function() {
    console.log('App is listening on :' + port);
});
