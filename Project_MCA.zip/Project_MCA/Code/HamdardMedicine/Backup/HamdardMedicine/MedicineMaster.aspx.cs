﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Reflection;
using System.Data.SqlClient;
using System.Data.Common;
using System.IO;
using System.Text;


using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace HamdardMedicine
{
    public partial class MedicineMaster : System.Web.UI.Page
    {
        string conString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
        
        protected void Page_Load(object sender, EventArgs e)
        {
            //btnSave.Attributes.Add("onClick ", " return ValidateNumber();");
            lblSave.Text = "";
            GetMedicine();
        }

        protected void btnSave_Click(object sender, ImageClickEventArgs e)
        {
            string gmlit = rdoGm.Checked ? "GM" : "ML";
            int WtLit = Convert.ToInt16(txtWtLit.Text.Trim());
            Decimal Price = Convert.ToDecimal(txtPrice.Text.Trim());
            InsertMedicine(txtMedicineCode.Text.Trim(), txtMedicineName.Text.Trim(), WtLit, gmlit, txtRemark.Text.Trim(), Price);
            GetMedicine();
        }
        public void InsertMedicine(string medicineCode, string medicineName, int gramlit, string gmlit, string remark, Decimal price)
        {
            SqlConnection myConnection = new SqlConnection(conString);
            SqlCommand myCommand;
            try
            {   
                myConnection.Open();
                myCommand = new SqlCommand("UDSP_InsertMedcine", myConnection);
                myCommand.CommandType = CommandType.StoredProcedure;

                myCommand.Parameters.Add("@medicineCode", SqlDbType.VarChar);
                myCommand.Parameters["@medicineCode"].Value = medicineCode;

                myCommand.Parameters.Add("@medicineName", SqlDbType.VarChar);
                myCommand.Parameters["@medicineName"].Value = medicineName;

                myCommand.Parameters.Add("@gramlit", SqlDbType.Int);
                myCommand.Parameters["@gramlit"].Value = gramlit;

                myCommand.Parameters.Add("@gmlit", SqlDbType.VarChar);
                myCommand.Parameters["@gmlit"].Value = gmlit;

                myCommand.Parameters.Add("@Price", SqlDbType.Decimal);
                myCommand.Parameters["@Price"].Value = price;

                myCommand.Parameters.Add("@Remark", SqlDbType.VarChar);
                myCommand.Parameters["@Remark"].Value = remark;

               int result =  myCommand.ExecuteNonQuery();
               if (result == 1)
                {
                    lblSave.Text = "Data Saved Successfully";
                }
                myConnection.Close();
            }
            catch (Exception ex)
            {
                lblSave.Text = "Error occured in saving Data";
                throw ex;

            }
            finally { myConnection.Close(); }
                

        }

        private void GetMedicine()
        {
            SqlConnection myConnection;
            DataSet ds;
            SqlDataAdapter da  ;
            try
            {
                myConnection = new SqlConnection(conString);
                myConnection.Open();
                ds = new DataSet();
                da = new SqlDataAdapter("Select Medcine_ID, medicineCode,medicineName,CAST(gramlit as varchar)  + ' ' + gmlit gramlit ,price, Remark From Master_Medicine", myConnection);
                da.Fill(ds);
                grdMedicine.DataSource = ds;
                grdMedicine.DataBind();
                myConnection.Close();
            }

            catch (Exception ex)
            {

                throw ex;

            }
            
        }

        protected void rdoGm_CheckedChanged(object sender, EventArgs e)
        {
            rdoLit.Checked = false;
            rdoGm.Checked = true;
        }

        protected void rdoLit_CheckedChanged(object sender, EventArgs e)
        {   
                rdoLit.Checked = true;
                rdoGm.Checked = false;
        }

        protected void btnCancel_Click(object sender, ImageClickEventArgs e)
        {
            txtMedicineCode.Text = "";
            txtMedicineName.Text = "";
            txtRemark.Text = "";
            txtWtLit.Text = "";
            txtPrice.Text = "";
            rdoGm.Checked = true;
            rdoLit.Checked = false;

        }

       
        protected void grdMedicine_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdMedicine.PageIndex = e.NewPageIndex;
            grdMedicine.DataBind();

        }
    }
    
}