﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Reflection;
using System.Data.SqlClient;
using System.Data.Common;
using System.IO;
using System.Text;


using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace HamdardMedicine
{
    public partial class BillingTransaction : System.Web.UI.Page
    {
        string conString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
        DataSet ds = new DataSet();
        double BillPrice = 0;
        double FooterBillPrice = 0;
        protected void Page_Load(object sender, EventArgs e)
        {
            lblSave.Text = "";

            if (!IsPostBack)
            {
                txtQuantity.Text = "1";
                ds.Tables.Add("med");
                ds.Tables["med"].Columns.Add("medicineCode");
                ds.Tables["med"].Columns.Add("medicineName");
                ds.Tables["med"].Columns.Add("price");
                ds.Tables["med"].Columns.Add("Qty");
                ds.Tables["med"].Columns.Add("Totalprice");
                ViewState["ds"] = ds;
                ViewState["FooterBillPrice"] = 0.0;
            }
        }

        protected void btnSave_Click(object sender, ImageClickEventArgs e)
        {
            AddMedicine();

            txtMedicineCode.Text = "";
            txtMedicineName.Text = "";
            txtQuantity.Text = "1";
            txtPrice.Text = "";
        }


        public void AddMedicine()
        {
            try
            {
                ds = (DataSet)ViewState["ds"];
                FooterBillPrice = Convert.ToDouble(ViewState["FooterBillPrice"]);
                if (ds.Tables[0].Rows.Count > 0)
                {
                    ds.Tables["med"].Rows.RemoveAt(ds.Tables["med"].Rows.Count - 1);
                }
                DataRow newrow = ds.Tables["med"].NewRow();
                newrow["medicineCode"] = txtMedicineCode.Text.Trim();
                newrow["medicineName"] = txtMedicineName.Text.Trim();
                newrow["price"] = txtPrice.Text.Trim();
                newrow["Qty"] = txtQuantity.Text.Trim();
                newrow["Totalprice"] = Convert.ToString(Convert.ToDouble(txtPrice.Text.Trim()) * Convert.ToDouble(txtQuantity.Text.Trim()));
                ds.Tables["med"].Rows.Add(newrow);
                FooterBillPrice = FooterBillPrice + (Convert.ToDouble(txtPrice.Text.Trim()) * Convert.ToDouble(txtQuantity.Text.Trim()));
                newrow = ds.Tables["med"].NewRow();
                newrow["Qty"] = "Total Amount";
                newrow["Totalprice"] = FooterBillPrice;
                ds.Tables["med"].Rows.Add(newrow);
                ViewState["FooterBillPrice"] = FooterBillPrice;
                ViewState["ds"] = ds;
                grdMedicine.DataSource = ds;
                grdMedicine.DataBind();
            }
            catch (Exception ex)
            {

                throw ex;

            }

        }



        protected void btnCancel_Click(object sender, ImageClickEventArgs e)
        {
            txtMedicineCode.Text = "";
            txtMedicineName.Text = "";
            txtQuantity.Text = "1";
            txtPrice.Text = "";
            txtpatient.Text = "";
            ViewState["ds"] = null;
            grdMedicine.DataSource = null;
            grdMedicine.DataBind();

        }

        protected void txtMedicineCode_TextChanged(object sender, EventArgs e)
        {
            FillMedicine(Convert.ToString(txtMedicineCode.Text.Trim()));

        }
        private void FillMedicine(string medicineCode)
        {
            SqlConnection myConnection;
            DataSet ds;
            SqlDataAdapter da;
            try
            {
                myConnection = new SqlConnection(conString);
                myConnection.Open();
                ds = new DataSet();
                da = new SqlDataAdapter("Select Medcine_ID, medicineCode,medicineName,CAST(gramlit as varchar)  + ' ' + gmlit gramlit ,price, Remark From Master_Medicine where medicineCode = '" + medicineCode + "'", myConnection);
                da.Fill(ds);
                txtMedicineName.Text = Convert.ToString(ds.Tables[0].Rows[0]["medicineName"]);
                txtPrice.Text = Convert.ToString(ds.Tables[0].Rows[0]["price"]);
            }
            catch (Exception ex)
            {

                throw ex;

            }

        }

        protected void GenerateBill_Click(object sender, ImageClickEventArgs e)
        {
            int BillNO = 0;
            BillNO = GetBill();
            GenerateMedicalBill(BillNO);
            txtMedicineCode.Text = "";
            txtMedicineName.Text = "";
            txtQuantity.Text = "1";
            txtPrice.Text = "";
            ViewState["ds"] = null;
        }


        public int GetBill()
        {
            SqlConnection myConnection;
            DataSet ds;
            SqlDataAdapter da;
            int BillNO = 0;
            try
            {
                myConnection = new SqlConnection(conString);
                myConnection.Open();
                ds = new DataSet();
                da = new SqlDataAdapter("SELECT ISNULL(MAX(BillNo),0) + 1 from billing", myConnection);
                da.Fill(ds);
                BillNO = Convert.ToInt16(ds.Tables[0].Rows[0][0]);
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return BillNO;
        }

        public void GenerateMedicalBill(int BillNO)
        {
            DataSet dsmedicine = new DataSet();
            string medicinecode = "";
            string medicineName = "";
            BillPrice = 0;
            double price = 0;
            double Qty = 0;
            double TotalPrice = 0;
            string patient = txtpatient.Text;
            StringBuilder sbbill = new StringBuilder();
            StringBuilder sbtxn = new StringBuilder();

            SqlConnection myConnection = new SqlConnection(conString);
            SqlCommand myCommand;
            try
            {

                dsmedicine = (DataSet)ViewState["ds"];
                if (dsmedicine.Tables[0].Rows.Count > 0)
                {
                    dsmedicine.Tables["med"].Rows.RemoveAt(dsmedicine.Tables["med"].Rows.Count - 1);
                    for (int medcount = 0; medcount < dsmedicine.Tables[0].Rows.Count; medcount++)
                    {
                        medicinecode = Convert.ToString(dsmedicine.Tables[0].Rows[medcount]["medicineCode"]);
                        medicineName = Convert.ToString(dsmedicine.Tables[0].Rows[medcount]["medicineName"]);
                        price = Convert.ToDouble(dsmedicine.Tables[0].Rows[medcount]["price"]);
                        Qty = Convert.ToDouble(dsmedicine.Tables[0].Rows[medcount]["Qty"]);
                        TotalPrice = Convert.ToDouble(dsmedicine.Tables[0].Rows[medcount]["Totalprice"]);
                        BillPrice = BillPrice + TotalPrice;
                        sbtxn.Append("INSERT INTO Billing_Txn (BillNo, medicineCode, medicineName, PRICE, Qty,TOTALPRICE,BILLDATE) VALUES(" + BillNO + ",'" + medicinecode + "','" + medicineName + "'," + price + "," + Qty + "," + TotalPrice + ",getdate())\n");
                    }
                    sbbill.Append("INSERT INTO Billing (BillNo, Patient, TOTALPRICE,BILLDATE) VALUES(" + BillNO + ",'" + patient + "'," + BillPrice + ",getdate())\n");

                    myConnection.Open();
                    myCommand = new SqlCommand(sbbill.ToString() + sbtxn.ToString(), myConnection);
                    myCommand.CommandType = CommandType.Text;
                    int result = myCommand.ExecuteNonQuery();
                    lblSave.Text = "Data Saved Successfully with BILL NO. &nbsp;&nbsp  HM" + BillNO + "&nbsp;&nbsp;&nbsp;&nbsp;   Bill Amount:    &nbsp;&nbsp;&nbsp;&nbsp;" + BillPrice;
                    lblSave.Font.Bold = true;
                    lblSave.Font.Size = 10;
                    myConnection.Close();
                }
            }
            catch (Exception ex)
            {
                lblSave.Text = "Error occured in saving Data";
                throw ex;

            }
            finally { myConnection.Close(); }

        }
        
    }

}