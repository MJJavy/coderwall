﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Reflection;
using System.Data.SqlClient;
using System.Data.Common;
using System.IO;
using System.Text;


using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Logging;


namespace HamdardMedicine
{
    public partial class SearchMedcine : System.Web.UI.Page
    {
        string conString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnSave_Click(object sender, ImageClickEventArgs e)
        {
            GetMedicine();
        }
        private void GetMedicine()
        {
            SqlConnection myConnection;
            DataSet ds;
            SqlDataAdapter da;
            string medicinecode = "";
            string medicineName = "";
            string sql = "";
            try
            {
                medicinecode = txtMedicineCode.Text.Trim();
                medicineName = txtMedicineName.Text.Trim();
                if (medicinecode.Length > 0)
                {  
                    sql = "Select Medcine_ID, medicineCode,medicineName,CAST(gramlit as varchar)  + ' ' + gmlit gramlit ,price, Remark From Master_Medicine where medicineCode LIKE  '%" + medicinecode + "%'";
                }
                else if (medicineName.Length > 0)
                {
                    sql = "Select Medcine_ID, medicineCode,medicineName,CAST(gramlit as varchar)  + ' ' + gmlit gramlit ,price, Remark From Master_Medicine where medicineName LIKE  '%" + medicineName + "%'";
                }
                else
                {
                    sql = "Select Medcine_ID, medicineCode,medicineName,CAST(gramlit as varchar)  + ' ' + gmlit gramlit ,price, Remark From Master_Medicine";
                }
                myConnection = new SqlConnection(conString);
                myConnection.Open();
                ds = new DataSet();
                da = new SqlDataAdapter(sql, myConnection);
                da.Fill(ds);
                grdMedicine.DataSource = ds;
                grdMedicine.DataBind();
            }
            catch (Exception ex)
            {

                throw ex;

            }

        }
    }
}