﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Reflection;
using System.Data.SqlClient;
using System.Data.Common;
using System.IO;
using System.Text;


namespace HamdardMedicine
{
    public partial class Loginpage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
           
        }

       
        protected void Save_Click(object sender, EventArgs e)
        {
            if (txtuser.Text == "hamdard" && txtpassword.Text == "hamdard")
            {
                Response.Redirect("Default.aspx");
            }
            else
            {
                mess.Text = "Invalid Login";
            }
        }
    }
}