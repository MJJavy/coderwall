﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;

using System.Reflection;
using System.Data.SqlClient;
using System.Data.Common;
using System.IO;
using System.Text;


using Microsoft.Practices.EnterpriseLibrary.Data;
using Microsoft.Practices.EnterpriseLibrary.Common;
using Microsoft.Practices.EnterpriseLibrary.Logging;

namespace HamdardMedicine
{
    public partial class BillReport : System.Web.UI.Page
    {
        string conString = ConfigurationManager.ConnectionStrings["myConnectionString"].ConnectionString;
        SqlConnection myConnection;
        DataSet ds;
        SqlDataAdapter da;
        string strSQL = "";
        protected void Page_Load(object sender, EventArgs e)
        {  
            lblSave.Text = "";
            if(!IsPostBack)
            {
                txtFromDate.Text = DateTime.Now.Day.ToString() + "-" +  DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString();
                txtToDate.Text = DateTime.Now.Day.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString();
            }
        }

        protected void btnSave_Click(object sender, ImageClickEventArgs e)
        {   
            GetMedicine();
        }
        

        private void GetMedicine()
        {   
            string fromdate = txtFromDate.Text.Trim();
            string toDate= txtToDate.Text.Trim();
            fromdate = fromdate.Split('-')[2].ToString() + "-" + fromdate.Split('-')[1].ToString()+ "-" + fromdate.Split('-')[0].ToString();
            toDate = toDate.Split('-')[2].ToString() + "-" + toDate.Split('-')[1].ToString() + "-" + toDate.Split('-')[0].ToString();
            try
            {
                myConnection = new SqlConnection(conString);
                myConnection.Open();
                ds = new DataSet();
                strSQL = "select  'HM' + convert(varchar,BillNo) BillNo, Patient,TOTALPRICE, convert(varchar,BILLDATE, 106) BILLDATE from Billing WHERE BILLDATE between '" + fromdate + "' AND '" + toDate + "'";
                   
                da = new SqlDataAdapter(strSQL, myConnection);
                da.Fill(ds);
                grdMedicine.DataSource = ds;
                grdMedicine.DataBind();
            }
            catch (Exception ex)
            {

                throw ex;

            }

        }

        protected void btnCancel_Click(object sender, ImageClickEventArgs e)
        {
            txtFromDate.Text = DateTime.Now.Day.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString();
            txtToDate.Text = DateTime.Now.Day.ToString() + "-" + DateTime.Now.Month.ToString() + "-" + DateTime.Now.Year.ToString();
            ds = null;
            grdMedicine.DataSource = ds;
            grdMedicine.DataBind();
           
        }

       
        protected void grdMedicine_PageIndexChanging(object sender, GridViewPageEventArgs e)
        {
            grdMedicine.PageIndex = e.NewPageIndex;
            GetMedicine();

        }
    }
    
}