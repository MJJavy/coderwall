package com.max.report.action;

import java.util.ResourceBundle;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.DriverManager;

import org.apache.log4j.Logger;



public class DBHelper 
{
	private static DBHelper instance=null;
	String encryptionKey = null;
	String encryptionScheme = null;
	static Logger logger = Logger.getLogger(DBHelper.class.getName());

	public DBHelper()
	{
		encryptionKey = "peGas@#235X798c5TEV23*9peGaT@#234X758c5TEV23*9";
        encryptionScheme = "DES";
	}
	
	public Connection getSourceConnection() throws SQLException
	{
		Connection con = null;
		String url = null;
		String user = null;
		String pwd = null;
		ResourceBundle rb = null;
		try
		{
			rb = ResourceBundle.getBundle("com.max.report.resources.ApplicationResource");
			url = rb.getString("DB_URL");
			user = rb.getString("DB_USER");
			pwd = rb.getString("DB_PWD");
			if(rb.getString("DB_TYPE")!=null && rb.getString("DB_TYPE").equalsIgnoreCase("SYBASE"))
			{
				//DriverManager.registerDriver(new com.sybase.jdbc4.jdbc.SybDriver());
			}
			else if(rb.getString("DB_TYPE")!=null && rb.getString("DB_TYPE").equalsIgnoreCase("ORACLE"))			 
			{
				DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
			}
			con = DriverManager.getConnection(url, user, pwd);
			if(con ==null)
			{			
				logger.debug("Unable to connect with database....");
				System.out.println("Unable to connect with database....");
			}
		}
		catch(Exception e)
		{
			e.printStackTrace(); 
			logger.error("Error while getting connection from data source "+e);
			throw new SQLException("Connection failed...");
		}		
		return con;
	}
	
	public static synchronized DBHelper getInstance()
	{
		if(instance == null)
		{
			logger.debug("Creating DBHelper Instance.");
			instance = new DBHelper();
		}
		return instance;
	}
}
