package com.max.report.action;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;


public  class SchedulerStatus 
{
	static Logger logger = Logger.getLogger(SchedulerStatus.class.getName());
	
	public String getLastExecutedDetails(String [] param)
	{
		String enddate="";
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("getLastExecutedDetails starts...");
		try
		{
			con =DBHelper.getInstance().getSourceConnection();
			String sql = "Select Start_date,end_date from EKUDOCS_DATA_TRACKER";
			pst = con.prepareStatement(sql);
			int i=0;
			if(param.length>0)
    		{
    			logger.info("SQL query to be executed : "+sql +" with Parameters :-"+Arrays.toString(param));
		        while(i<param.length)
		        {
		        	pst.setString(i+1,param[i]);
		        	i++;
		        }
    		}
    		else
    		{
    			logger.info("SQL query to be executed : "+sql);
    		}		
			logger.info("Executing query for getLastExecutedDetails");
			rs = pst.executeQuery();
			if(rs!=null)
			{
				while (rs.next()) 
                {                	
					enddate= rs.getString("end_date");              		                	
                }    	
			}
		}
		catch (Exception e) 
		{			
			e.printStackTrace();
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                e.printStackTrace();
                logger.error("SQL exception while closing resource : " + e);
                System.out.println("SQL exception while closing resource : " + e);
            }
        }
		logger.info("getLastExecutedDetails ends...");
		return enddate;
	}
	
	
	
	
	public void setCurrentExecuteddetails(String [] param)
	{
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("setCurrentExecuteddetails starts...");
		try
		{
			con = DBHelper.getInstance().getSourceConnection();
			String sql = "INSERT INTO EKUDOCS_DATA_TRACKER(START_DATE,END_DATE) VALUES(?,?)";
			pst = con.prepareStatement(sql);
			int i=0;
			if(param.length>0)
    		{
    			logger.info("SQL query to be executed : "+sql +" with Parameters :-"+Arrays.toString(param));
		        while(i<param.length)
		        {
		        	pst.setString(i+1,param[i]);
		        	i++;
		        }
    		}
    		else
    		{
    			logger.info("SQL query to be executed : "+sql);
    		}			
			pst.executeUpdate();			
		}
		catch (Exception e) 
		{			
			logger.error("Error in setCurrentExecuteddetails :-"+e,new Throwable());
			e.printStackTrace();
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                e.printStackTrace();
                logger.error("SQL exception while closing resource : " + e);
                System.out.println("SQL exception while closing resource : " + e);
            }
        }
		logger.info("setCurrentExecuteddetails ends...");	  
		
	}
	
	public void updateLastExecuteddetails(String [] param)
	{
		ResultSet rs = null;
		Connection con = null;
		PreparedStatement pst = null;
		logger.info("updateLastExecuteddetails starts...");
		try
		{
			con = DBHelper.getInstance().getSourceConnection();
			String sql = "UPDATE EKUDOCS_DATA_TRACKER SET END_DATE=? WHERE START_DATE = (SELECT MAX(START_DATE) FROM EKUDOCS_DATA_TRACKER)";
			pst = con.prepareStatement(sql);
			int i=0;
			if(param.length>0)
    		{
    			logger.info("SQL query to be executed : "+sql +" with Parameters :-"+Arrays.toString(param));
		        while(i<param.length)
		        {
		        	pst.setString(i+1,param[i]);
		        	i++;
		        }
    		}
    		else
    		{
    			logger.info("SQL query to be executed : "+sql);
    		}			
			pst.executeUpdate();			
		}
		catch (Exception e) 
		{			
			logger.error("Error in updateLastExecuteddetails :-"+e,new Throwable());
			e.printStackTrace();
		}	
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                e.printStackTrace();
                logger.error("SQL exception while closing resource : " + e);
                System.out.println("SQL exception while closing resource : " + e);
            }
        }
		logger.info("updateLastExecuteddetails ends...");			
	}
	
	
	
	public static void main (String hg[]){
		
		SchedulerStatus schedulerStatus=new SchedulerStatus();
		
	}
		// TODO Auto-generated method stub

	
	
	
}