package com.max.report.action;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.InetSocketAddress;
import java.net.Proxy;
import java.net.URL;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.max.util.XTrustProvider;

public class StartAction {

	static Logger logger = Logger.getLogger(StartAction.class.getName());
    ResourceBundle res = ResourceBundle.getBundle("com.max.report.resources.ApplicationResource");
	@SuppressWarnings("unchecked")
	public static Map<String,Object> getGsonData(String jsonData)
	{
		JsonElement jsonElement=new JsonParser().parse(jsonData);
		Map<String,Object> data=new Gson().fromJson(jsonElement,Map.class);
		//System.out.println(data);			
		return data;
	}
	public void EkudocsService(){
		logger.info("EkudocsService starts...");
		String responseEkube="";
		String responseEkudocs="";
		
		try
		{
			logger.info("EkudocsService going to connect with Ekube URL starts...");
			responseEkube=runningBackgroundcallingEkubeService();
			logger.info("EkudocsService connected with Ekube URL with response..."+responseEkube);
			logger.info("Going to parse into JSON with response..."+responseEkube);
			//System.out.println("responseEkube : "+responseEkube);
			Map<String,Object> resultData = getGsonData(responseEkube);
			if(resultData!=null)
			{
				Map response = (Map)resultData.get("response");
				if(response!=null 
						&& response.containsKey("status") 
						&& response.containsKey("ekudos")
						)
				{
					String status = response.get("status").toString().trim();
					if(status.equalsIgnoreCase("1"))
					{
						List ekudosData = (List)response.get("ekudos");
						if(ekudosData!=null && ekudosData.size()>0)
						{
							for(int i=0; i<ekudosData.size();i++)
							{
								Map ekudos = (Map)ekudosData.get(i);
							//	String event_category = ekudos.get("category").toString();
								String event_Occured = ekudos.get("event_Occured").toString();
								String userId = ekudos.get("userId").toString();
								logger.debug("event_Occured : "+event_Occured + " :: userId : "+userId);
								responseEkudocs=runningBackgroundcallingEkudosService(event_Occured,userId,"abc");
								logger.debug("Getting Response from Ekudocs URL     "+responseEkudocs);
								
								
								//System.out.println("event_Occured : "+event_Occured + " :: userId : "+userId);
							}
						}
					}
				}
			}
			logger.info("Returning  parsed JSON data ..."+resultData);
		}
		catch(Exception ex)
		{
			logger.info("We are in exception : "+ex);
		}
		
		
		
		
	}
	public String runningBackgroundcallingEkubeService()
	{
		String output = new String();
		String param[]=null;
		StringBuilder result = new StringBuilder();	
		String DevMode = "N";
		HttpURLConnection conn = null;
		logger.info("runningBackgroundcallingEkubeService to connect with Ekube URL starts...");

        SchedulerStatus schedulerStatus = new SchedulerStatus();
		try 
		{
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String EkubeUrl = res.getString("Ekube");
			URL urlEkube = new URL(EkubeUrl);
			logger.info("runningBackgroundcallingEkubeService to connect with Ekube URL ..."+urlEkube);

			//String DevMode = env.getProperty("spring.enable.proxy.development");
			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				conn = (HttpURLConnection) urlEkube.openConnection(proxy);
			}
			else
			{
				conn = (HttpURLConnection) urlEkube.openConnection();
			}

			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			//			conn.setRequestMethod("GET");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder requestdata=new StringBuilder();
			String enddate="";
			String lastexecuteddate="";
			String listName=res.getString("listName");
			String userName=res.getString("userName");
			String userPass=res.getString("userPass");
			Date now = new Date();
			DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
			//DateFormat dfs = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss:S a");

			String currenttm = df.format(now);

			try{
//				lastexecuteddate="01/01/2017 05:53:09 AM";
				lastexecuteddate=schedulerStatus.getLastExecutedDetails(new String[0]);
				if("".equalsIgnoreCase(lastexecuteddate)){
					
					lastexecuteddate=""+currenttm;
					
					
				}
				
				
			}catch(Exception e){
				
				logger.error("Error in parshing date in  runningBackgroundcallingEkubeService  "+e);

			}
			
			
			
			requestdata.append("	{	");
		    requestdata.append("	\"startDate\": \""+lastexecuteddate+"\",	");
			requestdata.append("	\"endDate\": \""+currenttm+"\",	");
			requestdata.append("	\"listName\": \""+listName+"\",	");
			requestdata.append("	\"userName\": \""+userName+"\",	");
			requestdata.append("	\"userPass\": \""+userPass+"\"	");
			requestdata.append("	}	");
			
			
			logger.info("Going to connect to Ekube URL ..."+urlEkube+"  with request param   "+requestdata);

			param=new String[2];
			param[0]=currenttm;
			param[1]=lastexecuteddate;
			//param[2]=requestdata.toString();
			logger.info("Going to save current execution date into db with setCurrentExecuteddetails");
			schedulerStatus.setCurrentExecuteddetails(param);
			logger.info("setCurrentExecuteddetails finish");

			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}

			int apiResponseCode = conn.getResponseCode();
			//System.out.println(apiResponseCode);
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				///System.out.println(result.toString());
			}
		}catch(Exception ex)
		{
			logger.error("Error in execution runningBackgroundcallingEkubeService  "+ex);
		}	
		logger.info("runningBackgroundcallingEkubeService is successfilly finished with response  "+result.toString());

		return 	result.toString();
		
	}
	
	
	public String runningBackgroundcallingEkudosService(String eventOccured, String ssoId,String event_category){
	
		///  Now Going to Connect Ekudocs URL ///
		
		String output = new String();
		String param[]=null;
		StringBuilder result = new StringBuilder();	
		String DevMode = "N";
		HttpURLConnection connEkudocs = null;
        SchedulerStatus schedulerStatus = new SchedulerStatus();

			try{
				Date now = new Date();
				DateFormat df = new SimpleDateFormat("MM/dd/yyyy HH:mm:ss a");
				String currenttm = df.format(now);
				String EkudocsUrl = res.getString("Ekudosurl");
				URL UrlEkudocs = new URL(EkudocsUrl);
				StringBuilder requestdataEkudocs=new StringBuilder();

			if(DevMode!=null && !DevMode.equalsIgnoreCase("") && DevMode.equalsIgnoreCase("Y"))
			{
				Proxy proxy = new Proxy(Proxy.Type.HTTP, new InetSocketAddress("cachecluster.maxlifeinsurance.com", 3128));
				connEkudocs = (HttpURLConnection) UrlEkudocs.openConnection(proxy);
			}
			else
			{
				connEkudocs = (HttpURLConnection) UrlEkudocs.openConnection();
			}
			
			HttpsURLConnection.setFollowRedirects(true);
			connEkudocs.setDoInput(true);
			connEkudocs.setDoOutput(true);
			connEkudocs.setRequestMethod("POST");
			//			conn.setRequestMethod("GET");
			connEkudocs.setRequestProperty("Content-Type", "application/json");
			UUID uniqueId = UUID.randomUUID();

			requestdataEkudocs.append("	{	");
			requestdataEkudocs.append("	    \"header\": {	");
			requestdataEkudocs.append("	        \"soaMsgVersion\": \"1.0\",	");
			requestdataEkudocs.append("	        \"soaAppId\": \"eCube\",	");
			requestdataEkudocs.append("	        \"soaCorrelationId\":\""+uniqueId+"\"");
			requestdataEkudocs.append("	    },	");
			requestdataEkudocs.append("	    \"payload\": {	");
			requestdataEkudocs.append("	        \"transactions\": [	");
			requestdataEkudocs.append("	            {	");
			requestdataEkudocs.append("	                \"eventOccured\": \""+eventOccured+"\",	");
			requestdataEkudocs.append("	                \"createdDate\": \"\",	");
			requestdataEkudocs.append("	                \"eventName\": \"\",	");
			requestdataEkudocs.append("	                \"userName\": \""+ssoId+"\",	");
			requestdataEkudocs.append("	                \"title\": \"\",	");
			requestdataEkudocs.append("	                \"category\": \""+event_category+"\",	");
			requestdataEkudocs.append("	                \"appName\": \"Ecube\",	");
			requestdataEkudocs.append("	                \"appType\": \"mobileApp\",	");
			requestdataEkudocs.append("	                \"updated\": \"\"	");
			requestdataEkudocs.append("	            }	");
			requestdataEkudocs.append("	        ]	");
			requestdataEkudocs.append("	    }	");
			requestdataEkudocs.append("	}	");
			
			OutputStreamWriter writer = new OutputStreamWriter(connEkudocs.getOutputStream());
			writer.write(requestdataEkudocs.toString());
			writer.flush();
			try {writer.close(); } catch (Exception e1) {}

			int apiResponseCode = connEkudocs.getResponseCode();
			//System.out.println(apiResponseCode);
			
			if(apiResponseCode == 200)
			{
				param=new String[1];
				param[0]=currenttm;
				
				logger.info("Going to update current execution date into db with updateLastExecuteddetails");
				schedulerStatus.updateLastExecuteddetails(param);
				BufferedReader br = new BufferedReader(new InputStreamReader((connEkudocs.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				connEkudocs.disconnect();
				br.close();
				//System.out.println(result.toString());
			}
			
			

		}catch(Exception ex)
		{
			logger.error("We are in Exception for runningBackgroundcallingEkudosService" +ex);

			//System.out.println("Exception>>>>>>>>>>>>"+ex);
		}
			logger.info("runningBackgroundcallingEkubeService is successfilly finished with response  "+result.toString());

			return result.toString();
	}
	
	
	
	
	
	public static void main(String[] args) {
		
		StartAction startaction = new StartAction();
		startaction.EkudocsService();
		
		
	}

}
