package com.qc.example;

import java.io.FileOutputStream;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.qc.dto.CustomerDTO;
import com.qc.utils.HttpUrlConnection_GetDetails;

public class MainAction {
 
    Connection m_Connection = null;
    Statement m_Statement = null;
    ResultSet m_ResultSet = null;
    String m_Driver = "oracle.jdbc.driver.OracleDriver";
    String m_Url = "jdbc:oracle:thin:@172.23.51.195:1875:TPPSIT";
    String query = "";
    
    ResourceBundle res=ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");
    
    public MainAction() {
        //Load driver
        try {
            Class.forName(m_Driver);
        } catch (ClassNotFoundException ex) {
            ex.printStackTrace();
        }
    }
 
    public void doWork() {
        
        try {
            //Create connection object
            m_Connection = DriverManager.getConnection(m_Url, "TPPSIT", "tpp#sit");
 
            //Create Statement object
            m_Statement = m_Connection.createStatement();
            query = "SELECT * FROM Teams";
            //Execute the query
            m_ResultSet = m_Statement.executeQuery(query);
            //Loop through the results
            while (m_ResultSet.next()) {
            	
            	
                System.out.print(m_ResultSet.getString(1));
                System.out.print(", ");
                System.out.print(m_ResultSet.getString(2));
                System.out.print(", ");
                System.out.print(m_ResultSet.getString(3));
//                System.out.print("\n"); //new line
 
                
            }
        } catch (SQLException ex) {
            ex.printStackTrace();
            System.out.println(query);
        } finally {
            try {
                if (m_ResultSet != null) {
                    m_ResultSet.close();
                }
                if (m_Statement != null) {
                    m_Statement.close();
                }
                if (m_Connection != null) {
                    m_Connection.close();
                }
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
 
    public static void main(String[] args) {
    	MainAction dbTest = new MainAction();
//        dbTest.doWork();
    	HttpUrlConnection_GetDetails details=new HttpUrlConnection_GetDetails();
    	
    	CustomerDTO result=dbTest.getAllCustomers();
        
//        String getdetailresult = details.getUserDetail(result);
        
//        dbTest.generateReport1(result);
    }
    //
	public CustomerDTO getAllCustomers() 
    {
		
//        ArrayList<CustomerDTO> customers = new ArrayList<CustomerDTO>();
        CustomerDTO customer = new CustomerDTO();
        ResultSet rs = null;
        try {
        	  m_Connection = DriverManager.getConnection(m_Url, "TPPSIT", "tpp#sit");
        	  
              //Create Statement object
              m_Statement = m_Connection.createStatement();
              query = "SELECT * FROM Teams";
              
              rs = m_Statement.executeQuery(query);
            

            while (rs.next()) {
            	customer.setTeamId(rs.getString("TEAMID"));
            	customer.setTeamName(rs.getString("TEAMNAME"));
                customer.setParent_Team_Id(rs.getString("PARENT_TEAM_ID"));
                customer.setLast_update_id(rs.getString("LST_UPDT_USRID"));
                customer.setLast_update_date(rs.getString("LST_UPDT_DTM"));
            }

            rs.close();
        } catch (Exception e) {
            System.out.println(e);
        }

        return customer;
    }
	public  void generateReport1(List<List<String>> data)
	{

		ResourceBundle res2=ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");

		FileOutputStream out;
		try
		{
			//generateExcel("sheet", wb, data);
			StringBuffer sb = new StringBuffer();
			//sb.append("File path").append("File name").append("Mobile").append("Email").append("Address").append("Protected");
			out= new FileOutputStream(res2.getString("com.max.report.filePath"));
			for(List<String> list : data)
			{
				for(String str : list)
				{
					sb.append(str+"\t");

				}
				sb.append("\n");

			}
			byte[] b=sb.toString().getBytes();
			out.write(b);
			out.flush();
			out.close();
		}
		catch (Exception e) 
		{
			e.printStackTrace();
			//System.out.println("\n\t exception "+e);
		}
	
		
	}

}