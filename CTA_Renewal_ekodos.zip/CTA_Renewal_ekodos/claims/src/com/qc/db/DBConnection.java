package com.qc.db;

import java.sql.Connection;
import java.sql.DriverManager;

public class DBConnection {

	private static Connection con;
	private static String url = "jdbc:oracle:thin:@172.23.51.195:1875:TPPSIT";
	private static String driverName = "oracle.jdbc.driver.OracleDriver"; 
	private static String username="TPPSIT";
	private static String password="tpp#sit";
	
	public static Connection getConnection()
	{
		try {
			Class.forName(driverName);
			
			try {
				con=DriverManager.getConnection(url,username,password);
			} catch (Exception e)
			{
				System.out.println("Failed to create the database connection"+e);
			}
			
		} catch (Exception e) {
			System.out.println("Driver not found"); 
		}
		return con;
	}
}
