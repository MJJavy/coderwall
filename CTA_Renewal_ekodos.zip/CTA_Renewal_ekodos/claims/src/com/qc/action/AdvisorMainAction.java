package com.qc.action;

import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.qc.dto.AgencyBean;
import com.qc.dto.ClaimBean;
import com.qc.utils.HttpUrlConnection_GetAdvisor;
import com.qc.utils.HttpUrlConnection_GetDetails;
import com.qc.utils.HttpUrlConnection_GetMedical;

public class AdvisorMainAction {

	static Logger logger = Logger.getLogger(AdvisorMainAction.class.getName());
	ResourceBundle res = ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");
	 
	 @SuppressWarnings("unchecked")
		public static Map<String,Object> getGsonData(String jsonData)
		{
			JsonElement jsonElement=new JsonParser().parse(jsonData);
			Map<String,Object> data=new Gson().fromJson(jsonElement,Map.class);
			//System.out.println(data);			
			return data;
		}
	 
	public void advisorService(){
		
		logger.info("advisorService starts...");
		String response="";

		try {
			logger.info("advisorService going to connect with URL starts...");
			response=runningBackgroundcallingadvisorService();
			logger.info("advisorService connected with URL with response..."+response);
			logger.info("Going to parse into JSON with response..."+response);
			
			Map<String,Object> resultData = getGsonData(response);
			
			if(resultData!=null)
			{
				Map res = (Map)resultData.get("response");
				
			}
		} catch (Exception e) {
			// TODO: handle exception
		}
	}
	public String runningBackgroundcallingadvisorService()
	{
		AgencyBean bean=null;
		String claimData="";
		
		logger.info("runningBackgroundcallingadvisorService to connect with URL starts...");
		
		AdvisorDataStatus status = new AdvisorDataStatus();
		try {
//			String enddate="";
//			String lastexecuteddate="";
//			String Policy_No=res.getString("Policy_No");
//			String CHANNEL=res.getString("CHANNEL");
//			String ZONE=res.getString("ZONE");
			
			bean=status.fromDB(new String[0]);
			
			HttpUrlConnection_GetAdvisor details=new HttpUrlConnection_GetAdvisor();
			claimData=details.pushToAPI(bean);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		
		return claimData.toString();
	}
	
	public static void main(String[] args) {
		AdvisorMainAction startaction = new AdvisorMainAction();
		startaction.advisorService();
	}
}
