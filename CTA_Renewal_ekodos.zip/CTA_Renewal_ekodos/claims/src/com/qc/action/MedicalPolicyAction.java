package com.qc.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import com.qc.db.DBConnection;
import com.qc.dto.ClaimBean;
import com.qc.dto.MedicalBean;
import com.qc.utils.HttpUrlConnection_GetMedical;

public class MedicalPolicyAction {

	ResourceBundle res = ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");
	Connection con = null;
	Statement st = null;
	String query = "";
	public static void main(String[] args) {
		
		MedicalPolicyAction action=new MedicalPolicyAction();
		HttpUrlConnection_GetMedical medical=new HttpUrlConnection_GetMedical();
		
		
	}
	public MedicalBean getMedicalDetails() 
    {
		
		MedicalBean bean = new MedicalBean();
        ResultSet rs = null;
        try {

        	con=DBConnection.getConnection();
        	st = con.createStatement();
              query = "SELECT * FROM Teams";
              
              rs = st.executeQuery(query);
            

            while (rs.next()) {
            	bean.setgO_Code(rs.getString("gO_Code"));
            	bean.setPolicy_Number(rs.getString("policy_Number"));
            	bean.setDispatched_Date(rs.getString("dispatched_Date"));
            	bean.setDispatch_Mode(rs.getString("dispatch_Mode"));
            	bean.setPacket_Status(rs.getString("packet_Status"));
            	bean.setDelivery_Date(rs.getString("delivery_Date"));
            	bean.setIssue_Date(rs.getString("issue_Date"));
            	bean.setCustomer_Sign_Date(rs.getString("customer_Sign_Date"));
            	bean.setInforce_Date(rs.getString("inforce_Date"));
            	bean.setCustomer_ID(rs.getString("customer_ID"));
            	bean.setName_of_Purchased(rs.getString("name_of_Purchased"));
            	bean.setTenure(rs.getString("tenure"));
            	bean.setAnnual_Premium_Paid_Policy(rs.getString("annual_Premium_Paid_Policy"));
            	bean.setFreequency_of_Premium_Paid(rs.getString("freequency_of_Premium_Paid"));
            	bean.setuLIP_Non_ULIP(rs.getString("uLIP_Non_ULIP"));
            	bean.setChannel_of_Purchase(rs.getString("channel_of_Purchase"));
            	bean.setAge_of_Insured(rs.getString("age_of_Insured"));
            	bean.setcAT_Yes_No(rs.getString("cAT_Yes_No"));
            	bean.setPolicy_Type(rs.getString("policy_Type"));
            	bean.setzONE_NAME(rs.getString("zONE_NAME"));
            	bean.setWriting_Agent_Status(rs.getString("writing_Agent_ID"));
            	bean.setWriting_Agent_Status(rs.getString("writing_Agent_Status"));
            	bean.setServicing_Agent_ID(rs.getString("servicing_Agent_ID"));
            	bean.setServicing_Agent_Status(rs.getString("servicing_Agent_Status"));
            	bean.setAgent_Segment(rs.getString("agent_Segment"));
            	bean.setdCS(rs.getString("dCS"));
            	bean.setMed_Non_Med_cases(rs.getString("med_Non_Med_cases"));
            	bean.setReason_for_Counter_Offer(rs.getString("reason_for_Counter_Offer"));
            }

            rs.close();
        } catch (Exception e) {
            System.out.println(e);
        }

        return bean;
    }

}
