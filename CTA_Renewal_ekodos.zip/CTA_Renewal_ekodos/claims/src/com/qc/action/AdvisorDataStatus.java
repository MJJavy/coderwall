package com.qc.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.qc.db.DBConnection;
import com.qc.dto.AgencyBean;
import com.qc.dto.ClaimBean;


public class AdvisorDataStatus {
	
	static Logger logger = Logger.getLogger(AdvisorDataStatus.class.getName());
	public AgencyBean fromDB(String [] param)
	{
		logger.info("getfromDB Starts...");
		
		AgencyBean agency = new AgencyBean();
	
		Connection con = null;
		PreparedStatement pst = null;
	    ResultSet rs = null;
	    String sql = "";
		try {
			con=DBConnection.getConnection();
			sql = "SELECT * FROM Teams";
			pst = con.prepareStatement(sql);
			
			int i=0;
			if(param.length>0)
    		{
    			logger.info("SQL query to be executed : "+sql +" with Parameters :-"+Arrays.toString(param));
		        while(i<param.length)
		        {
		        	pst.setString(i+1,param[i]);
		        	i++;
		        }
    		}
    		else
    		{
    			logger.info("SQL query to be executed : "+sql);
    		}		
			logger.info("Executing query for getfromDB");
			rs = pst.executeQuery();
			if(rs!=null)
			{
				while (rs.next()) 
                {
	            	agency.setPolIdKey((rs.getString("POL_ID_KEY")==null)?"":rs.toString());
	            	agency.setPolicyStatus((rs.getString("POLICY_STATUS")==null)?"":rs.toString());
	            	agency.setIssueDate((rs.getString("ISSUE_DATE")==null)?"":rs.toString());
	            	agency.setInforceDate((rs.getString("INFORCE_DATE")==null)?"":rs.toString());
	            	agency.setCustomerId((rs.getString("CUSTOMER_ID")==null)?"":rs.toString());
	            	agency.setWrAgtName((rs.getString("OWNERID_KEY")==null)?"":rs.toString());
	            	agency.setPlanId((rs.getString("PLAN_ID")==null)?"":rs.toString());
	            	agency.setPlanName((rs.getString("PLAN_NAME")==null)?"":rs.toString());
	            	agency.setPolicyTenure((rs.getString("POLICY_TENURE")==null)?"":rs.toString());
	            	agency.setFrequencyPremiumPaid((rs.getString("FREQUENCY_OF_PREMIUM_PAID")==null)?"":rs.toString());
	            	agency.setPolicyType((rs.getString("POLICY_TYPE")==null)?"":rs.toString());
	            	agency.setChannel((rs.getString("CHANNEL")==null)?"":rs.toString());
	            	agency.setAnnualPremium((rs.getString("ANNUAL_PREMIUM")==null)?"":rs.toString());
	            	agency.setTotalPremiumPaid((rs.getString("TOTAL_PREMIUM_PAID")==null)?"":rs.toString());
	            	agency.setModalPremium((rs.getString("MODAL_PREMIUM")==null)?"":rs.toString());
	            	agency.setGoCodes((rs.getString("GO_CODES")==null)?"":rs.toString());
	            	agency.setWrAgtId((rs.getString("WR_AGT_ID")==null)?"":rs.toString());
	            	agency.setWrAgtName((rs.getString("WR_AGT_NAME")==null)?"":rs.toString());
	            	agency.setCategory((rs.getString("Category")==null)?"":rs.toString());
	            	agency.setServAgtId((rs.getString("SERV_AGT_ID")==null)?"":rs.toString());
	            	agency.setServAgentName((rs.getString("SERV_AGENT_NAME")==null)?"":rs.toString());
	            	agency.setServBrId((rs.getString("SERV_BR_ID")==null)?"":rs.toString());
	            	agency.setHniFlag((rs.getString("HNI_FLAG")==null)?"":rs.toString());
	            	agency.setCatFlag((rs.getString("CAT_FLAG")==null)?"":rs.toString());
	            	agency.setCustomerName((rs.getString("CUSTOMER_NAME")==null)?"":rs.toString());
	            	agency.setLadnlineNumber((rs.getString("LADNLINE_NUMBER")==null)?"":rs.toString());
	            	agency.setContactNo((rs.getString("CONTACT_NUMBER")==null)?"":rs.toString());
	            	agency.setMobileNo((rs.getString("MOBILE_NUMBER")==null)?"":rs.toString());
	            	agency.setInstrumentSeqNo((rs.getString("INSTRUMENT_SEQ_NO")==null)?"":rs.toString());
	            	agency.setLocationCode((rs.getString("LOCATION_CODE")==null)?"":rs.toString());
	            	agency.setStrinstrtypecd((rs.getString("STRINSTRTYPECD")==null)?"":rs.toString());
	            	agency.setInstrumentType((rs.getString("INSTRUMENT_TYPE")==null)?"":rs.toString());
	            	agency.setInstrumentCategory((rs.getString("INSTRUMENT_CATEGORY")==null)?"":rs.toString());
	            	agency.setDtreceipt((rs.getString("DTRECEIPT")==null)?"":rs.toString());
	            	agency.setDtinstr((rs.getString("DTINSTR")==null)?"":rs.toString());
	            	agency.setStrinstrnbr((rs.getString("STRINSTRNBR")==null)?"":rs.toString());
	            	agency.setDtcreated((rs.getString("DTCREATED")==null)?"":rs.toString());
	            	agency.setDtstub((rs.getString("DTSTUB")==null)?"":rs.toString());
	            	agency.setInstrumentAmount((rs.getString("INSTRUMENT_AMOUNT")==null)?"":rs.toString());
	            }    	
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                e.printStackTrace();
                logger.error("SQL exception while closing resource : " + e);
                System.out.println("SQL exception while closing resource : " + e);
            }
        }
		logger.info("getLastExecutedDetails ends...");
		return agency;
	}
}
