package com.qc.action;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.ResourceBundle;

import com.qc.dto.AgencyBean;
import com.qc.dto.CustomerDTO;
import com.qc.example.MainAction;
import com.qc.utils.HttpUrlConnection_GetDetails;

public class AdvisorAction {
	
	Connection c = null;
    Statement st = null;
    ResultSet rs = null;
    String driver = "oracle.jdbc.driver.OracleDriver";
    String url = "jdbc:oracle:thin:@172.23.51.195:1875:TPPSIT";
    String query = "";
    
    ResourceBundle res = ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");
    
    
	public static void main(String[] args) {
		AdvisorAction test = new AdvisorAction();
		HttpUrlConnection_GetDetails details=new HttpUrlConnection_GetDetails();
//	
//    	List all_listAdvisor=test.getAllAdvisor();
//    	String getdetailresult = details.getUserDetail(all_listAdvisor);
    	
    		
	}
	
	public AgencyBean getAllAdvisor() 
    {
		
//        ArrayList<AgencyAdvior> advisor = new ArrayList<AgencyAdvior>();
        AgencyBean agency = new AgencyBean();
        ResultSet rs = null;
        try {
        	  c = DriverManager.getConnection(url, "TPPSIT", "tpp#sit");
        	  
              //Create Statement object
              st = c.createStatement();
              query = "SELECT * FROM Teams";
              
              rs = st.executeQuery(query);
            

            while (rs.next()) {
            	agency.setPolIdKey(rs.getString("POL_ID_KEY"));
            	agency.setPolicyStatus(rs.getString("POLICY_STATUS"));
            	agency.setIssueDate(rs.getString("ISSUE_DATE"));
            	agency.setIssueDate(rs.getString("INFORCE_DATE"));
            	agency.setCustomerId(rs.getString("CUSTOMER_ID"));
            	agency.setWrAgtName(rs.getString("OWNERID_KEY"));
            	agency.setPlanId(rs.getString("PLAN_ID"));
            	agency.setPlanName(rs.getString("PLAN_NAME"));
            	agency.setPolicyTenure(rs.getString("POLICY_TENURE"));
            	agency.setFrequencyPremiumPaid(rs.getString("FREQUENCY_OF_PREMIUM_PAID"));
            	agency.setPolicyType(rs.getString("POLICY_TYPE"));
            	agency.setChannel(rs.getString("CHANNEL"));
            	agency.setAnnualPremium(rs.getString("ANNUAL_PREMIUM"));
            	agency.setTotalPremiumPaid(rs.getString("TOTAL_PREMIUM_PAID"));
            	agency.setModalPremium(rs.getString("MODAL_PREMIUM"));
            	agency.setGoCodes(rs.getString("GO_CODES"));
            	agency.setWrAgtId(rs.getString("WR_AGT_ID"));
            	agency.setWrAgtName(rs.getString("WR_AGT_NAME"));
            	agency.setCategory(rs.getString("Category"));
            	agency.setServAgtId(rs.getString("SERV_AGT_ID"));
            	agency.setServAgentName(rs.getString("SERV_AGENT_NAME"));
            	agency.setServBrId(rs.getString("SERV_BR_ID"));
            	agency.setHniFlag(rs.getString("HNI_FLAG"));
            	agency.setCatFlag(rs.getString("CAT_FLAG"));
            	agency.setCustomerName(rs.getString("CUSTOMER_NAME"));
            	agency.setLadnlineNumber(rs.getString("LADNLINE_NUMBER"));
            	agency.setContactNo(rs.getString("CONTACT_NUMBER"));
            	agency.setMobileNo(rs.getString("MOBILE_NUMBER"));
            	agency.setInstrumentSeqNo(rs.getString("INSTRUMENT_SEQ_NO"));
            	agency.setLocationCode(rs.getString("LOCATION_CODE"));
            	agency.setStrinstrtypecd(rs.getString("STRINSTRTYPECD"));
            	agency.setInstrumentType(rs.getString("INSTRUMENT_TYPE"));
            	agency.setInstrumentCategory(rs.getString("INSTRUMENT_CATEGORY"));
            	agency.setDtreceipt(rs.getString("DTRECEIPT"));
            	agency.setDtinstr(rs.getString("DTINSTR"));
            	agency.setStrinstrnbr(rs.getString("STRINSTRNBR"));
            	agency.setDtcreated(rs.getString("DTCREATED"));
            	agency.setDtstub(rs.getString("DTSTUB"));
            	agency.setInstrumentAmount(rs.getString("INSTRUMENT_AMOUNT"));

            }

            rs.close();
        } catch (Exception e) {
            System.out.println(e);
        }

        return agency;
    }	
}
