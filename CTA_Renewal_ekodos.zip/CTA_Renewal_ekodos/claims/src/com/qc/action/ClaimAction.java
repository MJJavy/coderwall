package com.qc.action;

import java.sql.Connection;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.qc.dto.AgencyBean;
import com.qc.dto.ClaimBean;
import com.qc.utils.HttpUrlConnection_GetDetails;

public class ClaimAction {
	
	Connection c = null;
    Statement st = null;
    ResultSet rs = null;
    String driver = "oracle.jdbc.driver.OracleDriver";
    String url = "jdbc:oracle:thin:@172.23.51.195:1875:TPPSIT";
    String query = "";
    static ClaimAction action =null;
    static Logger logger = Logger.getLogger(ClaimAction.class.getName());
    
    ResourceBundle res = ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");

	public static void main(String[] args)
	{
		new ClaimAction();
		
		action.claimService();
		
//		ClaimBean otp=action.getClaimDetails();
//		HttpUrlConnection_GetDetails details=new HttpUrlConnection_GetDetails();
//		String getdetailresult = details.pushToAPI(otp);
		
	}
	
	public ClaimBean getClaimDetails() 
    {
		logger.info("getClaimDetails starts...");
		
		ClaimBean bean = new ClaimBean();
        ResultSet rs = null;
        try {
        	  c = DriverManager.getConnection(url, "TPPSIT", "tpp#sit");
        	  
              //Create Statement object
              st = c.createStatement();
              
              logger.info("Query starts...");
              query = "SELECT * FROM Teams";
              
              rs = st.executeQuery(query);
              
              logger.info("Query End...");
              
            while (rs.next()) {
            	
            	bean.setS_no(rs.getString("S_NO"));
            	bean.setStage(rs.getString("Stage"));
            	bean.setPolicy_no(rs.getString("Policy_No"));
            	bean.setLife_insured(rs.getString("Life_Insured"));
            	bean.setDate_of_death(rs.getString("Date_of_Death"));
            	bean.setDate_of_intimation_go(rs.getString("Date_of_Intimation_GO"));
            	bean.setTotal_claim_amount(rs.getString("Total_Claim_Amount"));
            	bean.setSettlement_date(rs.getString("Settlement_Date"));
            	bean.setClaimant(rs.getString("Claimant"));
            	bean.setEarly_non_early(rs.getString("Early_Non_Early"));
            	bean.setDeceased_client_id(rs.getString("Deceaseds_Client_ID"));
            	bean.setEffective_date(rs.getString("Effective_Date"));
            	bean.setService_go_code(rs.getString("Service_Go_Code"));
            	bean.setClaimants_no(rs.getString("CLAIMANTS_NO"));
            	bean.setLas_state(rs.getString("LAS_STATE"));
            	bean.setCause_of_event(rs.getString("Cause_of_Event"));
            	bean.setChannell(rs.getString("CHANNEL"));
            	bean.setZone(rs.getString("ZONE"));
            	bean.setAgent_status(rs.getString("AGENT_STATUS"));
            	bean.setEti_reduced_paid_up_cases(rs.getString("ETI_Reduced_paid_up_cases"));
            	
            	
            }

            rs.close();
        } catch (Exception e) {
            System.out.println(e);
        }
        logger.info("getClaimDetails End...");
        
        return bean;
    }	
	
	public void claimService()
	{
		logger.info("claimService starts...");
		new ClaimAction();
		ClaimBean bean=action.getClaimDetails();
		HttpUrlConnection_GetDetails details=new HttpUrlConnection_GetDetails();
//		String getdetailresult = details.pushToAPI(bean);
		logger.info("claimService end...");
	}
}
