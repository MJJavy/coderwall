package com.qc.action;

import java.io.File;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonParser;
import com.qc.dto.ClaimBean;
import com.qc.utils.HttpUrlConnection_GetDetails;

public class MainAction {

	static Logger logger = Logger.getLogger(MainAction.class.getName());
	ResourceBundle res = ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");
	HttpUrlConnection_GetDetails details=new HttpUrlConnection_GetDetails();
	 @SuppressWarnings("unchecked")
		public static Map<String,Object> getGsonData(String jsonData)
		{
			JsonElement jsonElement=new JsonParser().parse(jsonData);
			Map<String,Object> data=new Gson().fromJson(jsonElement,Map.class);
			//System.out.println(data);			
			return data;
		}
	 
	public void claimService(){
		
		logger.info("claimService starts...");
		String responseClaim="";
		
		List list = null;
		String claimData="";
		ClaimBean claimBean = null;
		try {
			list = readExcel();
			for (int i = 0; i < list.size(); i++) {
				claimBean = (ClaimBean) list.get(0);
				claimData=details.pushToAPI(list);
			}	
		} catch (Exception e) 
		{
			logger.info("creating exception in startSparcWork" + e);
		}
	}
	
	public List readExcel() {
		logger.info("readExcel() method starts..... ");
		String path = res.getString("filepath");
		String filename = res.getString("filename");
		ArrayList list = null;
		ClaimBean claimBean = null;
		ArrayList listData = null;
		try {
			List excelData = new ExcellTool().loadListFromValidExcel(path + File.separator + filename);
			if (excelData != null && !excelData.isEmpty()) {
				listData = new ArrayList();
				for (int i = 1; i < excelData.size(); i++) {
					int k = 0;
					claimBean = new ClaimBean();
					list = (ArrayList<String>) excelData.get(i);

					if (list != null && !list.isEmpty()) {
						claimBean.setS_no(nullThenBlank(list.get(k++).toString()));
						claimBean.setStage(nullThenBlank(list.get(k++).toString()));
						claimBean.setPolicy_no(nullThenBlank(list.get(k++).toString()));
						claimBean.setLife_insured(nullThenBlank(list.get(k++).toString()));
						claimBean.setDate_of_death(nullThenBlank(list.get(k++).toString()));
						claimBean.setDate_of_intimation_go(nullThenBlank(list.get(k++).toString()));
						claimBean.setTotal_claim_amount(nullThenBlank(list.get(k++).toString()));
						claimBean.setSettlement_date(nullThenBlank(list.get(k++).toString()));
						claimBean.setClaimant(nullThenBlank(list.get(k++).toString()));
						claimBean.setEarly_non_early(nullThenBlank(list.get(k++).toString()));
						claimBean.setDeceased_client_id(nullThenBlank(list.get(k++).toString()));
						claimBean.setEffective_date(nullThenBlank(list.get(k++).toString()));
						claimBean.setService_go_code(nullThenBlank(list.get(k++).toString()));
						claimBean.setClaimants_no(nullThenBlank(list.get(k++).toString()));
						claimBean.setLas_state(nullThenBlank(list.get(k++).toString()));
						claimBean.setCause_of_event(nullThenBlank(list.get(k++).toString()));
						claimBean.setChannell(nullThenBlank(list.get(k++).toString()));
						claimBean.setZone(nullThenBlank(list.get(k++).toString()));
						claimBean.setAgent_status(nullThenBlank(list.get(k++).toString()));
						claimBean.setEti_reduced_paid_up_cases(nullThenBlank(list.get(k++).toString()));
						}
						listData.add(claimBean);
					}
				
			} else {
				logger.info("Excel is cooming blank");
			}
		} catch (Exception e) {
			logger.info("creating exception in readExcel " + e);
		}
		logger.info("readExcel() method end..... ");
		return listData;
	}
	
	public String nullThenBlank(String value) {
		String data = "";
		try {
			if (null != value) {
				data = value;
			}
		} catch (Exception e) {
			logger.info("creating excepiton in nullThenBlank " + e);
		}
		return data;
	}
	
	
	
	public static void main(String[] args) {
		MainAction startaction = new MainAction();
		startaction.claimService();
	}
}
