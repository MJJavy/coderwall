package com.qc.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.Arrays;
import java.util.ResourceBundle;

import org.apache.log4j.Logger;

import com.qc.db.DBConnection;
import com.qc.dto.ClaimBean;


public class DataStatus {
	
	static Logger logger = Logger.getLogger(DataStatus.class.getName());
	public ClaimBean fromDB(String [] param)
	{
		logger.info("getfromDB Starts...");
		
		ClaimBean bean = new ClaimBean();
	
		Connection con = null;
		PreparedStatement pst = null;
	    ResultSet rs = null;
	    String sql = "";
		try {
			con=DBConnection.getConnection();
			sql = "SELECT * FROM Teams";
			pst = con.prepareStatement(sql);
			
			int i=0;
			if(param.length>0)
    		{
    			logger.info("SQL query to be executed : "+sql +" with Parameters :-"+Arrays.toString(param));
		        while(i<param.length)
		        {
		        	pst.setString(i+1,param[i]);
		        	i++;
		        }
    		}
    		else
    		{
    			logger.info("SQL query to be executed : "+sql);
    		}		
			logger.info("Executing query for getfromDB");
			rs = pst.executeQuery();
			if(rs!=null)
			{
				while (rs.next()) 
                {                	
//					enddate= rs.getString("end_date");   
					bean.setS_no(rs.getString("S_NO"));
	            	bean.setStage(rs.getString("Stage"));
	            	bean.setPolicy_no(rs.getString("Policy_No"));
	            	bean.setLife_insured(rs.getString("Life_Insured"));
	            	bean.setDate_of_death(rs.getString("Date_of_Death"));
	            	bean.setDate_of_intimation_go(rs.getString("Date_of_Intimation_GO"));
	            	bean.setTotal_claim_amount(rs.getString("Total_Claim_Amount"));
	            	bean.setSettlement_date(rs.getString("Settlement_Date"));
	            	bean.setClaimant(rs.getString("Claimant"));
	            	bean.setEarly_non_early(rs.getString("Early_Non_Early"));
	            	bean.setDeceased_client_id(rs.getString("Deceaseds_Client_ID"));
	            	bean.setEffective_date(rs.getString("Effective_Date"));
	            	bean.setService_go_code(rs.getString("Service_Go_Code"));
	            	bean.setClaimants_no(rs.getString("CLAIMANTS_NO"));
	            	bean.setLas_state(rs.getString("LAS_STATE"));
	            	bean.setCause_of_event(rs.getString("Cause_of_Event"));
	            	bean.setChannell(rs.getString("CHANNEL"));
	            	bean.setZone(rs.getString("ZONE"));
	            	bean.setAgent_status(rs.getString("AGENT_STATUS"));
	            	bean.setEti_reduced_paid_up_cases(rs.getString("ETI_Reduced_paid_up_cases"));
                }    	
			}
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		finally 
        {
            try 
            {
                if (rs != null) 
                {
                    rs.close();
                }
                if (pst != null) 
                {
                	pst.close();
                }
                if (con != null) 
                {
                    con.close();
                }
            }
            catch (Exception e) 
            {
                e.printStackTrace();
                logger.error("SQL exception while closing resource : " + e);
                System.out.println("SQL exception while closing resource : " + e);
            }
        }
		logger.info("getLastExecutedDetails ends...");
		return bean;
	}
}
