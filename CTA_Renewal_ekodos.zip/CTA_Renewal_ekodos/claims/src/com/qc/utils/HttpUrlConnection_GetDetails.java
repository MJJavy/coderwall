package com.qc.utils;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.lang.reflect.Field;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.ResourceBundle;
import java.util.Set;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;
import com.fasterxml.jackson.core.JsonGenerationException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.qc.dto.ClaimBean;



public class HttpUrlConnection_GetDetails 
{
	private static Logger logger = LogManager.getLogger(HttpUrlConnection_GetDetails.class);
	
	
	
	public String pushToAPI(List claimBean)
	{
		//logger.info("START :- Inside : - pushToAPI :- "+data);
		ResourceBundle res = ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");
		HttpURLConnection conn = null;
		StringBuilder result = new StringBuilder();
		String output = ""; 
		
//		String[] array = new String[data.size()];
//		int index = 0;
		try
		{
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			StringBuilder requestdata=new StringBuilder();
			
			
			
//			/ output
			for (Object value : claimBean) {
				
			
					String firstAddress=value + "" ;
				 	ObjectMapper mapper = new ObjectMapper();
				      
				 	try {
						// Convert object to JSON string and save into a file directly
						mapper.writeValue(new File("D:\\claimbean.json"), firstAddress);

						// Convert object to JSON string
						String jsonInString = mapper.writeValueAsString(firstAddress);
						System.out.println(jsonInString);

						// Convert object to JSON string and pretty print
						jsonInString = mapper.writerWithDefaultPrettyPrinter().writeValueAsString(firstAddress);
						System.out.println(jsonInString);

					} catch (JsonGenerationException e) {
						e.printStackTrace();
					} catch (JsonMappingException e) {
						e.printStackTrace();
					} catch (IOException e) {
						e.printStackTrace();
					}
				 	
//				  index++;	
			}
			
//			UUID uniqueId = UUID.randomUUID();
//			requestdata.append("	{	");
//			requestdata.append("	    \"S_NO\": \""+claimBean.getS_no()+"\",	");
//		    requestdata.append("	    \"Stage\": \""+claimBean.getStage()+"\",	");
//			requestdata.append("	    \"Policy_No\": \""+data.getPolicy_no()+"\",	");
//			requestdata.append("	    \"Life_Insured\": \""+data.getLife_insured()+"\",	");
//			requestdata.append("	    \"Date_of_Death\": \""+data.getDate_of_death()+"\",	");
//			requestdata.append("	    \"Date_of_Intimation_GO\": \""+data.getDate_of_intimation_go()+"\",	");
//			requestdata.append("	    \"Total_Claim_Amount\": \""+data.getTotal_claim_amount()+"\",	");
//			requestdata.append("	    \"Settlement_Date\": \""+data.getSettlement_date()+"\",	");
//			requestdata.append("	    \"Claimant\": \""+data.getClaimant()+"\",	");
//			requestdata.append("	    \"Early_Non_Early\": \""+data.getEarly_non_early()+"\",	");
//			requestdata.append("	    \"Deceaseds_Client_ID\": \""+data.getDeceased_client_id()+"\",	");
//			requestdata.append("	    \"Effective_Date\": \""+data.getEffective_date()+"\",	");
//			requestdata.append("	    \"Service_Go_Code\": \""+data.getService_go_code()+"\",	");
//			requestdata.append("	    \"CLAIMANTS_NO\": \""+data.getClaimants_no()+"\",	");
//			requestdata.append("	    \"LAS_STATE\": \""+data.getLas_state()+"\",	");
//			requestdata.append("	    \"Cause_of_Event\": \""+data.getCause_of_event()+"\",	");
//			requestdata.append("	    \"CHANNEL\": \""+data.getChannell()+"\",	");
//			requestdata.append("	    \"ZONE\": \""+data.getZone()+"\",	");
//			requestdata.append("	    \"AGENT_STATUS\": \""+data.getAgent_status()+"\",	");
//			requestdata.append("	    \"ETI_Reduced_paid_up_cases\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
			requestdata.append("	  },	");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {writer.close(); } 
			catch (Exception e1) 
			{
				logger.info(e1);
			}

			int apiResponseCode = conn.getResponseCode();
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
				logger.info("External API Call : END : pushToAPI : claim Details");

			}
			else
			{
				logger.info("Unable to connect External API");
			}
		}
		catch(Exception e)
		{
			logger.info("Exception Occoured While Calling pushToAPI"+e);
		}
//		logger.info("END :- OutSide : - pushToAPI :- "+data);
		return result.toString();
	}
}
