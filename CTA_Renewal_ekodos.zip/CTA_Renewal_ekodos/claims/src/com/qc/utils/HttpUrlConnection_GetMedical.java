package com.qc.utils;

import java.io.BufferedReader;

import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;
import java.util.UUID;

import javax.net.ssl.HttpsURLConnection;

import com.qc.dto.ClaimBean;
import com.qc.dto.CustomerDTO;
import com.qc.dto.MedicalBean;


public class HttpUrlConnection_GetMedical 
{
//	private static Logger logger = LogManager.getLogger(HttpUrlConnection_GetDetails.class);
	
	
	
	public String getHttpClaimDetail(MedicalBean data)
	{
//		logger.info("START :- Inside : - getUserDetail :- SSOID:- "+ssoId);
		ResourceBundle res = ResourceBundle.getBundle("com.qc.report.resources.ApplicationResources");
		HttpURLConnection conn = null;
		StringBuilder result = new StringBuilder();
		String output = ""; 
		try
		{
			XTrustProvider trustProvider=new XTrustProvider();
			trustProvider.install();
			String serviceurl = res.getString("servicegetUserDetail");
			URL url = new URL(serviceurl);
			conn = (HttpURLConnection) url.openConnection();
			HttpsURLConnection.setFollowRedirects(true);
			conn.setDoInput(true);
			conn.setDoOutput(true);
			conn.setRequestMethod("POST");
			conn.setRequestProperty("Content-Type", "application/json");
			StringBuilder requestdata=new StringBuilder();
			UUID uniqueId = UUID.randomUUID();
			requestdata.append("	{	");
			requestdata.append("	    \"gO_Code\": \""+data.getgO_Code()+"\",	");
			requestdata.append("	    \"policy_Number\": \""+data.getPolicy_Number()+"\",	");
			requestdata.append("	    \"dispatched_Date\": \""+data.getDispatched_Date()+"\",	");
			requestdata.append("	    \"dispatch_Mode\": \""+data.getDispatch_Mode()+"\",	");
			requestdata.append("	    \"packet_Status\": \""+data.getPacket_Status()+"\",	");
			requestdata.append("	    \"delivery_Date\": \""+data.getDelivery_Date()+"\",	");
			requestdata.append("	    \"issue_Date\": \""+data.getIssue_Date()+"\",	");
			requestdata.append("	    \"customer_Sign_Date\": \""+data.getCustomer_Sign_Date()+"\",	");
			requestdata.append("	    \"inforce_Date\": \""+data.getInforce_Date()+"\",	");
			requestdata.append("	    \"customer_ID\": \""+data.getCustomer_ID()+"\",	");
//			requestdata.append("	    \"name_of_Purchased\": \""+data.getDeceased_client_id()+"\",	");
//			requestdata.append("	    \"contact_No_Purchased\": \""+data.getEffective_date()+"\",	");
//			requestdata.append("	    \"tenure\": \""+data.getService_go_code()+"\",	");
//			requestdata.append("	    \"annual_Premium_Paid_Policy\": \""+data.getClaimants_no()+"\",	");
//			requestdata.append("	    \"freequency_of_Premium_Paid\": \""+data.getLas_state()+"\",	");
//			requestdata.append("	    \"uLIP_Non_ULIP\": \""+data.getCause_of_event()+"\",	");
//			requestdata.append("	    \"channel_of_Purchase\": \""+data.getChannell()+"\",	");
//			requestdata.append("	    \"age_of_Insured\": \""+data.getZone()+"\",	");
//			requestdata.append("	    \"cAT_Yes_No\": \""+data.getAgent_status()+"\",	");
//			requestdata.append("	    \"policy_Type\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"zONE_NAME\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"writing_Agent_ID\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"writing_Agent_Status\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"servicing_Agent_ID\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"servicing_Agent_Status\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"agent_Segment\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"dCS\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"med_Non_Med_cases\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
//			requestdata.append("	    \"reason_for_Counter_Offer\": \""+data.getEti_reduced_paid_up_cases()+"\",	");
			requestdata.append("	  },	");
			OutputStreamWriter writer = new OutputStreamWriter(conn.getOutputStream());
			writer.write(requestdata.toString());
			writer.flush();
			try {writer.close(); } 
			catch (Exception e1) 
			{
//				logger.info(e1);
			}

			int apiResponseCode = conn.getResponseCode();
			if(apiResponseCode == 200)
			{
				BufferedReader br = new BufferedReader(new InputStreamReader((conn.getInputStream())));
				while ((output = br.readLine()) != null) 
				{
					result.append(output);
				}
				conn.disconnect();
				br.close();
//				logger.info("External API Call : END : servicegetUserDetail : User Validation");

			}
			else
			{
//				logger.info("Unable to connect External GetUserDetail API");
			}
		}
		catch(Exception e)
		{
//			logger.info("Exception Occoured While Calling getUserDetail API"+e);
		}
//		logger.info("END :- OutSide : - getUserDetail :- SSOID:- "+ssoId);
		return result.toString();
	}
}
