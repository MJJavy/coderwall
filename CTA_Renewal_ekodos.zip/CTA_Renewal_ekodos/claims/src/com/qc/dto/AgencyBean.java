package com.qc.dto;

import java.util.ArrayList;
import java.util.Date;



public class AgencyBean {
	
	private String polIdKey;
	private String policyStatus;
	private String issueDate;
	private String inforceDate;
	private String customerId;
	private String ownerIdKey;
	private String planId;
	private String planName;
	private String policyTenure;
	private String frequencyPremiumPaid;
	private String policyType;
	private String channel;
	private String annualPremium;
	private String totalPremiumPaid;
	private String modalPremium;
	private String goCodes;
	private String wrAgtId;
	private String wrAgtName;
	private String servAgtId;
	private String classData;
	private String servAgentName;
	private String servBrId;
	private String zone;
	private String hniFlag;
	private String catFlag;
	private String customerName;
	private String ladnlineNumber;
	private String contactNo;
	private String mobileNo;
	private String instrumentSeqNo;
	private String locationCode;
	private String strinstrtypecd;
	private String instrumentType;
	private String instrumentCategory;
	private String dtreceipt;
	private String dtinstr;
	private String strinstrnbr;
	private String dtcreated;
	private String dtstub;
	private String instrumentAmount;
	
	//added by MJ*
	private String category;
	
	
	public String getPolIdKey() {
		return polIdKey;
	}
	public void setPolIdKey(String polIdKey) {
		this.polIdKey = polIdKey;
	}
	public String getPolicyStatus() {
		return policyStatus;
	}
	public void setPolicyStatus(String policyStatus) {
		this.policyStatus = policyStatus;
	}
	public String getIssueDate() {
		return issueDate;
	}
	public void setIssueDate(String issueDate) {
		this.issueDate = issueDate;
	}
	public String getInforceDate() {
		return inforceDate;
	}
	public void setInforceDate(String inforceDate) {
		this.inforceDate = inforceDate;
	}
	public String getCustomerId() {
		return customerId;
	}
	public void setCustomerId(String customerId) {
		this.customerId = customerId;
	}
	public String getOwnerIdKey() {
		return ownerIdKey;
	}
	public void setOwnerIdKey(String ownerIdKey) {
		this.ownerIdKey = ownerIdKey;
	}
	public String getPlanId() {
		return planId;
	}
	public void setPlanId(String planId) {
		this.planId = planId;
	}
	public String getPlanName() {
		return planName;
	}
	public void setPlanName(String planName) {
		this.planName = planName;
	}
	public String getPolicyTenure() {
		return policyTenure;
	}
	public void setPolicyTenure(String policyTenure) {
		this.policyTenure = policyTenure;
	}
	public String getFrequencyPremiumPaid() {
		return frequencyPremiumPaid;
	}
	public void setFrequencyPremiumPaid(String frequencyPremiumPaid) {
		this.frequencyPremiumPaid = frequencyPremiumPaid;
	}
	public String getPolicyType() {
		return policyType;
	}
	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}
	public String getChannel() {
		return channel;
	}
	public void setChannel(String channel) {
		this.channel = channel;
	}
	public String getAnnualPremium() {
		return annualPremium;
	}
	public void setAnnualPremium(String annualPremium) {
		this.annualPremium = annualPremium;
	}
	public String getTotalPremiumPaid() {
		return totalPremiumPaid;
	}
	public void setTotalPremiumPaid(String totalPremiumPaid) {
		this.totalPremiumPaid = totalPremiumPaid;
	}
	public String getModalPremium() {
		return modalPremium;
	}
	public void setModalPremium(String modalPremium) {
		this.modalPremium = modalPremium;
	}
	public String getGoCodes() {
		return goCodes;
	}
	public void setGoCodes(String goCodes) {
		this.goCodes = goCodes;
	}
	public String getWrAgtId() {
		return wrAgtId;
	}
	public void setWrAgtId(String wrAgtId) {
		this.wrAgtId = wrAgtId;
	}
	public String getWrAgtName() {
		return wrAgtName;
	}
	public void setWrAgtName(String wrAgtName) {
		this.wrAgtName = wrAgtName;
	}
	public String getServAgtId() {
		return servAgtId;
	}
	public void setServAgtId(String servAgtId) {
		this.servAgtId = servAgtId;
	}
	public String getClassData() {
		return classData;
	}
	public void setClassData(String classData) {
		this.classData = classData;
	}
	public String getServAgentName() {
		return servAgentName;
	}
	public void setServAgentName(String servAgentName) {
		this.servAgentName = servAgentName;
	}
	public String getServBrId() {
		return servBrId;
	}
	public void setServBrId(String servBrId) {
		this.servBrId = servBrId;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getHniFlag() {
		return hniFlag;
	}
	public void setHniFlag(String hniFlag) {
		this.hniFlag = hniFlag;
	}
	public String getCatFlag() {
		return catFlag;
	}
	public void setCatFlag(String catFlag) {
		this.catFlag = catFlag;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getLadnlineNumber() {
		return ladnlineNumber;
	}
	public void setLadnlineNumber(String ladnlineNumber) {
		this.ladnlineNumber = ladnlineNumber;
	}
	public String getContactNo() {
		return contactNo;
	}
	public void setContactNo(String contactNo) {
		this.contactNo = contactNo;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getInstrumentSeqNo() {
		return instrumentSeqNo;
	}
	public void setInstrumentSeqNo(String instrumentSeqNo) {
		this.instrumentSeqNo = instrumentSeqNo;
	}
	public String getLocationCode() {
		return locationCode;
	}
	public void setLocationCode(String locationCode) {
		this.locationCode = locationCode;
	}
	public String getStrinstrtypecd() {
		return strinstrtypecd;
	}
	public void setStrinstrtypecd(String strinstrtypecd) {
		this.strinstrtypecd = strinstrtypecd;
	}
	public String getInstrumentType() {
		return instrumentType;
	}
	public void setInstrumentType(String instrumentType) {
		this.instrumentType = instrumentType;
	}
	public String getInstrumentCategory() {
		return instrumentCategory;
	}
	public void setInstrumentCategory(String instrumentCategory) {
		this.instrumentCategory = instrumentCategory;
	}
	public String getDtreceipt() {
		return dtreceipt;
	}
	public void setDtreceipt(String dtreceipt) {
		this.dtreceipt = dtreceipt;
	}
	public String getDtinstr() {
		return dtinstr;
	}
	public void setDtinstr(String dtinstr) {
		this.dtinstr = dtinstr;
	}
	public String getStrinstrnbr() {
		return strinstrnbr;
	}
	public void setStrinstrnbr(String strinstrnbr) {
		this.strinstrnbr = strinstrnbr;
	}
	public String getDtcreated() {
		return dtcreated;
	}
	public void setDtcreated(String dtcreated) {
		this.dtcreated = dtcreated;
	}
	public String getDtstub() {
		return dtstub;
	}
	public void setDtstub(String dtstub) {
		this.dtstub = dtstub;
	}
	public String getInstrumentAmount() {
		return instrumentAmount;
	}
	public void setInstrumentAmount(String instrumentAmount) {
		this.instrumentAmount = instrumentAmount;
	}
	
	
	public String getCategory() {
		return category;
	}
	public void setCategory(String category) {
		this.category = category;
	}
	@Override
	public String toString() {
		return "SparcBean [polIdKey=" + polIdKey + ", policyStatus=" + policyStatus + ", issueDate=" + issueDate
				+ ", inforceDate=" + inforceDate + ", customerId=" + customerId + ", ownerIdKey=" + ownerIdKey
				+ ", planId=" + planId + ", planName=" + planName + ", policyTenure=" + policyTenure
				+ ", frequencyPremiumPaid=" + frequencyPremiumPaid + ", policyType=" + policyType + ", channel="
				+ channel + ", annualPremium=" + annualPremium + ", totalPremiumPaid=" + totalPremiumPaid
				+ ", modalPremium=" + modalPremium + ", goCodes=" + goCodes + ", wrAgtId=" + wrAgtId + ", wrAgtName="
				+ wrAgtName + ", servAgtId=" + servAgtId + ", classData=" + classData + ", servAgentName="
				+ servAgentName + ", servBrId=" + servBrId + ", zone=" + zone + ", hniFlag=" + hniFlag + ", catFlag="
				+ catFlag + ", customerName=" + customerName + ", ladnlineNumber=" + ladnlineNumber + ", contactNo="
				+ contactNo + ", mobileNo=" + mobileNo + ", instrumentSeqNo=" + instrumentSeqNo + ", locationCode="
				+ locationCode + ", strinstrtypecd=" + strinstrtypecd + ", instrumentType=" + instrumentType
				+ ", instrumentCategory=" + instrumentCategory + ", dtreceipt=" + dtreceipt + ", dtinstr=" + dtinstr
				+ ", strinstrnbr=" + strinstrnbr + ", dtcreated=" + dtcreated + ", dtstub=" + dtstub
				+ ", instrumentAmount=" + instrumentAmount + "]";
	}
	
	
}
