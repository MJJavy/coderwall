package com.qc.dto;

public class ClaimBean {

	private String s_no;
	private String stage;
	private String policy_no;
	private String life_insured;
	private String date_of_death;
	private String date_of_intimation_go;
	private String total_claim_amount;
	private String settlement_date;
	private String claimant;
	private String early_non_early;
	private String deceased_client_id;
	private String effective_date;
	private String service_go_code;
	private String claimants_no;
	private String las_state;
	private String cause_of_event;
	private String channell;
	private String zone;
	private String agent_status;
	private String eti_reduced_paid_up_cases;
	public String getS_no() {
		return s_no;
	}
	public void setS_no(String s_no) {
		this.s_no = s_no;
	}
	public String getStage() {
		return stage;
	}
	public void setStage(String stage) {
		this.stage = stage;
	}
	public String getPolicy_no() {
		return policy_no;
	}
	public void setPolicy_no(String policy_no) {
		this.policy_no = policy_no;
	}
	public String getLife_insured() {
		return life_insured;
	}
	public void setLife_insured(String life_insured) {
		this.life_insured = life_insured;
	}
	public String getDate_of_death() {
		return date_of_death;
	}
	public void setDate_of_death(String date_of_death) {
		this.date_of_death = date_of_death;
	}
	public String getDate_of_intimation_go() {
		return date_of_intimation_go;
	}
	public void setDate_of_intimation_go(String date_of_intimation_go) {
		this.date_of_intimation_go = date_of_intimation_go;
	}
	public String getTotal_claim_amount() {
		return total_claim_amount;
	}
	public void setTotal_claim_amount(String total_claim_amount) {
		this.total_claim_amount = total_claim_amount;
	}
	public String getSettlement_date() {
		return settlement_date;
	}
	public void setSettlement_date(String settlement_date) {
		this.settlement_date = settlement_date;
	}
	public String getClaimant() {
		return claimant;
	}
	public void setClaimant(String claimant) {
		this.claimant = claimant;
	}
	public String getEarly_non_early() {
		return early_non_early;
	}
	public void setEarly_non_early(String early_non_early) {
		this.early_non_early = early_non_early;
	}
	public String getDeceased_client_id() {
		return deceased_client_id;
	}
	public void setDeceased_client_id(String deceased_client_id) {
		this.deceased_client_id = deceased_client_id;
	}
	public String getEffective_date() {
		return effective_date;
	}
	public void setEffective_date(String effective_date) {
		this.effective_date = effective_date;
	}
	public String getService_go_code() {
		return service_go_code;
	}
	public void setService_go_code(String service_go_code) {
		this.service_go_code = service_go_code;
	}
	public String getClaimants_no() {
		return claimants_no;
	}
	public void setClaimants_no(String claimants_no) {
		this.claimants_no = claimants_no;
	}
	public String getLas_state() {
		return las_state;
	}
	public void setLas_state(String las_state) {
		this.las_state = las_state;
	}
	public String getCause_of_event() {
		return cause_of_event;
	}
	public void setCause_of_event(String cause_of_event) {
		this.cause_of_event = cause_of_event;
	}
	public String getChannell() {
		return channell;
	}
	public void setChannell(String channell) {
		this.channell = channell;
	}
	public String getZone() {
		return zone;
	}
	public void setZone(String zone) {
		this.zone = zone;
	}
	public String getAgent_status() {
		return agent_status;
	}
	public void setAgent_status(String agent_status) {
		this.agent_status = agent_status;
	}
	public String getEti_reduced_paid_up_cases() {
		return eti_reduced_paid_up_cases;
	}
	public void setEti_reduced_paid_up_cases(String eti_reduced_paid_up_cases) {
		this.eti_reduced_paid_up_cases = eti_reduced_paid_up_cases;
	}
	@Override
	public String toString() {
		return "ClaimBean [s_no=" + s_no + ", stage=" + stage + ", policy_no=" + policy_no + ", life_insured="
				+ life_insured + ", date_of_death=" + date_of_death + ", date_of_intimation_go=" + date_of_intimation_go
				+ ", total_claim_amount=" + total_claim_amount + ", settlement_date=" + settlement_date + ", claimant="
				+ claimant + ", early_non_early=" + early_non_early + ", deceased_client_id=" + deceased_client_id
				+ ", effective_date=" + effective_date + ", service_go_code=" + service_go_code + ", claimants_no="
				+ claimants_no + ", las_state=" + las_state + ", cause_of_event=" + cause_of_event + ", channell="
				+ channell + ", zone=" + zone + ", agent_status=" + agent_status + ", eti_reduced_paid_up_cases="
				+ eti_reduced_paid_up_cases + "]";
	}
	
}
