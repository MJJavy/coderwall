package com.qc.dto;

public class MedicalBean {
	private	String	gO_Code;
	private	String	policy_Number;
	private	String	dispatched_Date	;
	private	String	dispatch_Mode	;
	private	String	packet_Status	;
	private	String	delivery_Date	;
	private	String	issue_Date	;
	private	String	customer_Sign_Date	;
	private	String	inforce_Date	;
	private	String	customer_ID	;
	private	String	name_of_Purchased	;
	private	String	contact_No_Purchased	;
	private	String	tenure;
	private	String	annual_Premium_Paid_Policy	;
	private	String	freequency_of_Premium_Paid	;
	private	String	uLIP_Non_ULIP	;
	private	String	channel_of_Purchase	;
	private	String	age_of_Insured	;
	private	String	cAT_Yes_No;
	private	String	policy_Type	;
	private	String	zONE_NAME	;
	private	String	writing_Agent_ID	;
	private	String	writing_Agent_Status	;
	private	String	servicing_Agent_ID	;
	private	String	servicing_Agent_Status	;
	private	String	agent_Segment	;
	private	String	dCS	;
	private	String	med_Non_Med_cases	;
	private	String	reason_for_Counter_Offer	;
	public String getgO_Code() {
		return gO_Code;
	}
	public void setgO_Code(String gO_Code) {
		this.gO_Code = gO_Code;
	}
	public String getPolicy_Number() {
		return policy_Number;
	}
	public void setPolicy_Number(String policy_Number) {
		this.policy_Number = policy_Number;
	}
	public String getDispatched_Date() {
		return dispatched_Date;
	}
	public void setDispatched_Date(String dispatched_Date) {
		this.dispatched_Date = dispatched_Date;
	}
	public String getDispatch_Mode() {
		return dispatch_Mode;
	}
	public void setDispatch_Mode(String dispatch_Mode) {
		this.dispatch_Mode = dispatch_Mode;
	}
	public String getPacket_Status() {
		return packet_Status;
	}
	public void setPacket_Status(String packet_Status) {
		this.packet_Status = packet_Status;
	}
	public String getDelivery_Date() {
		return delivery_Date;
	}
	public void setDelivery_Date(String delivery_Date) {
		this.delivery_Date = delivery_Date;
	}
	public String getIssue_Date() {
		return issue_Date;
	}
	public void setIssue_Date(String issue_Date) {
		this.issue_Date = issue_Date;
	}
	public String getCustomer_Sign_Date() {
		return customer_Sign_Date;
	}
	public void setCustomer_Sign_Date(String customer_Sign_Date) {
		this.customer_Sign_Date = customer_Sign_Date;
	}
	public String getInforce_Date() {
		return inforce_Date;
	}
	public void setInforce_Date(String inforce_Date) {
		this.inforce_Date = inforce_Date;
	}
	public String getCustomer_ID() {
		return customer_ID;
	}
	public void setCustomer_ID(String customer_ID) {
		this.customer_ID = customer_ID;
	}
	public String getName_of_Purchased() {
		return name_of_Purchased;
	}
	public void setName_of_Purchased(String name_of_Purchased) {
		this.name_of_Purchased = name_of_Purchased;
	}
	public String getContact_No_Purchased() {
		return contact_No_Purchased;
	}
	public void setContact_No_Purchased(String contact_No_Purchased) {
		this.contact_No_Purchased = contact_No_Purchased;
	}
	public String getTenure() {
		return tenure;
	}
	public void setTenure(String tenure) {
		this.tenure = tenure;
	}
	public String getAnnual_Premium_Paid_Policy() {
		return annual_Premium_Paid_Policy;
	}
	public void setAnnual_Premium_Paid_Policy(String annual_Premium_Paid_Policy) {
		this.annual_Premium_Paid_Policy = annual_Premium_Paid_Policy;
	}
	public String getFreequency_of_Premium_Paid() {
		return freequency_of_Premium_Paid;
	}
	public void setFreequency_of_Premium_Paid(String freequency_of_Premium_Paid) {
		this.freequency_of_Premium_Paid = freequency_of_Premium_Paid;
	}
	public String getuLIP_Non_ULIP() {
		return uLIP_Non_ULIP;
	}
	public void setuLIP_Non_ULIP(String uLIP_Non_ULIP) {
		this.uLIP_Non_ULIP = uLIP_Non_ULIP;
	}
	public String getChannel_of_Purchase() {
		return channel_of_Purchase;
	}
	public void setChannel_of_Purchase(String channel_of_Purchase) {
		this.channel_of_Purchase = channel_of_Purchase;
	}
	public String getAge_of_Insured() {
		return age_of_Insured;
	}
	public void setAge_of_Insured(String age_of_Insured) {
		this.age_of_Insured = age_of_Insured;
	}
	public String getcAT_Yes_No() {
		return cAT_Yes_No;
	}
	public void setcAT_Yes_No(String cAT_Yes_No) {
		this.cAT_Yes_No = cAT_Yes_No;
	}
	public String getPolicy_Type() {
		return policy_Type;
	}
	public void setPolicy_Type(String policy_Type) {
		this.policy_Type = policy_Type;
	}
	public String getzONE_NAME() {
		return zONE_NAME;
	}
	public void setzONE_NAME(String zONE_NAME) {
		this.zONE_NAME = zONE_NAME;
	}
	public String getWriting_Agent_ID() {
		return writing_Agent_ID;
	}
	public void setWriting_Agent_ID(String writing_Agent_ID) {
		this.writing_Agent_ID = writing_Agent_ID;
	}
	public String getWriting_Agent_Status() {
		return writing_Agent_Status;
	}
	public void setWriting_Agent_Status(String writing_Agent_Status) {
		this.writing_Agent_Status = writing_Agent_Status;
	}
	public String getServicing_Agent_ID() {
		return servicing_Agent_ID;
	}
	public void setServicing_Agent_ID(String servicing_Agent_ID) {
		this.servicing_Agent_ID = servicing_Agent_ID;
	}
	public String getServicing_Agent_Status() {
		return servicing_Agent_Status;
	}
	public void setServicing_Agent_Status(String servicing_Agent_Status) {
		this.servicing_Agent_Status = servicing_Agent_Status;
	}
	public String getAgent_Segment() {
		return agent_Segment;
	}
	public void setAgent_Segment(String agent_Segment) {
		this.agent_Segment = agent_Segment;
	}
	public String getdCS() {
		return dCS;
	}
	public void setdCS(String dCS) {
		this.dCS = dCS;
	}
	public String getMed_Non_Med_cases() {
		return med_Non_Med_cases;
	}
	public void setMed_Non_Med_cases(String med_Non_Med_cases) {
		this.med_Non_Med_cases = med_Non_Med_cases;
	}
	public String getReason_for_Counter_Offer() {
		return reason_for_Counter_Offer;
	}
	public void setReason_for_Counter_Offer(String reason_for_Counter_Offer) {
		this.reason_for_Counter_Offer = reason_for_Counter_Offer;
	}
	@Override
	public String toString() {
		return "MedicalsBean [gO_Code=" + gO_Code + ", policy_Number=" + policy_Number + ", dispatched_Date="
				+ dispatched_Date + ", dispatch_Mode=" + dispatch_Mode + ", packet_Status=" + packet_Status
				+ ", delivery_Date=" + delivery_Date + ", issue_Date=" + issue_Date + ", customer_Sign_Date="
				+ customer_Sign_Date + ", inforce_Date=" + inforce_Date + ", customer_ID=" + customer_ID
				+ ", name_of_Purchased=" + name_of_Purchased + ", contact_No_Purchased=" + contact_No_Purchased
				+ ", tenure=" + tenure + ", annual_Premium_Paid_Policy=" + annual_Premium_Paid_Policy
				+ ", freequency_of_Premium_Paid=" + freequency_of_Premium_Paid + ", uLIP_Non_ULIP=" + uLIP_Non_ULIP
				+ ", channel_of_Purchase=" + channel_of_Purchase + ", age_of_Insured=" + age_of_Insured
				+ ", cAT_Yes_No=" + cAT_Yes_No + ", policy_Type=" + policy_Type + ", zONE_NAME=" + zONE_NAME
				+ ", writing_Agent_ID=" + writing_Agent_ID + ", writing_Agent_Status=" + writing_Agent_Status
				+ ", servicing_Agent_ID=" + servicing_Agent_ID + ", servicing_Agent_Status=" + servicing_Agent_Status
				+ ", agent_Segment=" + agent_Segment + ", dCS=" + dCS + ", med_Non_Med_cases=" + med_Non_Med_cases
				+ ", reason_for_Counter_Offer=" + reason_for_Counter_Offer + "]";
	}

}
