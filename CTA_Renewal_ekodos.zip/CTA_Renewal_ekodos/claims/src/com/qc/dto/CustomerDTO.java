package com.qc.dto;

public class CustomerDTO {

	String teamId;
	String teamName;
	String parent_Team_Id;
	String last_update_date;
	String is_Delete;
	String last_update_id;
	
	public String getTeamId() {
		return teamId;
	}
	public void setTeamId(String teamId) {
		this.teamId = teamId;
	}
	public String getTeamName() {
		return teamName;
	}
	public void setTeamName(String teamName) {
		this.teamName = teamName;
	}
	public String getParent_Team_Id() {
		return parent_Team_Id;
	}
	public void setParent_Team_Id(String parent_Team_Id) {
		this.parent_Team_Id = parent_Team_Id;
	}
	public String getLast_update_date() {
		return last_update_date;
	}
	public void setLast_update_date(String last_update_date) {
		this.last_update_date = last_update_date;
	}
	public String getIs_Delete() {
		return is_Delete;
	}
	public void setIs_Delete(String is_Delete) {
		this.is_Delete = is_Delete;
	}
	
	
	public String getLast_update_id() {
		return last_update_id;
	}
	public void setLast_update_id(String last_update_id) {
		this.last_update_id = last_update_id;
	}
	@Override
	public String toString() {
		return "CustomerDTO [teamId=" + teamId + ", teamName=" + teamName + ", parent_Team_Id=" + parent_Team_Id
				+ ", last_update_date=" + last_update_date + ", is_Delete=" + is_Delete + ", last_update_id="
				+ last_update_id + "]";
	}

}
