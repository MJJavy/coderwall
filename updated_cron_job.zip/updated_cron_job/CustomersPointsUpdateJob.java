package com.gamification.core;

import de.hybris.platform.cronjob.enums.CronJobResult;
import de.hybris.platform.cronjob.enums.CronJobStatus;
import de.hybris.platform.cronjob.model.CronJobModel;
import de.hybris.platform.servicelayer.cronjob.AbstractJobPerformable;
import de.hybris.platform.servicelayer.cronjob.PerformResult;

import java.util.Date;

import javax.annotation.Resource;

import org.apache.log4j.Logger;

import com.gamification.core.service.GamificationEventsPointsService;


public class CustomersPointsUpdateJob extends AbstractJobPerformable<CronJobModel>
{
	@Resource
	private GamificationEventsPointsService gamificationEventsPointsService;


	private final static Logger LOG = Logger.getLogger(CustomersPointsUpdateJob.class.getName());

	@Override
	public PerformResult perform(final CronJobModel cronJobModel)
	{
		int bonusPoint = 0;
		final Date lastExecutionTime = cronJobModel.getEndTime();
		if (lastExecutionTime != null)
		{
			bonusPoint = getGamificationEventsPointsService().getCustomerMonthlyEarnedPoints(lastExecutionTime);
		}

		if (bonusPoint > 0)
		{
			LOG.info("Finished Bonus Points Update CronJob. ");
			return new PerformResult(CronJobResult.SUCCESS, CronJobStatus.FINISHED);
		}
		else
		{
			LOG.info("Aborted Bonus Points Update CronJob. ");
			return new PerformResult(CronJobResult.FAILURE, CronJobStatus.ABORTED);
		}

	}

	public GamificationEventsPointsService getGamificationEventsPointsService()
	{
		return gamificationEventsPointsService;
	}

	public void setGamificationEventsPointsService(final GamificationEventsPointsService gamificationEventsPointsService)
	{
		this.gamificationEventsPointsService = gamificationEventsPointsService;
	}

}