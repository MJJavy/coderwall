/*
 * [y] hybris Platform
 *
 * Copyright (c) 2000-2019 SAP SE
 * All rights reserved.
 *
 * This software is the confidential and proprietary information of SAP
 * Hybris ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the
 * terms of the license agreement you entered into with SAP Hybris.
 */
package com.gamification.core.service.impl;

import de.hybris.platform.core.PK;
import de.hybris.platform.core.model.user.CustomerModel;
import de.hybris.platform.servicelayer.model.ModelService;
import de.hybris.platform.servicelayer.user.UserService;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;

import org.springframework.util.Assert;

import com.gamification.core.dao.GamificationEventsRecordDao;
import com.gamification.core.service.GamificationEventsPointsService;


/**
 * mj
 */
public class DefaultGamificationEventsPointsService implements GamificationEventsPointsService
{

	@Resource
	private UserService userService;

	private ModelService modelService;


	@Resource
	GamificationEventsRecordDao gamificationEventsRecordDao;


	@Override
	public int getCustomerMonthlyEarnedPoints(final Date fromDate)
	{
		final Map<CustomerModel, Integer> customerVal = new HashMap<>();
		int finalMonthlyPoints = 0;
		final List<Object> resOfMonthlyPoints = gamificationEventsRecordDao.getCurrentTotalEventsPoints(fromDate);
		Assert.notNull(resOfMonthlyPoints, "Monthly Event listOfRecords cannot be null.");


		for (final Object customerAndPointList : resOfMonthlyPoints)
		{
			final List<Object> customerAndPoint = (List<Object>) customerAndPointList;
			final String customerPK = (String) customerAndPoint.get(0);
			final String customermonthlyPoint = (String) customerAndPoint.get(1);
			final CustomerModel customerModel = modelService.get(PK.parse(customerPK));

			if (customerModel.getMonthlyBonusPoints() != null)
			{
				finalMonthlyPoints = customerModel.getMonthlyBonusPoints().intValue() + Integer.parseInt(customermonthlyPoint);
			}
			else
			{
				finalMonthlyPoints = Integer.parseInt(customermonthlyPoint);
			}

			customerModel.setMonthlyBonusPoints(finalMonthlyPoints);
			modelService.save(customerModel);


		}
		return finalMonthlyPoints;

	}


	public ModelService getModelService()
	{
		return modelService;
	}

	public void setModelService(final ModelService modelService)
	{
		this.modelService = modelService;
	}

	public UserService getUserService()
	{
		return userService;
	}

	public void setUserService(final UserService userService)
	{
		this.userService = userService;
	}

}
