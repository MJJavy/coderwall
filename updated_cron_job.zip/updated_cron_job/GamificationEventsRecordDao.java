package com.gamification.core.dao;

import java.util.Date;
import java.util.List;


/**
 * MJ
 */
public interface GamificationEventsRecordDao
{

	public List<Object> getCurrentTotalEventsPoints(Date fromDate);

}
